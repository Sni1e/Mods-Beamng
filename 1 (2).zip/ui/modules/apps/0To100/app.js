angular.module('beamng.apps')
    .directive('zeroto100', ['$log', function ($log) {
        return {
            template: '<div style="margin: 10px; background-color: rgba(255, 255, 255, 0.4); padding:10px; box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.75); border-bottom: solid 2px ' + "{{status_color}}" + '; border-bottom: solid 2px ' + "{{status_color}}" + '"><div style="width:100%; height:100%; background-color: rgba(255, 255, 255, 0.9); padding:10px; " layout="column">'

                + '<div layout="row" layout-align="space-between">'

                + '<div layout="column">' + '<div style="font-size: 1.5em; text-align:center;">' + "{{ timer | date:'mm:ss:sss'  }}" + '</div>' + '<div style="font-size: 0.7em; text-align:center;">' + "{{ status_color == 'red' ? 'TIME' : 'LAST TIME' }}" + '</div>' + '</div>'


                + '<div layout="column">' + '<div style="font-size: 1.5em; text-align:center;">' + "{{ best_time | date:'mm:ss:sss'  }}" + '</div>' + '<div style="font-size: 0.7em; text-align:center;">' + "BEST TIME" + '</div>' + '</div>'

                + '</div>'

                + '<div layout="column">' + '<div style=" display:' + "{{settings ? 'visible' : 'none'}}" + ';" ><md-slider flex min=0 max='+"500"+' ng-model="goalStart" step="5"></md-slider><md-slider style="margin-top:-10px;" flex min=0 max=500 ng-model="goalEnd" step="5"></md-slider></div>' + '<md-button class="md-flat" style=" text-transform: none; width: 30%; margin: -10px auto -10px;  font-size: 0.7em;" ng-click="buttonClick()">{{ goalStart }} - {{ goalEnd }} {{ units.label }}</md-button>' + '</div>'
            

                + '<div layout="row" layout-align="space-between" style="margin-top:15px;">' + '<div flex="100" style="background-color:'+ "{{acc ? '#b2b3b5' : '#555' }}" +'; hegiht: 5px; overflow: hidden;"><div style="font-size: 6px; background-color:'+ "{{acc ? '#555' : '#b2b3b5' }}" +'; width:' + "{{ acc ? (( (speed-goalStart)/(goalEnd-goalStart) )*100) <0 ? '0' : (( (speed-goalStart)/(goalEnd-goalStart) )*100) :  (( (speed-goalEnd)/(goalStart-goalEnd) )*100) <0 ? '0' : (( (speed-goalEnd)/(goalStart-goalEnd) )*100) }}" + '%; ">&nbsp;</div></div>' + '</div>'         

                +"</div></div>",


    replace: true,
    restrict: 'EA',

    controller: ['$scope', function ($scope) {
        $scope.goalEnd = 100;
        $scope.goalStart = 0;
        //clear values if goal is changed
        $scope.$watch('goalStart', function (newVal, oldVal) {
            $scope.best_time = 0;
            $scope.start_time = 0;
            $scope.timer = 0;
            $scope.ready = false;
            $scope.status_color = 'transparent';

        }, true);
        
        //clear values if goal is changed
        $scope.$watch('goalEnd', function (newVal, oldVal) {
            $scope.best_time = 0;
            $scope.start_time = 0;
            $scope.timer = 0;
            $scope.ready = false;
            $scope.status_color = 'transparent';



        }, true);

        $scope.settings = false;
        $scope.buttonClick = function () {
            if ($scope.settings) {
                $scope.settings = false;
            } else {
                $scope.settings = true;
            }
        };

}],


    link: function (scope, element, attrs) {
        'use strict';

        scope.$on('$destroy', function () {
            $log.debug('<speed-timer> destroyed');
        });

        var unitSystems = {
            imperial: {
                speedFactor: 2.236,
                label: 'mph'
            },
            metric: {
                speedFactor: 3.6,
                label: 'km/h'
            }
        };

        scope.speed = NaN;
        scope.units = unitSystems.metric;
        scope.goalEnd = 100;
        scope.goalStart = 0;
        scope.status_color = 'transparent';
        scope.timer = 0;
        scope.best_time = 0;
        scope.ready = false;


        scope.$on('SettingsChanged', function (event, data) {
            var uiUnits = data.values.uiUnits;

            if (unitSystems[uiUnits]) {
                scope.$evalAsync(function () {
                    scope.units = unitSystems[uiUnits];
                });
                if (uiUnits == 'imperial'){
                    scope.goalEnd = 60;
                }
                else if (uiUnits == 'metric'){
                    scope.goalEnd = 100;
                }
                scope.goalStart = 0;
                
            } else {
                $log.warn('<speed-timer> Attempted to change to unknown units %s', uiUnits);
            }
        });

        scope.$on('streamsUpdate', function (event, streams) {
            scope.$evalAsync(function () {
                
                scope.acc = scope.goalStart < scope.goalEnd;
                
                var speedMs = streams.electrics.airspeed;
                $log.debug('speed', speedMs);
                scope.speed = ('0000' + Math.round(speedMs * scope.units.speedFactor)).slice(-4);
                

                if ( scope.ready && ( (scope.speed > scope.goalStart &&  scope.acc) || (scope.speed < scope.goalStart && !scope.acc) ) ){ 
                    
                    if (scope.status_color != 'red') {
                        scope.timer = 0;
                        scope.status_color = 'red'                        
                    }
                    
                    var newTime = performance.now();
                    var timeDiff = newTime - scope.start_time;
                    //if change in time is small, game wasn't paused
                    if (timeDiff < 1000) {
                        scope.timer += timeDiff;
                    }
                    scope.start_time = newTime;

                    
                    if ( (scope.acc && scope.speed >= scope.goalEnd) || (!scope.acc && scope.speed <= scope.goalEnd) ) {
                        scope.ready = false;
                        scope.status_color = 'transparent';

                        if (scope.best_time > scope.timer || scope.best_time == 0) {
                            scope.best_time = scope.timer;
                        }                        
                    }
                }
                
                else if ( (scope.acc && scope.speed <= scope.goalStart) || (!scope.acc && scope.speed >= scope.goalStart) ) {

                    if (scope.ready && scope.status_color == 'red') {
                        scope.timer = 0;
                    }
                    
                    scope.start_time = performance.now();
                    scope.ready = true;
                    scope.status_color = 'green';
                }


            });
        });
    }
}
}])