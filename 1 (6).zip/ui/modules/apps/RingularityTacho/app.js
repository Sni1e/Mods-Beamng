angular.module('beamng.apps')
.directive('ringularityTacho', [function() {
  return {
    template:
        '<div id="RT_container">' +
          '<link rel="stylesheet" href="../../resources/base.css">' +
          '<link rel="stylesheet" href="../../modules/apps/RingularityTacho/app.css">' +
          '<canvas class="canvas" id="RT_bgCanvas" width="300" height="300"></canvas>' +
          '<canvas class="canvas" id="RT_canvas"   width="300" height="300"></canvas>' +
        '</div>',
    replace: true,
    restrict: 'EA',
    link: function ($scope, $element) {
      // This is all that is variable between apps
      const APP_TYPE = "tachometer";
      const APP_THEME = "ringularity";

      //////////////////////////////////////////////////////////////////////////////////////////////
      // Everything Below Required In All Apps                                                    //
      // Cannot be extracted into another file as cannot be loaded by Angular before then         //
      //////////////////////////////////////////////////////////////////////////////////////////////

      let vars = {
        /**
         * @type TachometersAppBase
         * Access through <b>getTachoAppBase</b>
         */
        TachometersAppBase: null,
        /** @type AbstractAppContainer */
        appContainer: null,
        /** @type string[] */
        requiredStreams: null,
        /** @type NullableDimensions */
        initialDimensions: null
      };

      ////////////////////////////////
      // Load the base angular file //
      ////////////////////////////////

      // noinspection JSClosureCompilerSyntax
      /**
       * Called when the app loads
       * @param {AbstractAppContainer} appCon - the app container instance
       * @param {class<AbstractAppContainer>} containerClass - the app container's class
       */
      function onAppLoaded(appCon, containerClass) {
        vars.appContainer = appCon;
        vars.requiredStreams = appCon.getRequiredStreams();
        StreamsManager.add(vars.requiredStreams);
      }

      /**
       * Returns the TachometersAppBase angular factory service. If this service has not yet been
       * retrieved, this function retrieves it and stores it for returning in future
       * @return {TachometersAppBase} the TachometersAppBase service
       */
      function getTachoAppBase() {
        if (!vars.TachometersAppBase)
          vars.TachometersAppBase = angular.injector(["beamng.apps"]).get("TachometersAppBase");

        return vars.TachometersAppBase;
      }

      /**
       * Called when the base angular script loads. This method begins the loading of every other
       * scripts and creating the app at the end. When the app is created, a call to <b>onAppLoaded
       * </b> is made
       */
      function onScriptLoad() {
        getTachoAppBase().load(APP_TYPE, APP_THEME, bngApi, UiUnits, onAppLoaded);
      }

      /**
       * Checks whether initial dimensions have been stored and whether the app is available. If so,
       * this function sets those initial dimensions and then clears them. Else, this function does
       * nothing
       */
      function checkAndSetInitDims() {
        if (vars.initialDimensions && vars.appContainer) {
          // Apply initial dimensions
          vars.appContainer.onAppResized(vars.initialDimensions);
          vars.initialDimensions = null;
        }
      }


      let appBase = document.createElement("script");
      appBase.src = "../../src/appBaseAngular.js";
      appBase.onload = onScriptLoad;
      $element.append(appBase);

      ////////////
      // Events //
      ////////////

      $scope.$on("VehicleFocusChanged", () => {
        if (vars.appContainer) {
          vars.appContainer.hideApp();
          vars.initialDimensions = vars.appContainer.getCurrentAppDimensions();
        }

        // If this is null, then the initial script setup has not yet begun so don't do anything
        // here (it'll be setup when the script loads)
        if (vars.TachometersAppBase)
          onScriptLoad();
      });

      $scope.$on("$destroy", () => {
        if (vars.requiredStreams)
          StreamsManager.remove(vars.requiredStreams);
      });

      $scope.$on("streamsUpdate", (_event, streams) => {
        checkAndSetInitDims();

        if (vars.appContainer)
          vars.appContainer.onStreamsUpdated(streams);
      });

      $scope.$on("app:resized", (_event, dimensions) => {
        if (vars.appContainer)
          vars.appContainer.onAppResized(dimensions);
        // Important not to overwrite any existing initial dimensions, since switching vehicle takes
        // precedence over this, so if they have been set by that function, don't overwrite them
        else if (!vars.initialDimensions)
          // Save for when the app is loaded
          vars.initialDimensions = dimensions;
      });

      //////////////////////////////////////////////////////////////////////////////////////////////
    }
  };
}]);