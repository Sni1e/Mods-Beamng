import glob
import re
from io import open
from pprint import pprint
from sys import argv
from functools import reduce

OUTPUT_FILENAME = "composite.all.js"

IGNORE = {
    OUTPUT_FILENAME: True,
    "appBaseAngular.js": True
}


########################################################################################################################
# Dictionary Helpers #
########################################################################################################################

def invertDict(dictionary):
    """
    Inverts the keys and values of a dictionary to be values and keys respectively.
    Will only work if the dictionary is not bijective
    :param dict dictionary:
    :return dict:
    """
    inverted = {}

    for k, v in dictionary.items():
        if isinstance(v, list):
            for item in v:
                inverted[item] = k
        else:
            inverted[v] = k

    return inverted


def conactDict(dictionary, keyOrder):
    """
    Concatenates the values of a dictionary, ordered by their associated keys
    :param dict dictionary: the dictionary to concatenate the values of
    :param list[str] keyOrder: the order of keys in the dictionary. A subset can be given to only concatenate a slice of
    the dictionary
    :return str: the concatenation
    """
    return reduce(lambda a, b: a + b, map(lambda k: dictionary.get(k), keyOrder))


def pairListToDic(pairList):
    """
    Converts a list of pairs into a dictionary, where the first value in a pair represents the key and the second
    represents the value
    :param list[(T, str)] pairList:
    :return: the dictionary created
    """
    return {a: b for (a, b) in pairList}


def dictMapValues(dictionary, func):
    """
    Performs a function on each value in the dictionary
    :param dict dictionary: the dictionary
    :param callable func: the function to apply to all values
    :return:
    """
    return {k: func(v) for k, v in dictionary.items()}


########################################################################################################################
# File Handling #
########################################################################################################################

def clear(filename):
    """
    Empties the content of a file and save it
    :param str filename: the name of the file to empty
    """
    open(filename, "w").close()


def writeTo(content, filename):
    """
    Writes text to a file
    :param str content: the content to write
    :param str filename: the name of the file to save to
    """
    f = open(filename, "w")
    f.write(content)
    f.close()


def readFile(filename):
    """
    Reads the contents of a file and returns it
    :param str filename: the name of the file to open
    :return str: the file's content
    """
    f = open(filename, "r")
    content = f.read() + "\n \n"
    f.close()
    return content


def readAll(rootFolder):
    """
    Reads all .js files in thie given directory and filters them to valid .js files for loading in BeamNG.
    This includes removing any imports, and removig the 'exports' keyword.
    Operates deep/recursively
    :param str rootFolder: the folder to search for .js files in
    :return [(str, str)]: a mapping of filename to content in the file
    """
    files = []

    for filename in glob.iglob(rootFolder + "/**/*.js", recursive=True):
        if filename.endswith('.js') and not IGNORE.get(filename.replace(rootFolder, "")):
            contents = filterLines(filename, lambda l: 'import' not in l)
            contents = contents.replace("export ", "")
            files.append((filename, contents))

    return files


def searchForKeyWord(string, keyword):
    """
    Searches a string for a keyword, and returns the next string of uppercase letter followed by letters to the next
    whitespace character
    :param str string: the string to search
    :param str keyword: the keyword to look for
    :return list[str]: the match(es)
    """
    return re.findall("(?<={}\s)([A-Z]\w*?)(?=\s)".format(keyword), string)


def filterLines(filename, lineFunc):
    """
    Reads a file, rejecting any line that is not valid using the passed lineFunc, and returning the valid lines as a
    single string
    :param str filename: the name of the file to filter
    :param lambda lineFunc: the function that determines whether a line is valid or not. Should return true if the line
    is valid, false if not
    :return str: the filtered file contents
    """
    valid = ""

    with open(filename, "r") as file:
        for line in file:
            if lineFunc(line):
                valid += line

    return valid


########################################################################################################################
# Dependency Mapping #
########################################################################################################################

def getClassDefinitions(string):
    """
    Returns a list of JavaScript class definitions found in a code string
    :param str string: the string to search
    :return list[str]: the list of class definitions found
    """
    return searchForKeyWord(string, "class")


def getClassDependencies(string):
    """
    Returns a list of JavaScript class dependencies found in a code string
    :param str string: the string to search
    :return list[str]: the list of class dependencies found
    """
    return searchForKeyWord(string, "extends")


def mapPairListToDict(pairList, func=lambda _: _):
    """
    Maps a list of pairs to a dictionary, with an option function being applied to each of the values of the dictionary
    :param list[(T, U)] pairList: the list of pairs
    :param callable(U) -> V func: the function to apply. Defaults to a function that keeps value the same
    :return dict[T, V]: the dictionary created
    """
    dictionary = pairListToDic(pairList)
    return dictMapValues(dictionary, func)


def getClassDefinitionsFromFiles(files):
    """
    Finds the class definitions from a list of files (as pairs of (filename, code content)), and creates a dictionary
    where the key is the filename and the value is the class(es) it defines
    :param list[(str, str)] files: the list of filename and code content pairs
    :return dict[str, str]: the dictionary of class definitions
    """
    return mapPairListToDict(files, getClassDefinitions)


def getClassDependenciesFromFiles(files):
    """
    Finds the class dependencies from a list of files (as pairs of (filename, code content)), and creates a dictionary
    where the key is the filename and the value is the class(es) it requires
    :param list[(str, str)] files: the list of filename and code content pairs
    :return dict[str, str]: the dictionary of class definitions
    """
    return mapPairListToDict(files, getClassDependencies)


def getFileDependencies(classDefs, classDeps):
    """
    Finds the file dependencies that another file needs, given their class depencieis, and the files that define them
    :param dict[str, str] classDefs: the class definitions, with key = class definition, value = class that defines them
    :param dict[str, str] classDeps: the class dependencies, with key = filename, value = list of class dependencies
    :return dict[str, Set]: the file dependencies, by filename : file dependencies
    """
    fileDepencencies = {}

    for filename, deps in classDeps.items():
        allDeps = set()
        for dep in deps:
            if not classDefs[dep] == filename:
                allDeps.add(classDefs[dep])

        fileDepencencies[filename] = allDeps

    return fileDepencencies


def splitByDependencies(fileDepencencies):
    """
    Splits a list of files into those which are independent of any other, and those thare are dependant on at least one
    other file
    :param dict[str, Iterable] fileDepencencies: the file dependencies
    :return (list[str], dict[str, Iterable]): the independent and dependant files
    """
    independent = []
    dependent = {}

    for filename, dependencies in fileDepencencies.items():
        if len(dependencies) == 0:
            independent.append(filename)
        else:
            dependent[filename] = dependencies

    return independent, dependent


def createDependencyList(fileDependencies):
    """
    Creates a dependency list where the returned string list's order represents files that are most indepedent to least
    :param dict[str, Iterable] fileDependencies: the file dependencies
    :return list[str]: the dependency list
    """
    dependencyList = []

    while len(fileDependencies) > 0:
        (independents, dependents) = splitByDependencies(fileDependencies)

        if len(independents) == 0:
            break

        for independent in independents:
            dependencyList.append(independent)

            for f, deps in dependents.items():
                if independent in deps:
                    deps.remove(independent)

        fileDependencies = dependents

    return dependencyList


if __name__ == "__main__":
    rootFolder = argv[1]
    outputPath = rootFolder + OUTPUT_FILENAME

    clear(outputPath)
    js = readAll(rootFolder + "out")
    jsDict = mapPairListToDict(js)
    classDefsByDefs = invertDict(getClassDefinitionsFromFiles(js))
    classDepsByName = getClassDependenciesFromFiles(js)
    fileDeps = getFileDependencies(classDefsByDefs, classDepsByName)
    depList = createDependencyList(fileDeps)
    composite = conactDict(jsDict, depList)
    writeTo(composite, outputPath)
