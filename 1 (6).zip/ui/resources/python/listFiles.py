import glob
import os.path


if __name__ == "__main__":
    files = [os.path.basename(x) for x in glob.glob('../../src/**/*.js', recursive=True)]

    for f in files:
        print(f)
