let value = 0.5;
let dir = 1;
let colourScheme = 0;

let engine = {maxRPM: 7300, redlineRPM: 8000};
let turbo = 500;

////////////////////////////////////////////////////////////////////////////////////////////////////

let tachoApp = new VelocityTachometerApp(150, document, null);
tachoApp.centre = new Vector(150, 160);
let boostApp = new VelocityBoostApp(75, document, null);
boostApp.centre = new Vector(425, 160);

let tachoApp2 = new FusionTachometerApp(150, document, null);
tachoApp2.centre = new Vector(150, 485);
let boostApp2 = new FusionBoostApp(75, document, null);
boostApp2.centre = new Vector(425, 485);

let tachoApp3 = new RingularityTachometerApp(150, document, null);
tachoApp3.centre = new Vector(150, 810)
let boostApp3 = new RingularityBoostApp(75, document, null);
boostApp3.centre = new Vector(425, 810);
//

let tachos = [tachoApp, tachoApp2, tachoApp3];
let fis = [boostApp, boostApp2, boostApp3];

for (let ta of tachos) {
  ta.sendInitialVehicleData(engine);
  ta.recreate(false);
  ta.drawBackgroundCanvas();
}
for (let ba of fis) {
  ba.sendInitialVehicleData(turbo);
  ba.recreate(false);
  ba.drawBackgroundCanvas();
}

////////////////////////////////////////////////////////////////////////////////////////////////////

let x = setInterval(() => {
  let vData = {
    pBrakeEnabled: value > 0.5,
    temp: value * 130,
    fuel: value,
    currRPM: value * engine.redlineRPM,
    speed: Math.round(value * 100),
    gear: Math.floor((value * 5.5) - 1),
    throttle: value,
    brake: value,
    indicators: {
      left: value > 0.5 ? 1 : 0,
      right: value > 0.5 ? 1 : 0,
    },
    shouldShift: value > 0.75,
    lightState: Math.floor(value * 2.5)
  };
  let bData = {boost: (value - 0.5) * turbo * 2};

  for (let tacho of tachos) {
    tacho.update(vData);
    tacho.draw();
  }
  for (let fi of fis) {
    fi.update(bData);
    fi.draw();
  }

  value += 0.005 * dir;

  let vals = swap(value, dir);
  dir = vals[0];
  value = vals[1];

  // clearInterval(x);
}, 10);

function swap(value, dir) {
  if (dir === 1 && value >= 1)
    return [-1, 1];
  else if (dir === -1 && value <= 0)
    return [1, 0];
  else
    return [dir, value];
}