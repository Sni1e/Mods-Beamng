{};
/**
 * Represents a canvas object that can be drawn on
 */
class Canvas {
    /**
     * @constructor
     * @param {Document} document - the document object this canvas is on
     * @param {string} ID - the canvas's identifier string
     * @param {number} baseSize - the width and height of the canvas __without__ any scaling being applied. In the context
     * of this being a canvas for an app, this should be set to the default/starting width of the app
     */
    constructor(document, ID, baseSize) {
        this.ID = ID;
        this.baseSize = baseSize;
        // The scale of the drawing on the canvas
        this.scaleFactor = 1;
        this.element = document.getElementById(this.ID);
        // Change the canvas size to match the dimensions of the app container
        this.setElementDimensions(this.getContainerDimensions());
    }
    /**
     * @returns {Dimensions} the current dimensions of the app container that this canvas is container within
     * @private
     */
    getContainerDimensions() {
        // The app container is 3 levels above
        return this.element.parentElement.parentElement.parentElement.getBoundingClientRect();
        // return { width: 1000, height: 1000 };
    }
    /**
     * Sets the dimensions of the canvas element
     * @param {Dimensions} newDimensions - the new dimensions to set
     * @private
     */
    setElementDimensions(newDimensions) {
        this.element.width = newDimensions.width;
        this.element.height = newDimensions.height;
    }
    /**
     * @return {Dimensions} the initial dimensions of the canvas
     */
    getCurrentDimensions() {
        return { width: this.element.width, height: this.element.height };
    }
    /**
     * Resizes the canvas's dimensions
     * @param {number} newSize - the size to set
     */
    resize(newSize) {
        this.scaleFactor = newSize / this.baseSize;
        this.setElementDimensions({ width: newSize, height: newSize });
    }
    /**
     * Shows or hides the canvas
     * @param {boolean} show - whether to show or hide the canvas
     */
    show(show) {
        this.element.style.opacity = show ? "1" : "0";
    }
    /**
     * @returns {CanvasRenderingContext2D} the 2D context of the canvas
     */
    get2DContext() {
        let ctx = this.element.getContext("2d");
        /* Add a scale factor parameter to the context
           Nothing outside of this class needs to know about this, since this is a parameter ONLY for
           this class to use when resetting the transform of the context */
        ctx.scaleFactor = this.scaleFactor;
        return ctx;
    }
    /**
     * Clears the canvas of all content drawn on it
     */
    clear() {
        let ctx = this.get2DContext();
        // Width/height will change, and current max is 750
        ctx.clearRect(0, 0, 2160, 2160);
    }
    /**
     * Sets a listener to a canvas for the left and right click action by a mouse
     * @param {(event: Event) => void} leftFunc - the function to perform on a left click
     * @param {(event: Event) => void} rightFunc - the function to perform on a right click
     */
    setupCanvasClick(leftFunc, rightFunc) {
        // Remove any previous event listeners
        this.removeEventListeners();
        this.element.addEventListener("mousedown", function (event) {
            switch (event.button) {
                case 0:
                    leftFunc(event);
                    break;
                case 2:
                    rightFunc(event);
                    break;
            }
        });
    }
    /**
     * Removes all event listeners from this canvas element
     * @private
     */
    removeEventListeners() {
        let newElement = this.element.cloneNode(false);
        this.element.replaceWith(newElement);
        this.element = document.getElementById(this.ID);
    }
    /**
     * Resets the transformation of a canvas's 2D context
     * @param {CanvasRenderingContext2D} ctx - the context to reset the transformation of
     */
    static resetTransformationState(ctx) {
        let sctx = ctx;
        sctx.setTransform(1, 0, 0, 1, 0, 0);
        /* Keep the scaling as this is global for the whole canvas.
           Other classes need not know about this, as this should be encapsulated.
           Not the best solution, but it allows complete global control over scaling via one line of
           code */
        sctx.scale(sctx.scaleFactor, sctx.scaleFactor);
    }
    /**
     * Resets the filter to prevent lingering filters
     * @param {CanvasRenderingContext2D} ctx - the canvas context to reset the filter of
     */
    static resetFilter(ctx) {
        ctx.filter = "none";
        ctx.shadowBlur = 0;
        ctx.shadowColor = "none";
    }
    /**
     * Draws a shape to a canvas, preserving transparency of that shape. Any previously filled in
     * parts of the canvas will be drawn over
     * @param {(CanvasRenderingContext2D) => void} drawFunc - the function that will draw to the
     * canvas. Should take in the <b>ctx</b> object for drawing
     * @param {CanvasRenderingContext2D} ctx - the canvas context to draw to
     */
    static drawTransparency(drawFunc, ctx) {
        // Clear the area for alpha to work
        ctx.globalCompositeOperation = "destination-out";
        drawFunc(ctx);
        // Then draw the actual
        ctx.globalCompositeOperation = "source-over";
        drawFunc(ctx);
    }
}
/**
 * Represents an object is drawable to a canvas context object
 */
class Drawable {
}
/**
 * Represents a static background that can draw to a canvas and redraw periodically for a specific
 * app
 */
class AbstractBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw on
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        this.ctx = ctx;
        this.centre = centre;
        this.baseRadius = baseRadius;
        this.colourScheme = colourScheme;
        // The colour of the lighting (black = none)
        this.lightColour = "#000";
    }
    /**
     * Updates the lighting with the new colour. If this new colour is different, a re-draw is in
     * order and this method will return __true__ to indicated this
     * @param {string} lightColour - the colour of the lighting to set
     * @returns {boolean} whether the background needs a re-draw
     */
    updateLighting(lightColour) {
        if (this.lightColour !== lightColour) {
            this.lightColour = lightColour;
            return true;
        }
        return false;
    }
    /**
     * Draws to the internal instance canvas
     */
    draw() {
        Canvas.resetTransformationState(this.ctx);
    }
}
/**
 * Represent an app that can display information from a vehicle
 * @template T, S, R
 */
class AbstractBaseApp {
    /**
     * @constructor
     * @param {Theme} theme - the theme of this app
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     * @param {Newable<AbstractFullGaugeBuilder<R>>} GaugeBuilder - the gauge builder class to use when creating gauge
     * components
     * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
     */
    constructor(theme, baseRadius, document, bngApi, GaugeBuilder, Background) {
        this.theme = theme;
        this.baseRadius = baseRadius;
        this.document = document;
        this.bngApi = bngApi;
        this.GaugeBuilder = GaugeBuilder;
        this.Background = Background;
        this.COLOUR_SCHEMES = ColourScheme.createSchemes();
        // Default to first
        this.colourScheme = this.COLOUR_SCHEMES[0];
        // A flag that determines whether the background needs to be re-drawn for the next update cycle
        this.bgNeedsRedraw = false;
        this.centre = new Vector(baseRadius, baseRadius);
        this.id = this.getId();
        // The foreground and background canvases
        this.canvas = new Canvas(document, this.id + "_canvas", this.baseRadius * 2);
        this.bgCanvas = new Canvas(document, this.id + "_bgCanvas", this.baseRadius * 2);
        this.addClickEvents();
        this.background = this.createBackground();
    }
    /**
     * Creates the gauge component using the instance's gauge builder and returns it
     * @returns {R} the created gauge component
     * @protected
     */
    createGauge() {
        return this.setDefaultGaugeBuilderValues(this.GaugeBuilder).build();
    }
    /**
     * Creates the background component
     */
    createBackground() {
        return new this.Background(this.bgCanvas.get2DContext(), this.centre, this.baseRadius, this.colourScheme);
    }
    /**
     * Adds click an event handler for mouse actions on the foreground canvas
     */
    addClickEvents() {
        this.canvas.setupCanvasClick((_event) => this.cycleUnitWithUpdate(), (_event) => this.cycleColourSchemeWithUpdate());
    }
    /**
     * Sets default values to all setters in an AbstractComponentBuilder instance.
     * @param {AbstractComponentBuilder<any>} Builder - the class of builder to create and set values to
     * @returns {AbstractComponentBuilder<any>} the same builder object
     * @protected
     */
    setDefaultBuilderValues(Builder) {
        let builder = new Builder();
        // TODO - Find a better way of performing 'instanceof' for below partial classes
        if (Object.getPrototypeOf(builder)['setColourScheme'])
            builder.setColourScheme(this.colourScheme);
        if (Object.getPrototypeOf(builder)['setRadius'])
            builder.setRadius(this.baseRadius);
        if (Object.getPrototypeOf(builder)['setFontName'])
            builder.setFontName(this.theme.FONT_NAME);
        if (Object.getPrototypeOf(builder)['setCtx'])
            builder.setCtx(this.canvas.get2DContext());
        return builder.setCentre(this.centre);
    }
    /**
     * Sets default values to all setters in an AbstractFullGaugeBuilder instance.
     * @param {AbstractFullGaugeBuilder<any>} builder - the builder to set values to
     * @returns {AbstractFullGaugeBuilder<any>} the same builder object
     * @protected
     */
    setDefaultGaugeBuilderValues(builder) {
        return this.setDefaultBuilderValues(builder);
    }
    /**
     * Resizes the canvases for drawing on a smaller or bigger canvas.
     * Note that all apps are currently square (and assumed for the future?) so this will also set the height to this
     * value as well
     * @param {number} newWidth - the new width to assign
     */
    resize(newWidth) {
        this.canvas.resize(newWidth);
        this.bgCanvas.resize(newWidth);
    }
    /**
     * @return {Dimensions} the current dimensions of the canvases
     */
    getCurrentDimensions() {
        return this.canvas.getCurrentDimensions();
    }
    /**
     * Cycles the unit and recreates the app to show the change when drawing
     */
    cycleUnitWithUpdate() {
        this.cycleUnit();
        this.recreate(true);
    }
    /**
     * Cycles the colour scheme and recreates the app to show the change when drawing
     */
    cycleColourSchemeWithUpdate() {
        this.colourScheme = getNextElement(this.COLOUR_SCHEMES, this.colourScheme);
        // Re-creating is far easier than having tonnes of setters everywhere
        this.recreate(true);
    }
    /**
     * Recreates the components and re-draws the background canvas.
     * If the app is not return set up, this method does nothing
     */
    recreate(resave) {
        if (!this.isSetup())
            return;
        // Re-create components to reflect unit changes
        this.createComponents();
        // Re-create background
        this.background = this.createBackground();
        this.drawBackgroundCanvas();
        // Save this colour scheme and unit as default
        if (resave)
            this.save();
    }
    /**
     * Saves the current colour scheme and unit to a file in the user's directory. Note that this
     * only saves the indexes with respect to the colourSchemes array and not the actual instance
     */
    save() {
        let data = {
            unit: this.getIndexOfCurrUnit(),
            colourScheme: this.COLOUR_SCHEMES.indexOf(this.colourScheme)
        };
        this.bngApi.engineLua("extensions.ui_tachometers.save('" + this.id + "', " + this.bngApi.serializeToLua(data) + ")");
    }
    /**
     * Loads the settings file from the user's directory. If the file does not exist, this method
     * does nothing; else, it loads the unit and colour scheme to this app
     */
    load() {
        this.bngApi.engineLua("extensions.ui_tachometers.load('" + this.id + "')", (response) => {
            if (!response)
                return;
            this.setIndexOfCurrUnit(response.unit || 0);
            // Backwards compatibility -> the number of colour-schemes has changed so check it is not out
            // of bounds
            this.colourScheme =
                this.COLOUR_SCHEMES[response.colourScheme < this.COLOUR_SCHEMES.length ? response.colourScheme : 0];
            this.recreate(false);
        });
    }
    /**
     * Draws to the main canvas
     */
    draw() {
        // Re-draw if necessary before the foreground canvas does so
        if (this.bgNeedsRedraw)
            this.drawBackgroundCanvas();
        this.canvas.show(true);
        this.canvas.clear();
    }
    /**
     * Draws the app to the background canvas
     */
    drawBackgroundCanvas() {
        this.bgCanvas.show(true);
        this.bgCanvas.clear();
        this.background.draw();
    }
    /**
     * Hides the app by hiding both canvases
     */
    hide() {
        this.canvas.show(false);
        this.bgCanvas.show(false);
        // When this app is next drawn, the background will need an update
        this.bgNeedsRedraw = true;
    }
    /**
     * Reloads the UI, hiding it after 50ms. If instantReload is true, this is done
     * instantly
     * @param {AbstractBaseApp} app - the app to reload
     * @param {boolean} instantReload - whether to instantly reload instead of waiting
     */
    static reload(app, instantReload) {
        if (!app)
            return;
        let time = instantReload ? 0 : 50;
        setTimeout(() => {
            // It is unknown whether this vehicle will need this app, so hide it provisionally and it is
            // does, the app will re-show itself automatically when updating/drawing occurs
            app.hide();
        }, time);
    }
}
/**
 * Represents a container object for an app tha can setup, update and maintain this app
 */
class AbstractAppContainer {
    /**
     * @constructor
     * @param {AbstractBaseApp} app - the app
     */
    constructor(app) {
        this.app = app;
        // The initial dimensions
        this.initDimensions = null;
        // Whether the initial dimensions have been applied to the app yet
        this.hasInitDimensionsApplied = false;
        // A timer that will countdown to 0. A value of -1 means the timer is inactive
        this.resizingSaveTimer = -1;
    }
    /**
     * Sends streams data to the app. If the app is not yet setup, this method also setups the app and
     * handles the app being resized
     * @param {any} streams - the streams
     * @param {(streams: any, app: AbstractBaseApp) => void} appStreamUpdate - the update function to run on the app
     */
    onStreamsUpdate(streams, appStreamUpdate) {
        if (!this.app)
            return;
        appStreamUpdate(streams, this.app);
        if (!this.hasInitDimensionsApplied && this.initDimensions !== null && this.app.isSetup())
            this.applyInitDimensions();
        else
            this.updateResizeSaveTimer();
    }
    /**
     * Updates the resizing timer and saves the app if the timer reaches 0.
     * If the timer is not running, this method does nothing
     */
    updateResizeSaveTimer() {
        // Timer not in action
        if (this.resizingSaveTimer === -1)
            return;
        // Timeout for saving
        if (this.resizingSaveTimer > 0) {
            this.resizingSaveTimer--;
        }
        else if (this.resizingSaveTimer === 0) {
            this.app.save();
            this.resizingSaveTimer = -1;
        }
    }
    /**
     * Resizes the app with the initial dimensions.
     */
    applyInitDimensions() {
        this.app.resize(this.initDimensions.width);
        this.app.recreate(false);
        this.hasInitDimensionsApplied = true;
    }
    /**
     * Changes the dimensions of the app. Note that the width and height based should be equal (as of
     * right now, all apps have a square/1:1 sizing)
     * @param {Dimensions} newDimensions - the dimensions to set
     */
    onAppResized(newDimensions) {
        if (newDimensions.width !== newDimensions.height)
            console.warn("Width and height are not the same for this app! Width will be used");
        // If the app container hasn't yet been setup, ignore until it has
        if (newDimensions.width === 0)
            return;
        if (this.app.isSetup()) {
            this.app.resize(newDimensions.width);
            this.app.recreate(false);
            /* Start a timer to save in the future.
               This way, this only saves once after ~0.5s of non-scaling activity by the user, instead of
               every pixel change that occurs */
            this.resizingSaveTimer = 15;
        }
        else {
            // Save for applying when the app is setup
            this.initDimensions = newDimensions;
        }
    }
    /**
     * Hides the app from view
     */
    hideApp() {
        this.app.hide();
    }
    /**
     * @return {Dimensions} the current dimensions of the app
     */
    getCurrentAppDimensions() {
        return this.app.getCurrentDimensions();
    }
}
/**
 * Represents a theme for all apps to use for global styling and helper methods
 */
class Theme {
    /**
     * @constructor
     * @param {string} FONT_NAME - the name of the font associated with this theme
     * @param {NumberRange} mainAngleRange - the main range of angles to style components towards
     * @param {string} BASE_ID - the unique identifier that forms the basis of this theme's app's ids
     */
    constructor(FONT_NAME, mainAngleRange, BASE_ID) {
        this.FONT_NAME = FONT_NAME;
        this.mainAngleRange = mainAngleRange;
        this.BASE_ID = BASE_ID;
    }
    get MAIN_ANGLE_RANGE() {
        return this.mainAngleRange.clone();
    }
}
{};
/**
 * Represents a dual-colour scheme with a primary/default colour and a secondary/backup colour
 */
class ColourPriority {
    /**
     * Constructor
     * @param {string} primary - the primary colour
     * @param {string} secondary - the secondary colour
     */
    constructor(primary, secondary) {
        this.primary = primary;
        this.secondary = secondary;
    }
    invert() {
        return new ColourPriority(this.secondary, this.primary);
    }
    clone() {
        return new ColourPriority(this.primary, this.secondary);
    }
    asArray() {
        return [this.primary, this.secondary];
    }
    getPrimary() {
        return this.primary;
    }
    getSecondary() {
        return this.secondary;
    }
    /**
     * Returns {@link primary} if passed value is true, else returns {@link secondary}
     * @param {boolean} bool - the boolean value
     * @returns {string} the returned colour
     */
    getFromBool(bool) {
        return bool ? this.primary : this.secondary;
    }
}
/**
 * Represents an RGB colour
 */
class ColourRGB {
    constructor(r, g, b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }
    /**
     * Lightens the colour by the specified amount, where 0 has no effect and 255 has maximal effect
     * @param {number} amount - the amount to lighten
     * @return {ColourRGB} the new colour
     */
    lighten(amount) {
        return new ColourRGB(this.r + amount, this.g + amount, this.b + amount);
    }
    /**
     * Darkens the colour by the specified amount, where 0 has no effect and 255 has maximal effect
     * @param {number} amount - the amount to darken
     * @return {ColourRGB} the new colour
     */
    darken(amount) {
        return new ColourRGB(this.r - amount, this.g - amount, this.b - amount);
    }
    /**
     * Darkens the colour by multiplying each channel by the given amount
     * @param {number} amount - the amount to darken (between [0,1])
     * @return {ColourRGB} the new colour
     */
    darkMulti(amount) {
        return new ColourRGB(this.r * amount, this.g * amount, this.b * amount);
    }
    get R() {
        return this.r;
    }
    get G() {
        return this.g;
    }
    get B() {
        return this.b;
    }
    toString() {
        return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
    }
    /**
     * Converts a hexadecimal string into a ColourRGB or ColourRGBA instance
     * @param {string} colour - the hexadecimal string
     * @returns {ColourRGB | ColourRGBA} the colour instance
     */
    static hexToInstance(colour) {
        // Remove starting "#"
        colour = colour.substring(1);
        let channels = stringToArray(colour, 2).map(hexadecimalToDenary);
        // Convert alpha channel from (0-255) to (0-1)
        if (channels.length === 4)
            channels[3] /= 255;
        return ColourRGB.arrayToInstance(channels);
    }
    /**
     * Converts a rgb() or rgba() string into a ColourRGB or ColourRGBA instance
     * @param {string} colour - the rgb() or rgba() string
     * @returns {ColourRGB | ColourRGBA} the colour instance
     */
    static jsColourToInstance(colour) {
        let channels = colour.split(",").map(str => {
            let num = str.match(/[+-]?\d+(\.\d+)?/g)[0];
            return Number.parseFloat(num);
        });
        return ColourRGB.arrayToInstance(channels);
    }
    /**
     * Converts a an array of three or four integers between (0,255) into a ColourRGB or ColourRGBA instance
     * @param {number[]} array - the array of values for each channel. Four values should be provided to specify alpha
     * @returns {ColourRGB | ColourRGBA} the colour instance
     */
    static arrayToInstance(array) {
        if (array.length === 3)
            return new ColourRGB(array[0], array[1], array[2]);
        else if (array.length === 4)
            return new ColourRGBA(array[0], array[1], array[2], array[3]);
    }
    /**
     * Takes in an rgb/rgba or hex string and returns a ColourRGB or ColourRGBA object
     * @param {string} colour the rgb(), rgba() or hex string to convert
     * @returns {ColourRGB | ColourRGBA} the colour instance
     */
    static colourToInstance(colour) {
        if (colour.startsWith("rgb") || colour.startsWith("rgba"))
            return ColourRGB.jsColourToInstance(colour);
        else if (colour.startsWith("#"))
            return ColourRGB.hexToInstance(colour);
        throw new Error(colour + " is not a known colour format. Use hex, rgb() or rgba()");
    }
    // Colour instances
    static red() {
        return new ColourRGB(255, 0, 0);
    }
    static blue() {
        return new ColourRGB(0, 100, 255);
    }
    static grey() {
        return new ColourRGB(128, 128, 128);
    }
    static green() {
        return new ColourRGB(0, 255, 0);
    }
    static white() {
        return new ColourRGB(255, 255, 255);
    }
    static black() {
        return new ColourRGB(0, 0, 0);
    }
    static orange() {
        return new ColourRGB(255, 127, 0);
    }
    static yellow() {
        return new ColourRGB(255, 255, 0);
    }
    static purple() {
        return new ColourRGB(150, 0, 255);
    }
    static lightblue() {
        return new ColourRGB(0, 255, 255);
    }
}
class ColourScheme {
    /**
     * @constructor
     * @param {string} BASE - the default colour to use when for miscellaneous situations
     * @param {ColourPriority} ARC_BAR - the colouring for the arc bar. The primary is used for the
     * active part of the bar, and the secondary the passive
     * @param {ColourPriority} TICKS - the colouring of the ticks. The primary is used when the
     * current value surpasses a tick and vice versa for the secondary
     * @param {string} VALUE - the colour of the value text
     * @param {string} UNIT - the colour of the unit text
     * @param {string} NUMBERING - the colouring of the numbering system
     * @param {ColourPriority} POINTER - the colour of the pointer. The primary is used for the main
     * part of the pointer and the secondary as an accent
     * @param {string} GLASS - the colour of the glass (expected to be transparent)
     * @param {ColourPriority} GEAR - the colour of the gear. The primary is used for the default text
     * and the secondary for when the shifting should occur
     * @param {ColourPriority} PARKING_BRAKE - the colour of the parking brake. The primary is used for
     * when the parking brake is active and vice versa for the secondary
     * @param {string} BACKGROUND - the default colour to use for background coloring to apps
     */
    constructor(BASE, ARC_BAR, TICKS, VALUE, UNIT, NUMBERING, POINTER, GLASS, GEAR, PARKING_BRAKE, BACKGROUND) {
        this.BASE = BASE;
        this.ARC_BAR = ARC_BAR;
        this.TICKS = TICKS;
        this.VALUE = VALUE;
        this.UNIT = UNIT;
        this.NUMBERING = NUMBERING;
        this.POINTER = POINTER;
        this.GLASS = GLASS;
        this.GEAR = GEAR;
        this.PARKING_BRAKE = PARKING_BRAKE;
        this.BACKGROUND = BACKGROUND;
    }
    /**
     * @return {boolean} whether or not the background is transparent
     */
    isBackgroundTransparent() {
        return this.BACKGROUND.startsWith("rgba");
    }
    /**
     * Creates a colour scheme
     * @param {string} baseColour - the base/main colour
     * @param {string} background - the background colour
     * @param {ColourPriority} arcBar - the secondary colour of the arc bar
     * @return {ColourScheme} the colour scheme created
     */
    static createScheme(baseColour, background, arcBar) {
        let glass = "rgba(0,0,0,0.5)";
        let black = ColourRGB.black().toString();
        return new ColourScheme(baseColour, arcBar, new ColourPriority(black, baseColour), baseColour, baseColour, ColourRGB.white().toString(), new ColourPriority(baseColour, black), glass, new ColourPriority(baseColour, baseColour), new ColourPriority(baseColour, ColourRGB.grey().toString()), background);
    }
    /**
     * Creates a glass/transparent colour scheme
     * @param {ColourRGB} baseColour - the base/main colour
     * @return {ColourScheme} the colour scheme created
     */
    static createGlassLikeScheme(baseColour) {
        let arcBar = new ColourPriority(baseColour.toString(), "rgba(0,0,0,0.5)");
        return ColourScheme.createScheme(baseColour.toString(), "rgba(40,40,40,0.25)", arcBar);
    }
    /**
     * Creates a opaque colour scheme
     * @param {ColourRGB} baseColour - the base/main colour
     * @return {ColourScheme} the colour scheme created
     */
    static createStandardScheme(baseColour) {
        let arcBar = new ColourPriority(baseColour.toString(), ColourRGB.black().toString());
        return ColourScheme.createScheme(baseColour.toString(), "rgb(30,30,30)", arcBar);
    }
    /**
     * Creates and returns a list of default colour schemes
     * @return {ColourScheme[]} the list of colour schemes
     */
    static createSchemes() {
        let colours = [
            ColourRGB.orange(),
            ColourRGB.red(),
            ColourRGB.green(),
            ColourRGB.blue(),
            ColourRGB.yellow(),
            ColourRGB.lightblue(),
            ColourRGB.purple(),
            ColourRGB.white()
        ];
        let themes = [];
        for (let colour of colours) {
            themes.push(ColourScheme.createStandardScheme(colour));
            themes.push(ColourScheme.createGlassLikeScheme(colour));
        }
        return themes;
    }
}
class DecimalFormatter {
    constructor(numDecimals) {
        this.numDecimals = numDecimals;
    }
    /**
     * @override
     * @inheritDoc
     */
    format(unformatted) {
        return unformatted.toFixed(this.numDecimals);
    }
}
{};
class MinLengthFormatter {
    constructor(minDigits) {
        this.minDigits = minDigits;
    }
    /**
     * @override
     * @inheritDoc
     */
    format(unformatted) {
        return precede(Math.floor(unformatted), this.minDigits);
    }
}
/**
 * Represents a range of values between two values
 */
class NumberRange {
    /**
     * @constructor
     * The lower bound does not have to be smaller than the upper bound, and in which case, the
     * range is considered reversed
     * @param {number} lower - the lower bound of the range
     * @param {number} upper - the upper bound of the range
     */
    constructor(lower, upper) {
        this.lower = lower;
        this.upper = upper;
    }
    /**
     * Inverts the bounds such that the upper and lower bound swap
     * @returns {NumberRange}
     */
    invert() {
        return new NumberRange(this.upper, this.lower);
    }
    setLower(lower) {
        this.lower = lower;
    }
    setUpper(upper) {
        this.upper = upper;
    }
    getLower() {
        return this.lower;
    }
    getUpper() {
        return this.upper;
    }
    /**
     * Pads the bounds outwards by a set amount. This lowers the lower bound by the set amount and
     * increases the upper bound by the set amount
     * @param {number} amount - the amount to pad
     */
    pad(amount) {
        this.lower -= amount;
        this.upper += amount;
    }
    /**
     * Clamps a value between this number range, such that a value lesser than the lower bound
     * will be set to the lower bound and vice versa for the upper bound. A value which lies
     * within the bounds is not affected
     * @param {number} value - the value to clamp
     * @returns {number} the clamped value
     */
    clampTo(value) {
        return Math.min(Math.max(value, this.lower), this.upper);
    }
    /**
     * Returns the value of the specified distance along this number range.
     * Example: {lower=5, upper=10}.getLinearRatio(0.5) -> 7.5
     * @param distance - the distance along the range
     * @returns {number} the value at {distance} along this range
     */
    getLinearRatio(distance) {
        return this.lower + distance * (this.upper - this.lower);
    }
    /**
     * Returns the normalised distance along a value appears along this number range.
     * This is a the inverse function of <b>getLinearRatio()</b>.
     * Note that a value greater than or less than the bounds of this range will be clamped as
     * necessary, so that a value lower than the lower-bound returns 0, and a value higher than the
     * higher-bound returns 1.
     * Example: {lower=5, upper=10}.getLinearRatio(7.5) -> 0.5
     * @param value
     * @returns {number}
     */
    getNormLinearRatio(value) {
        value = this.clampTo(value);
        return (value + Math.abs(this.lower)) / this.getDifference();
    }
    /**
     * @returns {number} the differences between the two bounds
     */
    getDifference() {
        return this.upper - this.lower;
    }
    /**
     * Clones and returns a new range with the same bounds as this one
     * @returns {NumberRange} the cloned range
     */
    clone() {
        return new NumberRange(this.lower, this.upper);
    }
}
/**
 * A class representing a 2D vector
 */
class Vector {
    /**
     * @constructor
     * @param {number} x
     * @param {number} y
     */
    constructor(x = 0, y = 0) {
        this.array = [x || 0, y || 0];
    }
    /**
     * Copies a vector and returns its copy
     * @param {Vector} v - the vector to copy
     * @returns {Vector} the copied vector instance
     */
    static copy(v) {
        return new Vector(v.array[0], v.array[1]);
    }
    /**
     * Rotates this vector around the origin by a given angle amount.
     * This does not affect this vector and a new vector is returned
     * @param {number} angle - the angle (in radians)
     * @returns {Vector} the resultant vector
     */
    rotateAboutOrigin(angle) {
        let cos = Math.cos(angle);
        let sin = Math.sin(angle);
        return new Vector(this.x() * cos - this.y() * sin, this.x() * sin + this.y() * cos);
    }
    /**
     * Reverse the signs of all elements in the vector
     */
    negate() {
        this.array.forEach(e => -e);
    }
    /**
     *
     * @param {Vector} vector
     * @param {Vector|number} amount
     * @param {(a: number, b: number) => number} func
     * @returns {Vector}
     */
    static mapOperations(vector, amount, func) {
        let result = new Vector(vector.array[0], vector.array[1]);
        if (amount instanceof Vector) {
            result.array = result.array.map((v, i) => func(v, amount.array[i]));
        }
        else {
            result.array = result.array.map(e => func(e, amount));
        }
        return result;
    }
    /**
     * Adds a vector from another or a scalar value
     * @param {Vector} vector - the vector to be added to
     * @param {Vector|number} amount - the vector/scalar to add
     * @returns {Vector} - the resulting vector
     */
    static add(vector, amount) {
        return Vector.mapOperations(vector, amount, (e, a) => e + a);
    }
    /**
     * Subtracts a vector from another or a scalar value
     * @param {Vector} vector - the vector to be subtracted from
     * @param {Vector|number} amount - the vector/scalar to subtract
     * @returns {Vector} - the resulting vector
     */
    static sub(vector, amount) {
        return Vector.mapOperations(vector, amount, (e, a) => e - a);
    }
    /**
     * Multiples a vector with another or a scalar value
     * @param {Vector} vector - the vector to be subtracted from
     * @param {Vector|number} amount - the vector/scalar to subtract
     * @returns {Vector} - the resulting vector
     */
    static mult(vector, amount) {
        return Vector.mapOperations(vector, amount, (e, a) => e * a);
    }
    /**
     * Divides a vector by another or a scalar value
     * @param {Vector} vector - the vector to be divided by
     * @param {Vector|number} amount - the vector/scalar to divide with
     * @returns {Vector} - the resulting vector
     */
    static div(vector, amount) {
        return Vector.mapOperations(vector, amount, (e, a) => e / a);
    }
    /**
     * Returns whether this vector and another are the same
     * @param {Vector} v - the other vector
     * @returns {boolean} whether this vector and another are the same
     */
    isEqual(v) {
        return this.x() === v.x() && this.y() === v.y();
    }
    /**
     * Clones this vector and returns its copy
     * @returns {Vector} the cloned vector
     */
    clone() {
        return Vector.copy(this);
    }
    /**
     * Adds to this vector another vector from another or a scalar value
     * @param {Vector|number} amount - the vector/scalar to add
     */
    add(amount) {
        this.array = Vector.add(this, amount).array;
    }
    /**
     * Subtracts this vector by another or a scalar value
     * @param {Vector|number} amount - the vector/scalar to subtract
     */
    sub(amount) {
        this.array = Vector.sub(this, amount).array;
    }
    /**
     * Multiples this vector with another or a scalar value
     * @param {Vector|number} amount - the vector/scalar to subtract
     */
    mult(amount) {
        this.array = Vector.mult(this, amount).array;
    }
    /**
     * Divides this vector by another or a scalar value
     * @param {Vector|number} amount - the vector/scalar to divide with
     */
    div(amount) {
        this.array = Vector.div(this, amount).array;
    }
    /**
     * Normalises this vector
     */
    normalise() {
        let mag = this.mag();
        if (mag > 0)
            this.div(mag);
    }
    /**
     * Calculates and returns this vector's magnitude
     * @returns {number} the magnitude of this vector
     */
    mag() {
        return Math.sqrt(this.array.reduce((a, b) => Math.pow(a, 2) + Math.pow(b, 2)));
    }
    /**
     * Sets this vector's components to that of another's
     * @param {Vector} vector - the components to copy
     */
    set(vector) {
        this.array = this.array.map((_, i) => vector.array[i]);
    }
    addX(incX) {
        this.array[0] += incX;
    }
    addY(incY) {
        this.array[1] += incY;
    }
    x() {
        return this.array[0];
    }
    y() {
        return this.array[1];
    }
}
{};
{};
class Quantity {
    /**
     * @constructor
     * @param {UnitConversion} unitConversion - the conversion unit for converting values to their respective unit
     * @param {Formatter<any, string>} formatter - the formatter to apply formatting to the converted unit
     */
    constructor(unitConversion, formatter) {
        this.unitConversion = unitConversion;
        this.formatter = formatter;
    }
    /**
     * @override
     * Converts a value (in ms^-1) to the selected unit
     * @param {number} value - the value (in ms^-1) to convert
     * @returns {ConvertedUnit} the converted number, in string format and the units it is in
     */
    convert(value) {
        let result = this.unitConversion.convert(value);
        return {
            value: this.formatter.format(result),
            units: this.unitConversion.getUnitName()
        };
    }
    /**
     * @returns {ConvertableUnit} the current unit being used
     */
    getUnit() {
        return this.unitConversion.getUnit();
    }
    /**
     * @returns {number} the index of the current unit being used
     */
    getUnitIndex() {
        return this.unitConversion.getIndex();
    }
    /**
     * @returns {string} the name of the current unit being used
     */
    getUnitName() {
        return this.unitConversion.getUnitName();
    }
    /**
     * Selects the next unit, wrapping around to the first unit if it is at the last unit currently
     */
    cycleUnit() {
        this.unitConversion.cycleUnit();
    }
    /**
     * Sets the selected unit
     * @param {number} index - the index of the new unit
     * @throws RangeError
     */
    setUnitIndex(index) {
        this.unitConversion.setSelected(index);
    }
    /**
     * Sets/changes the formatter object to the given one
     * @param {Formatter<any, any>} formatter - the new formatter to use
     */
    changeFormatter(formatter) {
        this.formatter = formatter;
    }
    /**
     * @returns {ConvertableUnit[]} a list of speed units and their conversion factors, relative to ms^-1
     */
    static speed() {
        return [
            { name: "mph", conversionFactor: 2.237 },
            { name: "kph", conversionFactor: 3.600 },
            { name: "kt", conversionFactor: 1.943 },
            { name: "m/s", conversionFactor: 1.000 }
        ];
    }
    /**
     * @returns {ConvertableUnit[]} a list of boost units and their conversion factors, relative to kPa
     */
    static boost() {
        return [
            { name: "inHg", conversionFactor: 0.295 },
            { name: "bar", conversionFactor: 0.010 },
            { name: "psi", conversionFactor: 0.145 },
            { name: "kPa", conversionFactor: 1.000 }
        ];
    }
}
class UnitConversion {
    /**
     * @constructor
     * @param {ConvertableUnit[]} quantity - the quantity that will be returned
     * @param {number} selected - the currently selected unit inside the quantity instance. Defaults to 0
     */
    constructor(quantity, selected = 0) {
        this.quantity = quantity;
        this.selected = selected;
    }
    /**
     * @override
     * Converts a value (in ms^-1) to the selected unit
     * @param {number} value - the value (in ms^-1) to convert
     * @returns {number} the converted number
     */
    convert(value) {
        let unit = this.quantity[this.selected];
        return value * unit.conversionFactor;
    }
    /**
     * Selects the next unit, wrapping around to the first unit if it is at the last unit currently
     */
    cycleUnit() {
        this.selected = wrapAdd(this.selected, 1, this.quantity.length);
    }
    /**
     * Sets the selected unit
     * @param {number} selected - the index of the selected unit
     * @throws RangeError
     */
    setSelected(selected) {
        if (selected < 0 || selected >= this.quantity.length)
            throw RangeError("Index must be > 0 and < the number of units");
        this.selected = selected;
    }
    /**
     * @returns {number} the index of the currently selected unit
     */
    getIndex() {
        return this.selected;
    }
    /**
     * @returns {string} the name of the currently selected unit
     */
    getUnitName() {
        return this.quantity[this.selected].name;
    }
    /**
     * @returns {ConvertableUnit} the unit currently in use
     */
    getUnit() {
        return this.quantity[this.selected];
    }
    /**
     * Converts a value (in ms^-1) to the selected unit
     * @param {ConvertableUnit} unit - the selected unit to convert into
     * @param {number} value - the value (in ms^-1) to convert
     * @returns {number} the converted number in {@link unit} units
     */
    static convert(unit, value) {
        return value * unit.conversionFactor;
    }
}
/**
 * Applies one or more mixins onto a base class, mimicking multiple inheritance
 * @param {any} derivedCtor - the base class
 * @param {any[]} constructors - the list of mixins
 */
function applyMixins(derivedCtor, constructors) {
    constructors.forEach((baseCtor) => {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach((name) => {
            Object.defineProperty(derivedCtor.prototype, name, Object.getOwnPropertyDescriptor(baseCtor.prototype, name) || Object.create(null));
        });
    });
}
class CanDraw {
    setCtx(ctx) {
        this.ctx = ctx;
        return this;
    }
}
class HasCentre {
    setCentre(value) {
        this.centre = value;
        return this;
    }
}
class HasColourScheme {
    setColourScheme(colourScheme) {
        this.colourScheme = colourScheme;
        return this;
    }
}
class HasFont {
    setFont(font) {
        this.font = font;
        return this;
    }
}
class HasFontName {
    setFontName(fontName) {
        this.fontName = fontName;
        return this;
    }
}
class HasRadius {
    setRadius(radius) {
        this.radius = radius;
        return this;
    }
}
class HasText {
    setText(text) {
        this.text = text;
        return this;
    }
}
{};
/**
 * Represents a style which can be applied to shapes and objects being drawn on a canvas
 */
class Style {
    /**
     * @constructor
     * @param {string | CanvasGradient} STROKE_COLOUR - the colour of the stroke
     * @param {number} LINE_WIDTH - the width of the line/outline
     * @param {boolean} [FILLED] - whether the shape will be filled (fill colour will be the same as stroke
     * colour). Defaults to false
     */
    constructor(STROKE_COLOUR, LINE_WIDTH, FILLED = false) {
        this.STROKE_COLOUR = STROKE_COLOUR;
        this.LINE_WIDTH = LINE_WIDTH;
        this.FILLED = FILLED;
    }
    /**
     * Returns a Style object of the specified colour that has a 1px stroke and is filled
     * @param {string} strokeColour - the colour of the stroke. Can be either RGB/RGBA or colour
     * name
     * @returns {Style} the style object created
     */
    static unitStrokeFill(strokeColour) {
        return new Style(strokeColour, 1, true);
    }
    /**
     * Returns a Style object that is filled with the specified colour and that does not have a
     * stroke applied to it
     * @param {string} fillColour - the fill colour. Can be either RGB/RGBA or colour name
     * @returns {Style} the style object created
     */
    static noStrokeFill(fillColour) {
        return new Style(fillColour, 0, true);
    }
    /**
     * @return {Style} a Style object with black colour, 0 stroke width and unfilled
     */
    static default() {
        return new Style("black", 0, false);
    }
    changeColour(newColour) {
        return new Style(newColour, this.LINE_WIDTH, this.FILLED);
    }
    changeLineWidth(newLineWidth) {
        return new Style(this.STROKE_COLOUR, newLineWidth, this.FILLED);
    }
    changeIsFilled(isFilled) {
        return new Style(this.STROKE_COLOUR, this.LINE_WIDTH, isFilled);
    }
    /**
     * @override
     * @inheritDoc
     */
    setVars(ctx) {
        if (this.FILLED) {
            ctx.fillStyle = this.STROKE_COLOUR;
        }
        else {
            ctx.strokeStyle = this.STROKE_COLOUR;
            ctx.lineWidth = this.LINE_WIDTH;
        }
    }
    /**
     * @Override
     * @inheritDoc
     */
    apply(ctx) {
        this.setVars(ctx);
        if (this.FILLED)
            ctx.fill();
        else
            ctx.stroke();
    }
}
class AbstractGradient {
    /**
     * @constructor
     * @param {string[]} colourStops - the colours in the gradient
     */
    constructor(colourStops) {
        this.colourStops = colourStops;
    }
    /**
     * Creates a set of ColourStop objects from the given colours where each colour is equally spaced, in the given order
     * @param {string[]} colours - the colours to make into ColourStops
     * @returns {ColourStop[]} the evenly distributed colours
     */
    static distributeEvenly(colours) {
        return colours.map((colour, i, array) => {
            return { colour: colour, offset: i / array.length };
        });
    }
    /**
     * Initialises the CanvasGradient and returns the completed gradient with all colours added to iut
     * @param {CanvasRenderingContext2D} ctx - the object to use to create the gradient
     * @returns {CanvasGradient} the gradient created
     */
    createGradient(ctx) {
        let grad = this.initGradient(ctx);
        this.colourStops.forEach(colourStop => grad.addColorStop(colourStop.offset, colourStop.colour));
        return grad;
    }
}
/**
 * Represents a font for text displaying
 */
class Font {
    /**
     * @constructor
     * @param {string} FONT_NAME - the font name
     * @param {number} FONT_SIZE - the font size
     * @param {boolean} IS_CENTRED - whether the text is centre
     */
    constructor(FONT_NAME, FONT_SIZE, IS_CENTRED) {
        this.FONT_NAME = FONT_NAME;
        this.FONT_SIZE = FONT_SIZE;
        this.IS_CENTRED = IS_CENTRED;
    }
    /**
     * Applies the font to a canvas object so that the next time text is drawn on this canvas, this font styling is
     * applied
     * @param {CanvasRenderingContext2D} ctx
     */
    apply(ctx) {
        ctx.textAlign = this.IS_CENTRED ? "center" : "left";
        ctx.textBaseline = this.IS_CENTRED ? "middle" : "alphabetic";
        ctx.font = this.FONT_SIZE + "px " + this.FONT_NAME;
    }
    /**
     * Returns the width and height of the font when rendering a text character
     * <b>Note: this will only be valid if the font is monospaced</b>
     * @param {CanvasRenderingContext2D} ctx - a canvas for trial rendering
     * @param {string} text - the text to render (should be of length 1)
     * @return {Vector} the width/height of the font when rending the passed text
     */
    getFontDimensions(ctx, text) {
        this.apply(ctx);
        return new Vector(ctx.measureText(text).width, ctx.measureText(text).width);
    }
    /**
     * Returns the centre offset vector for rendering a particular piece of text to a position, such
     * that it is fully centred.
     * <b>Note: this will only work if the font is monospaced</b>
     * @param {CanvasRenderingContext2D} ctx - a canvas for trial rendering
     * @param {string} text - the text to get the centre offset vector of
     * @return {Vector} the centre offset vector
     */
    getCentreFix(ctx, text) {
        let dims = this.getFontDimensions(ctx, text);
        dims.div(2);
        if (text.length === 1)
            return new Vector(-dims.x(), dims.y());
        // Height is the same as single characters
        else
            return new Vector(-dims.x(), this.getFontDimensions(ctx, "0").x() / 2);
    }
}
{};
{};
/**
 * Returns the next value in an array, given a current value, looping around to the start if
 * the value is at the end of the array
 * @param {T[]} array - the array of elements
 * @param {T} selected - the currently selected value
 * @template T
 */
function getNextElement(array, selected) {
    // Find next index, looping back around to 0 if necessary
    let index = array.indexOf(selected);
    index = (index + 1) % array.length;
    return array[index];
}
/**
 * Returns a list of numbers, going from {@link startValue} to {@link endValue}, generating in
 * total {@link totalNumbers} numbers
 * @param {number} startValue - the first value
 * @param {number} endValue - the last value
 * @param {number} totalNumbers - the number of numbers to return
 * @param {number} [decimalPlaces] - the number of decimal places each number can have. Defaults
 * to 0
 * @returns {number[]} the numbers generated
 */
function generateEquidistantValues(startValue, endValue, totalNumbers, decimalPlaces = 0) {
    let array = [];
    let range = new NumberRange(startValue, endValue);
    for (let i = 0; i < totalNumbers; i++) {
        let perc = i / (totalNumbers - 1);
        let number = truncate(range.getLinearRatio(perc), decimalPlaces);
        array.push(number);
    }
    return array;
}
/**
 * Creates an arithmetic series.
 * More formally, it generates an array of form [a, a+d, a+2d, ..., a+(n-1)d] where
 * <b>a=start-term</b>, <b>d=gap-between-terms</b> and <b>n=number-of-terms</b>
 * Examples:
 *  (  0,  1, 5) -> [0,1,2,3,4]
 *  (  2,  5, 3) -> [2,7,12]
 *  (-10, 15, 4) -> [-10,5,20,45]
 * @param {number} start - the starting term
 * @param {number} gap - the gap between two terms
 * @param {number} numTerms - the number of terms to generate
 * @return {number[]} the series generated
 */
function arithmeticSeries(start, gap, numTerms) {
    return Array.from({ length: numTerms }, (_, i) => start + i * gap);
}
/**
 * Partitions an array by keeping all elements whose index exist in the arithmetic sequence
 * [0,d,2d,...] and returns it. The original array is not affected
 * Examples:
 *  ([0,1,2,3,4,5,6,7,8,9], 2) -> [0,2,4,6,8]
 *  ([0,1,2,3,4,5,6,7,8,9], 3) -> [0,3,6,9]
 *  ([0,1,2,3,4,5,6,7,8,9], 4) -> [0,4,8]
 * @param {number[]} arr - the array to partition
 * @param {number} gapInTerms - the index 'gap' between terms
 * @returns {number[]} the partitioned array
 */
function partition(arr, gapInTerms) {
    return arr.filter((_, i) => i % gapInTerms === 0);
}
/**
 * Converts a string to an array.
 * By default, an array of each character is returned, however the {@link groupingSize} parameter allows for grouping by
 * a different size.
 * Examples:
 *  ("abcde"    ) => ["a", "b", "c", "d", "e"]
 *  ("abcde",  2) => ["ab", "cd", "e"]
 *  ("abcde",  4) => ["abcd", "e"]
 *  ("abcde", 10) => ["abcde"]
 * @param {string} string
 * @param {number} groupingSize
 * @returns {string[]}
 */
function stringToArray(string, groupingSize = 1) {
    return string.match(new RegExp('.{1,' + groupingSize + '}', 'g'));
}
/**
 * Creates and returns a numbering system with numbers arranged in an arc
 * @param {number} radius - the radius of the arc
 * @param {number} fontSize - the font size for the numbers
 * @param {string} fontName - the name of the font to use
 * @param {[number]} numbers - the list of numbers to display
 * @param {Vector} centre - the centre point
 * @param {NumberRange} arcRange - the arc range the numbers will fit to
 * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
 * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
 * @return {ArcNumbering} the numbering system created
 */
function createBasicNumbering(radius, fontSize, fontName, numbers, centre, arcRange, ctx, drawStartAndEndNumbers = true) {
    let font = new Font(fontName, fontSize, true);
    return new ArcNumbering(centre, radius, numbers, arcRange, font, ctx, drawStartAndEndNumbers);
}
/**
 * Returns the coordinates of a point on a circle, whose centre is the origin (0,0)
 * @param {number} radius - the radius of the circle
 * @param {number} angle - the angle along the circle the point is
 * @returns {Vector} the point
 */
function getCircularPoint(radius, angle) {
    return new Vector(radius * Math.cos(angle), radius * Math.sin(angle));
}
/**
 * Returns the coordinates of a point on a circle, whose centre is specified
 * @param {Vector} relCentre - the centre of the circle to rotate around
 * @param {number} radius - the radius of the circle
 * @param {number} angle - the angle along the circle the point is
 * @returns {Vector} the point
 */
function getRelCircularPoint(relCentre, radius, angle) {
    return Vector.add(relCentre, getCircularPoint(radius, angle));
}
/**
 * Adds two numbers together, wrapping back to the start if this the result reaches/exceeds the wrapping value.
 * Example: (3, 4, 5) => 2
 * @param {number} number1 - the first number
 * @param {number} number2 - the first number
 * @param {number} wrapPoint - the wrapping point
 */
function wrapAdd(number1, number2, wrapPoint) {
    return (number1 + number2) % wrapPoint;
}
/**
 * Returns a new NumberRange which represents the remaining circle, given the current 'portion' of that circle, in
 * NumberRange form.
 * @param {NumberRange} angles - the 'portion' of that circle
 * @returns {NumberRange} the remaining 'portion' of that circle
 */
function getRemainingCircle(angles) {
    let upper = angles.getUpper();
    return new NumberRange(upper, upper + angles.getLower());
}
/**
 * Rounds a number to a specified amount of significant figures
 * @param {number} number - the number to round
 * @param {number} sigFigs - the number of significant figures to round to
 * @returns {number} the rounded number to the specified amount of significant figures
 */
function sigFigs(number, sigFigs) {
    let prec = Number.parseFloat(number.toString()).toPrecision(sigFigs);
    return Number.parseFloat(prec);
}
/**
 * Adds in 0's preceding the number until the number of digits is equal to what is specified.
 * Note that if the number of digits requested is <= the number of digits already in the number
 * passed, the resultant string is simply that number passed in string form.
 * Examples:
 *    ( 24, 3) -> "024"
 *    (260, 5) -> "00260"
 *    (454, 3) -> "454"
 *    (999, 2) -> "999"
 * @param {number} number - the number to modify
 * @param {number} numDigits - the number of digits the resultant number must contain
 * @return {string} the resultant number, in string form
 */
function precede(number, numDigits) {
    let numStr = number.toString();
    let length = numStr.length;
    if (length >= numDigits)
        return numStr;
    return "0".repeat(numDigits - length) + numStr;
}
/**
 * Truncates a number to an amount of decimal places
 * @param {number} number - the number to truncate
 * @param {number} decimalPlaces - the number of decimal place to truncate to
 * @returns {number} the truncated number
 */
function truncate(number, decimalPlaces) {
    let truncate = Number.parseFloat(number.toString()).toFixed(decimalPlaces);
    return Number.parseFloat(truncate);
}
/**
 * Returns the last number of digits of a number. If the number of digits passed is more than the number of digits in
 * the number, then the whole number is returned as is.
 * Examples:
 *   (123, 2) => 23
 *   (123, 5) => 123
 *   (123, 1) => 3
 * @param {number} number - the number to get the last digits of
 * @param {number} numDigits - the number of last digits to return
 * @returns {number} the last {@link numDigits} of {@link number}
 */
function lastDigitsOf(number, numDigits) {
    let numStr = number.toString();
    let length = numStr.length;
    if (length >= numDigits)
        return Number.parseFloat(numStr.substring(length - numDigits));
    return number;
}
/**
 * Converts a single hex string character to its equivalent denary value.
 * Note that if a letter is passed, any capitalisation is ignored.
 * @param {string} hex - the hex charter to convert. Must be (0, 9) or (A-F)
 * @returns {number}
 * @throws {Error} if the digit passed is not a hexadecimal digit or more than one character is passed in the string
 */
function hexDigitValue(hex) {
    hex = hex.toUpperCase();
    if (hex.length !== 1)
        throw new Error("Hex digit must be a single character");
    if (Number.isInteger(Number(hex)))
        return Number.parseFloat(hex);
    switch (hex) {
        case "A": return 10;
        case "B": return 11;
        case "C": return 12;
        case "D": return 13;
        case "E": return 14;
        case "F": return 15;
    }
    throw new Error("Digit is not a hex character");
}
/**
 * Converts a hexadecimal string into its denary value
 * @param {string} hex - the hex string to convert
 * @returns {number} the denary value of {@link hex}
 */
function hexadecimalToDenary(hex) {
    let str = hex
        .toString()
        .replace("#", "");
    return stringToArray(str)
        .map((digit, index, arr) => hexDigitValue(digit) * Math.pow(16, arr.length - 1 - index))
        .reduce((prev, curr) => prev + curr);
}
/**
 * @template T
 * T is the type of pointer than can be created by this builder
 */
class AbstractPointerBuilder {
    constructor() {
        this.startAngle = -Math.PI / 2;
        // The scale of the minor part of the pointer
        this.minorScale = 0.6;
    }
    setStartAngle(value) {
        this.startAngle = value;
        return this;
    }
    setCentre(centre) {
        this.centre = centre.clone();
        return this;
    }
    setWidth(width) {
        this.width = width;
        return this;
    }
    setLength(length) {
        this.length = length;
        return this;
    }
    setValueRange(valueRange) {
        this.valueRange = valueRange.clone();
        return this;
    }
    setPointerRange(pointerRange) {
        this.pointerRange = pointerRange.clone();
        return this;
    }
    setMinorScale(minorScale) {
        this.minorScale = minorScale;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        this.setWidth(builder.width);
        this.setCentre(builder.centre);
        this.setLength(builder.length);
        this.setMinorScale(builder.minorScale);
        this.setPointerRange(builder.pointerRange);
        this.setStartAngle(builder.startAngle);
        this.setValueRange(builder.valueRange);
        return this;
    }
}
{};
/**
 * Represents a vehicle's engine
 */
class Engine {
    /**
     * @constructor
     * @param MAX_RPM - The maximum engine RPM (as gotten from the vehicles stats)
     * @param REDLINE_RPM - The next thousand from the maximum RPM, treated as the absolute maximum RPM
     */
    constructor(MAX_RPM, REDLINE_RPM) {
        this.MAX_RPM = MAX_RPM;
        this.REDLINE_RPM = REDLINE_RPM;
        this.currRPM = 0;
    }
    /**
     * Sets the current RPM
     * @param {number} rpm  - the RPM to set
     */
    setCurrRPM(rpm) {
        if (typeof rpm !== "undefined")
            this.currRPM = rpm;
    }
    /**
     * @return {number} the current RPM
     */
    getCurrentRPM() {
        return this.currRPM;
    }
    /**
     * @return {number} the maximum RPM
     */
    getMaxRPM() {
        return this.MAX_RPM;
    }
    /**
     * @return {number} the redline RPM
     */
    getRedLineRPM() {
        return this.REDLINE_RPM;
    }
    /**
     * @return {number} the redline RPM divided by 1000
     */
    getRedlineThousand() {
        return this.REDLINE_RPM / 1000;
    }
    /**
     * @returns {number} the ratio of current RPM to redline RPM
     */
    getCurrentRPMRatio() {
        return this.currRPM / this.REDLINE_RPM;
    }
    /**
     * @returns {number} the ratio of maximum engine RPM and the redline (next thousand) RPM
     */
    getRedlineRPMRatio() {
        return this.MAX_RPM / this.REDLINE_RPM;
    }
    /**
     * @returns {boolean} whether to shift up to the next gear
     */
    shouldShiftUp() {
        return this.currRPM >= this.MAX_RPM - Engine.SHIFT_TOL;
    }
}
// The tolerance between when to shift and the maximum engine RPM
Engine.SHIFT_TOL = 200;
/**
 * Represents a gearbox
 */
class Gearbox {
    /**
     * Constructor
     * @param {number | string} gear - the currently selected gear
     */
    constructor(gear) {
        this.gear = gear;
    }
    /**
     * Sets the current gear
     * @param {number | string} gear - the gear to set
     */
    setGear(gear) {
        this.gear = gear;
    }
    /**
     * @return {string} Returns the string name of the gear currently selected on this gearbox
     */
    getGearName() {
        return typeof this.gear === "string" ? this.gear : Gearbox.getGearNameManual(this.gear);
    }
    /**
     * @returns {string | number} the gear number
     */
    getGear() {
        return this.gear;
    }
    /**
     * Converts a gear number into its string name.
     * Mapping:
     *   < -1  -> R2...R(|n|+1)
     *   = -1  -> R
     *   =  0  -> N
     *  >=  1  -> 1...n
     * @param {number} gear - the gear number
     * @returns {string} the string name for this gear number
     */
    static getGearNameManual(gear) {
        let gearName;
        if (gear === 0) {
            gearName = "N";
        }
        else if (gear < 0) {
            // Add index of reverse gear if more than one exists
            if (gear < -1)
                gearName = "R" + Math.abs(gear);
            else
                gearName = "R";
        }
        else {
            gearName = gear.toString();
        }
        return gearName;
    }
}
/**
 * Represents a turbo
 */
class Turbo {
    /**
     * @constructor
     * @param {number} MAX_BOOST - the maximum boost this turbo can generate
     */
    constructor(MAX_BOOST) {
        this.MAX_BOOST = MAX_BOOST;
        this.currBoost = 0;
    }
    /**
     * Sets the current boost value
     * @param {number} boost - the value to set
     */
    setBoost(boost) {
        if (typeof boost !== "undefined")
            this.currBoost = boost;
    }
    /**
     * @returns {number} the maximum boost value
     */
    getMaxBoost() {
        return this.MAX_BOOST;
    }
    /**
     * @returns {number} the current boost value
     */
    getBoost() {
        return this.currBoost;
    }
    /**
     * @returns {number} the normalised boost value
     */
    getNormBoost() {
        // Normalise from range [-1,1] to [0,1]
        return (this.currBoost / this.MAX_BOOST + 1) / 2;
    }
}
/**
 * Represents an object that can be moved
 */
class Moveable extends Drawable {
    /**
     * @constructor
     * @param {Vector} [centre] - the centre point of the object. Defaults to (0,0)
     */
    constructor(centre = new Vector()) {
        super();
        this.centre = centre;
    }
    /**
     * @param {Vector} centre - the new centre to set the object to
     */
    setCentre(centre) {
        this.centre = centre;
    }
}
/**
 * Represents a forced induction app that can display data from a vehicle
 */
class AbstractBoostApp extends AbstractBaseApp {
    /**
     * @constructor
     * @param {Theme} theme - the theme of this app
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     * @param {Newable<AbstractPressureGaugeBuilder>} GaugeBuilder - the gauge builder class to use when creating pressure
     * gauge components
     * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
     */
    constructor(theme, baseRadius, document, bngApi, GaugeBuilder, Background) {
        super(theme, baseRadius, document, bngApi, GaugeBuilder, Background);
        this.turbo = null;
        this.gauge = null;
        this.pressure = null;
    }
    /**
     * @override
     * @inheritDoc
     * @param {number} data - the maximum boost of the vehicle to initialise with
     */
    sendInitialVehicleData(data) {
        this.turbo = new Turbo(data);
        this.createComponents();
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.turbo.setBoost(data.boost);
        this.gauge.update(this.turbo);
        this.pressure.update(data.boost);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        let ctx = this.canvas.get2DContext();
        this.gauge.draw(ctx);
        this.pressure.draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    createComponents() {
        this.gauge = this.createGauge();
        this.pressure = this.createPressureReadout();
    }
    /**
     * @override
     * @inheritDoc
     */
    cycleUnit() {
        this.pressure.cycleUnit();
        this.updateGaugePrecision();
    }
    /**
     * @override
     * @inheritDoc
     */
    getIndexOfCurrUnit() {
        return this.pressure.getIndexOfCurrent();
    }
    /**
     * @override
     * @inheritDoc
     */
    setIndexOfCurrUnit(index) {
        this.pressure.setIndexOfCurrent(index);
        this.updateGaugePrecision();
    }
    /**
     * @override
     * @inheritDoc
     */
    getQuantityInstance() {
        if (this.pressure)
            return this.pressure.getQuantity();
        else
            return this.getNewQuantityInstance();
    }
    /**
     * @override
     * @inheritDoc
     */
    setDefaultGaugeBuilderValues(builder) {
        return super.setDefaultGaugeBuilderValues(builder)
            .setMaxBoost(this.getMaxBoostFromTurbo())
            .setMaxBoostConverted(this.getMaxBoostFromTurboConverted());
    }
    /**
     * @override
     * @inheritDoc
     */
    isSetup() {
        return this.turbo !== null;
    }
    /**
     * @override
     * @inheritDoc
     */
    getId() {
        return this.theme.BASE_ID + "FI";
    }
    /**
     * Updates the gauge's precision. Should be called whenever the unit on the pressure gauge changes
     */
    updateGaugePrecision() {
        let quantity = this.pressure.getQuantity();
        let newDps = this.getGaugePrecision(quantity.getUnit());
        quantity.changeFormatter(new DecimalFormatter(newDps));
    }
    /**
     * Returns the number of decimal places that will be used for displaying any relevant values on
     * the pressure gauge
     * @param {ConvertableUnit} unit - the unit to use
     * @return {number} the number of decimal places
     */
    getGaugePrecision(unit) {
        return UnitConversion.convert(unit, this.turbo.getMaxBoost()) > 10 ? 0 : 1;
    }
    /**
     * @return {Quantity} a new Unit instance for the pressure displayer
     */
    getNewQuantityInstance() {
        let unit = new UnitConversion(Quantity.boost());
        let formatter = new DecimalFormatter(this.getGaugePrecision(unit.getUnit()));
        return new Quantity(unit, formatter);
    }
    /**
     * @returns {number} the maximum boost from the turbo
     * @protected
     */
    getMaxBoostFromTurbo() {
        return this.turbo.getMaxBoost();
    }
    /**
     * @returns {number} the maximum boost from the turbo, converted to the current units from {@link getQuantityInstance}
     * @protected
     */
    getMaxBoostFromTurboConverted() {
        let boost = this.getMaxBoostFromTurbo();
        let quantity = this.getQuantityInstance();
        return Number.parseFloat(quantity.convert(boost).value);
    }
    /**
     * Updates a boost app from a stream update event
     * @param {any} streams - the streams to update from
     * @param {AbstractBoostApp} app - the tachometer app to update
     */
    static streamsUpdate(streams, app) {
        if (!app || !streams || !streams.forcedInductionInfo)
            return;
        let forcedInductionInfo = streams.forcedInductionInfo;
        // Perform first time setup
        if (app.turbo === null) {
            app.sendInitialVehicleData(forcedInductionInfo.maxBoost);
            app.load();
        }
        else {
            app.update({ boost: forcedInductionInfo.boost });
            app.draw();
        }
    }
}
/**
 * Represents a base Tachometer modded app
 */
class AbstractTachometerApp extends AbstractBaseApp {
    /**
     * @constructor
     * @param {Theme} theme - the theme of this app
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     * @param {Newable<AbstractRPMGaugeBuilder>} GaugeBuilder - the gauge builder class to use when creating RPM gauge
     * components
     * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
     */
    constructor(theme, baseRadius, document, bngApi, GaugeBuilder, Background) {
        super(theme, baseRadius, document, bngApi, GaugeBuilder, Background);
        this.engine = null;
        this.gearbox = null;
        this.RPMGauge = null;
        this.indicators = null;
        this.pBrake = null;
        this.speedo = null;
        this.gear = null;
        this.fuelGauge = null;
        this.tempGauge = null;
        this.throttleGauge = null;
        this.brakeGauge = null;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        let ctx = this.canvas.get2DContext();
        this.getComponents().forEach(component => component.draw(ctx));
    }
    /**
     * @override
     * @inheritDoc
     */
    cycleUnit() {
        this.speedo.cycleUnit();
    }
    /**
     * @override
     * @inheritDoc
     */
    createComponents() {
        this.RPMGauge = this.createGauge();
        this.speedo = this.createSpeedoComponent();
        this.indicators = this.createIndicatorsComponent();
        this.pBrake = this.createPBrakeComponent();
        this.gear = this.createGearComponent();
        this.createBarCollection();
    }
    /**
     * @override
     * @inheritDoc
     */
    getIndexOfCurrUnit() {
        return this.speedo.getIndexOfCurrent();
    }
    /**
     * @override
     * @inheritDoc
     */
    setIndexOfCurrUnit(index) {
        this.speedo.setIndexOfCurrent(index);
    }
    /**
     * @override
     * @inheritDoc
     */
    setDefaultGaugeBuilderValues(builder) {
        return super.setDefaultBuilderValues(builder)
            .setEngine(this.engine);
    }
    /**
     * Creates the oil, fuel, brake and throttle gauges
     */
    createBarCollection() {
        let builder = this.createBarCollectionBuilder();
        this.brakeGauge = builder.buildBrakeBar();
        this.throttleGauge = builder.buildThrottleBar();
        this.tempGauge = builder.buildTempBar();
        this.fuelGauge = builder.buildFuelBar();
    }
    /**
     * Returns the list of components, treated as a list of AbstractDataDisplayer.
     * Note the order of components returned are in the order of being drawn. Should this be different
     * in a subclass, it is expected that that subclass will override this method
     * @returns {AbstractDataDisplayer[]}
     */
    getComponents() {
        return [
            this.fuelGauge,
            this.tempGauge,
            this.throttleGauge,
            this.brakeGauge,
            this.RPMGauge,
            this.speedo,
            this.gear,
            this.indicators,
            this.pBrake
        ];
    }
    /**
     * @override
     * @inheritDoc
     */
    sendInitialVehicleData(data) {
        this.engine = new Engine(data.maxRPM, data.redlineRPM);
        // Can use any initial value here as it will be overwritten later; default to neutral for now
        this.gearbox = new Gearbox(0);
        // Now safe to generate components
        this.createComponents();
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.engine.setCurrRPM(data.currRPM);
        this.gearbox.setGear(data.gear);
        this.pBrake.update(data.pBrakeEnabled);
        this.speedo.update(data.speed);
        this.RPMGauge.update(this.engine);
        this.fuelGauge.update(data.fuel);
        this.tempGauge.update(data.temp);
        this.brakeGauge.update(data.brake);
        this.throttleGauge.update(data.throttle);
        this.gear.update({
            gearbox: this.gearbox,
            shouldShift: this.engine.shouldShiftUp()
        });
        this.indicators.update({
            left: data.indicators.left,
            right: data.indicators.right
        });
        this.bgNeedsRedraw = this.background.updateLighting(this.getLightColour(data.lightState));
    }
    /**
     * @override
     * @inheritDoc
     */
    getQuantityInstance() {
        if (this.speedo)
            return this.speedo.getQuantity();
        else
            return this.getNewUnitInstance();
    }
    /**
     * @override
     * @inheritDoc
     */
    isSetup() {
        return this.engine !== null;
    }
    /**
     * @override
     * @inheritDoc
     */
    getId() {
        return this.theme.BASE_ID + "T";
    }
    /**
     * @return {Quantity} a new Quantity instance for the speedometer. This converts only to whole, integer values
     */
    getNewUnitInstance() {
        let units = new UnitConversion(Quantity.speed());
        return new Quantity(units, new DecimalFormatter(0));
    }
    /**
     * Updates the app via the streams system
     * @param {any} electrics - the electrics stream
     * @param {any} engineInfo - the engineInfo stream
     */
    updateFromStreams(electrics, engineInfo) {
        this.update({
            pBrakeEnabled: electrics.parkingbrake_input === 1,
            temp: electrics.watertemp,
            fuel: engineInfo[11] / engineInfo[12],
            currRPM: engineInfo[4],
            speed: electrics.wheelspeed,
            gear: engineInfo[5],
            throttle: electrics.throttle_input,
            brake: electrics.brake_input,
            indicators: {
                left: electrics.signal_L,
                right: electrics.signal_R
            },
            lightState: AbstractTachometerApp.getLightState(electrics)
        });
    }
    /**
     * Returns the colour of the lights, given their state integer value
     * @param {number} lightState - the light state
     * @return {string} the light colour
     */
    getLightColour(lightState) {
        return AbstractTachometerApp.getLightColour(lightState);
    }
    /**
     * Updates a tachometer app from a stream update event
     * @param {any} streams - the streams to update from
     * @param {AbstractTachometerApp} app - the tachometer app to update
     */
    static streamsUpdate(streams, app) {
        // The last condition is there since it is possible for the engineInfo stream to exist, but not
        // to have received any engine info yet
        if (!app || !streams || !streams.engineInfo || !streams.electrics || !streams.engineInfo[1])
            return;
        // Perform first time setup
        if (!app.engine) {
            let maxRPM = streams.engineInfo[1];
            app.sendInitialVehicleData({
                maxRPM: maxRPM,
                redlineRPM: (Math.floor(maxRPM / 1000) + 1) * 1000
            });
            app.load();
        }
        else {
            app.updateFromStreams(streams.electrics, streams.engineInfo);
            app.draw();
        }
    }
    /**
     * Returns the light colour, based on whether the lights are on and what type of lights are on.
     * Any value not of the below set returns "black".
     * All values returned are in hexadecimal format
     * @param {number} lightState - the state of the lights (0 = off, 1 = on, 2 = fog)
     */
    static getLightColour(lightState) {
        switch (lightState) {
            case 0:
                return "#000";
            case 1:
                return "#0F0";
            case 2:
                return "#06F";
            default:
                return "#000";
        }
    }
    /**
     * Returns the state of the lights.
     * @param {any} electrics - the electrics stream to read the light state
     * @returns {number} the state of the lights (0 = off, 1 = on, 2 = fog)
     */
    static getLightState(electrics) {
        if (electrics.lowbeam)
            return 1;
        else if (electrics.highbeam)
            return 2;
        else
            return 0;
    }
}
/**
 * Represents a container object for a boost app tha can setup, update and maintain this app
 */
class BoostAppContainer extends AbstractAppContainer {
    /**
     * @constructor
     * @param {AbstractBaseApp} app - the app
     */
    constructor(app) {
        super(app);
    }
    /**
     * @override
     * @inheritDoc
     */
    onStreamsUpdated(streams) {
        this.onStreamsUpdate(streams, AbstractBoostApp.streamsUpdate);
    }
    /**
     * @override
     * @inheritDoc
     */
    getRequiredStreams() {
        return ["forcedInductionInfo"];
    }
}
/**
 * Represents a container object for a tachometer app tha can setup, update and maintain this app
 */
class TachometerAppContainer extends AbstractAppContainer {
    /**
     * @constructor
     * @param {AbstractBaseApp} app - the app
     */
    constructor(app) {
        super(app);
    }
    /**
     * @override
     * @inheritDoc
     */
    onStreamsUpdated(streams) {
        this.onStreamsUpdate(streams, AbstractTachometerApp.streamsUpdate);
    }
    /**
     * @override
     * @inheritDoc
     */
    getRequiredStreams() {
        return ["electrics", "engineInfo"];
    }
}
const FUSION_THEME = new Theme("OCRAStd2", new NumberRange(0.5 * Math.PI, 1.8 * Math.PI), 'F');
class FusionThemeHelper {
    /**
     * Creates and returns a styled pointer
     * @param {Vector} centre - the centre of the pointer
     * @param {NumberRange} valueRange - the range of value this pointer can point between
     * @param {number} length - the length of the tip of the pointer
     * @param {number} dialRadius - the radius of the dial
     * @param {number} baseRadius - the base radius
     * @param {CanvasRenderingContext2D} ctx - the canvas context that will be drawing this pointer
     * @returns {UniPointer} the pointer created
     */
    static createPointer(centre, valueRange, length, dialRadius, baseRadius, ctx) {
        let pointerStyle = new Style("white", 1);
        let pointerPiece = Triangle.newIsosceles(length / 4, length, pointerStyle, centre, -Math.PI / 2);
        let dial = FusionThemeHelper.getDial(dialRadius, baseRadius, centre, ctx);
        return new UniPointer(centre, valueRange, FUSION_THEME.MAIN_ANGLE_RANGE, pointerPiece, dial);
    }
    /**
     * @returns {CanvasGradient} the linear gradient
     */
    static getDialGradient(baseRadius, ctx) {
        return new LinearGradient(new Vector(baseRadius, 0), new Vector(baseRadius, baseRadius * 2), AbstractGradient.distributeEvenly(["#555555", "#222222", "black"])).createGradient(ctx);
    }
    /**
     * Creates and returns a dial object for the pointer centre piece
     * @param {number} radius - the radius of the dial itself
     * @param {number} baseRadius - the radius of the app as a whole this dial is being drawn with
     * @param {Vector} centre - the centre of the dial
     * @param {CanvasRenderingContext2D} ctx - the canvas context that will be drawing this dial
     * @returns {MultiShape} the dial created
     */
    static getDial(radius, baseRadius, centre, ctx) {
        // The bottom semi-circle
        const STYLE = Style.noStrokeFill("#111111");
        let bottom = new Circle(radius, STYLE, centre);
        // The top semi-circle
        const RANGE = new NumberRange(Math.PI, 2 * Math.PI);
        const STYLE2 = Style.noStrokeFill(FusionThemeHelper.getDialGradient(baseRadius, ctx));
        let top = new Arc(radius, RANGE, STYLE2, centre);
        return new MultiShape([bottom, top], centre, centre);
    }
}
/**
 * Represents the fusion theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
class FusionBackground extends AbstractBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
        // The background colours for the background concentric circles
        this.BG_COLOURS = this.setupBGStyles();
    }
    /**
     * Returns the colour for the outermost background circle
     * @return {string} the colour
     */
    getOuterBGColour() {
        let colourRGB = ColourRGB.colourToInstance(this.colourScheme.BACKGROUND);
        let colour;
        if (colourRGB instanceof ColourRGBA)
            // Force no-alpha
            colour = new ColourRGB(colourRGB.R, colourRGB.G, colourRGB.B);
        else
            colour = colourRGB;
        return colour.darken(20).toString();
    }
    /**
     * Returns the styles for each of the background circles
     * @return {{TICKS: Style, NUMS: Style, OUTER: Style}} the styles
     */
    setupBGStyles() {
        let colourRGB = ColourRGB.colourToInstance(this.colourScheme.BACKGROUND);
        return {
            OUTER: Style.noStrokeFill(this.getOuterBGColour()),
            TICKS: Style.noStrokeFill(colourRGB.darken(10).toString()),
            NUMS: Style.noStrokeFill(colourRGB.toString())
        };
    }
    /**
     * Draws the main background concentric circles
     * @param {number} outerRadius - the radius of the outermost circle
     * @param {number} tickRadius - the radius at which ticks will be displayed at
     */
    drawMainBackground(outerRadius, tickRadius) {
        let bgCircles = [
            new Circle(this.baseRadius, this.BG_COLOURS.OUTER, this.centre),
            new Circle(outerRadius, this.BG_COLOURS.TICKS, this.centre),
            new Circle(tickRadius, this.BG_COLOURS.NUMS, this.centre)
        ];
        let applyTransparency = this.colourScheme.isBackgroundTransparent();
        for (let bgCircle of bgCircles) {
            if (applyTransparency)
                Canvas.drawTransparency(ctx => bgCircle.draw(ctx), this.ctx);
            else
                bgCircle.draw(this.ctx);
        }
    }
    /**
     * Draws the glass arc in the bottom right-hand side of the background
     * @param {number} radius - the radius of the arc
     */
    drawGlass(radius) {
        const RANGE = new NumberRange(1.85 * Math.PI, 0.45 * Math.PI);
        const COLOUR = this.lightColour === "#000" ? "rgba(255,255,255,0.25)" : this.lightColour;
        const STYLE = Style.noStrokeFill(COLOUR);
        let glassArc = new Arc(radius, RANGE, STYLE, this.centre);
        Canvas.drawTransparency(ctx => glassArc.draw(ctx), this.ctx);
    }
    /**
     * Draws the inner divider that separates the gauge arc and the inner part of the app
     * @param {number} radius - the radius of the divider
     * @param {number} width - the width of the divider
     */
    drawInnerDivider(radius, width) {
        // Add a little bit of padding so the pointer base does not extend past it
        const RANGE = FUSION_THEME.MAIN_ANGLE_RANGE.clone();
        RANGE.pad(0.1);
        // Draw the inner arc that mirrors the angle of the RPM's arc
        const STYLE = new Style(this.colourScheme.BASE, width);
        new Arc(radius, RANGE, STYLE, this.centre).draw(this.ctx);
        // Draw the remaining part to finish the circle to add an element of 3D
        const STYLE2 = new Style("black", width);
        new Arc(radius, RANGE.invert(), STYLE2, this.centre).draw(this.ctx);
    }
}
const RINGULARITY_THEME = new Theme("AzeretMono-Black", new NumberRange(0.5 * Math.PI, 2 * Math.PI), "R");
class RingularityThemeHelper {
    /**
     * Creates and returns a colour pair, from the given colour, as ColourRGB instances. The first colour is darkened to
     * 65%, and the second colour is equal to {@link colour}
     * @param {string} colour - the base colour to create a pair from
     * @returns {ColourRGB[]} the colour pair
     * @private
     */
    static getColourPair(colour) {
        let colourInst = ColourRGB.colourToInstance(colour);
        return [colourInst.darkMulti(0.6), colourInst];
    }
    /**
     * Creates and returns a colour pair, from the given colour, as ColourRGB instances. The first colour is darkened to
     * 65%, and the second colour is equal to {@link colour}. Similar to {@link getColourPair}, but returns the colours
     * as strings instead
     * @param {string} colour - the base colour to create a pair from
     * @returns {string[]} the colour pair as strings
     * @private
     */
    static getColourPairString(colour) {
        return this.getColourPair(colour).map(c => c.toString());
    }
    /**
     * Creates and returns a colour pair, from the given colour. The first colour is darkened by 65%, and both have an
     * alpha of 0.6
     * @param {string} colour - the colour to use as a base
     * @returns {string[]} the colour pairs
     */
    static getTransparentColourPair(colour) {
        return this.getColourPair(colour).map(c => ColourRGBA.addAlpha(c, 0.6).toString());
    }
    /**
     * Creates and returns a colour pair, from the ARC_BAR colour of the given colour scheme.
     * See {@link getColourPairString} for details on the colours returned
     * @param {ColourScheme} colourScheme - the colour scheme to use the ARC_BAR property of
     * @returns {string[]} the colour pair created
     */
    static getArcbarColourPair(colourScheme) {
        return RingularityThemeHelper.getColourPairString(colourScheme.ARC_BAR.getPrimary());
    }
    /**
     * Creates and returns a Style object for the arc bar with a gradient from the given colours
     * @param {string[]} colours - the colours to use for the gradient
     * @param {number} radius - the radius of the gradient's middle
     * @param {Vector} centre - the centre point of the gradient
     * @param {number} lineWidth - the width of the gradient (the full width will be double this)
     * @param {CanvasRenderingContext2D} ctx - the CanvasRenderingContext2D to create the gradient with
     * @returns {Style} the gradient style created
     * @private
     */
    static getGradientStyle(colours, radius, centre, lineWidth, ctx) {
        return new Style(new RadialGradient(centre.clone(), radius, radius + 1, AbstractGradient.distributeEvenly(colours)).createGradient(ctx), lineWidth);
    }
}
/**
 * Represents the Ringularity theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
class RingularityBackground extends AbstractBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
    }
    /**
     * Draws the bottom right arc that is not covered by the main angle range
     * @param {number} radius - the radius of the arc
     * @param {number} lineWidth - the width of the arc
     * @protected
     */
    drawBottomRightArc(radius, lineWidth) {
        let angles = getRemainingCircle(RINGULARITY_THEME.MAIN_ANGLE_RANGE);
        new Arc(radius, angles, new Style("black", lineWidth), this.centre.clone()).draw(this.ctx);
    }
    /**
     * Draws the main background circle and square
     * @param {number} rectWidth - the width and length of the circle
     * @param {number} circleRadius - the radius of the circle
     * @param {number} circleLineWidth - the width of the circle
     * @protected
     */
    drawMainBackground(rectWidth, circleRadius, circleLineWidth) {
        new Rectangle(rectWidth, rectWidth, Style.noStrokeFill("#111"), Vector.sub(this.centre, new Vector(rectWidth / 2, rectWidth / 2))).draw(this.ctx);
        new Circle(circleRadius, new Style(this.colourScheme.BACKGROUND, circleLineWidth), this.centre.clone()).draw(this.ctx);
    }
    /**
     * Draws the outer and inner strokes around the gauge arc
     * @param {number} width - the width of the arcs
     * @param {[number, number]} radii - the two radii values to create the arcs with
     * @protected
     */
    drawGaugeArcStrokeLines(width, radii) {
        this.drawStrokePair(RINGULARITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.ARC_BAR.getPrimary(), width, radii);
    }
    /**
     * Draws the inner glass circle
     * @param {number} radius - the radius of this inner circle
     * @protected
     */
    drawGlassInnerCircle(radius) {
        let glass = new Circle(radius, Style.noStrokeFill(this.colourScheme.GLASS), this.centre.clone());
        Canvas.drawTransparency(ctx => glass.draw(ctx), this.ctx);
    }
    /**
     * Draws a pair of arcs that 'sandwich' the arc on the gauge
     * @param {NumberRange} angles - the angles of both arcs
     * @param {string} colour - the base colour of the arcs. The outer arc will have this colour, while the inner will
     * have a modified colour based on this colour (see {@link RingularityThemeHelper#getColourPairString} for more details)
     * @param {number} width - the width of the arcs
     * @param {[number, number]} radii - the two radii values to create the arcs with
     * @private
     */
    drawStrokePair(angles, colour, width, radii) {
        let colours = RingularityThemeHelper.getColourPairString(colour);
        this.drawGaugeArc(radii[0], colours[0], angles.clone(), width);
        this.drawGaugeArc(radii[1], colours[1], angles.clone(), width);
    }
    /**
     * Draws an arc intended to surround the RPM part of the gauge
     * @param {number} radius - the radius of the arc
     * @param {string} colour - the colour of the arc
     * @param {NumberRange} angles - the angles of the arc
     * @param {number} width - the width of the arc
     * @private
     */
    drawGaugeArc(radius, colour, angles, width) {
        new Arc(radius, angles.clone(), new Style(colour, width), this.centre.clone()).draw(this.ctx);
    }
}
const VELOCITY_THEME = new Theme("Arial Black", new NumberRange(0.5 * Math.PI, 2 * Math.PI), "V");
/**
 * Represents the velocity theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
class VelocityBackground extends AbstractBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
    }
    /**
     * Draws the dividing arc between the gauge arc and the inner part of the app
     * @param {number} width - the width of the arc
     * @param {number} radius - the radius of the arc
     */
    drawInnerDivider(width, radius) {
        // Draw the dividing line between the inner RPM numbers
        let style = new Style("black", width);
        new Arc(radius, VELOCITY_THEME.MAIN_ANGLE_RANGE, style, this.centre).draw(this.ctx);
    }
    /**
     * Draws the main background circle, which is hollow to allow for transparency when drawing the
     * inner glass piece
     * @param {number} width - the width of the circle
     */
    drawMainBackground(width) {
        let BG_RADIUS = this.baseRadius - width / 2;
        // Draw as a hollow circle to allow the centre to show transparency
        let style = new Style(this.colourScheme.BACKGROUND, width);
        new Circle(BG_RADIUS, style, this.centre).draw(this.ctx);
    }
    /**
     * Draws the inner glass piece. This glass piece is inside the main part of the gauge and is a
     * complete circle, comprised of a transparent piece and an opaque piece. The coverage of the
     * former is determined by {@see VELOCITY_THEME.MAIN_ANGLE_RANGE} and the latter determined by the
     * remainder of the circle left
     * @param {number} radius - the radius of the glass piece
     * */
    drawInnerGlass(radius) {
        // Draw the glass
        let glass = new Wedge(radius, VelocityBackground.BASE_RANGE, Style.noStrokeFill(this.colourScheme.GLASS), this.centre);
        Canvas.drawTransparency(ctx => glass.draw(ctx), this.ctx);
        // Slight overlapping caused by transparency here; manual fix to prevent imperfection
        if (this.colourScheme.isBackgroundTransparent())
            radius -= 1;
        // Fill in the other part not filled in with the background colour;
        new Wedge(radius, VelocityBackground.BASE_RANGE.invert(), Style.noStrokeFill(this.colourScheme.BACKGROUND), this.centre).draw(this.ctx);
    }
}
VelocityBackground.BASE_RANGE = VELOCITY_THEME.MAIN_ANGLE_RANGE;
/**
 * Represents an RGB colour with an additional alpha channel
 */
class ColourRGBA extends ColourRGB {
    constructor(r, g, b, a) {
        super(r, g, b);
        this.a = a;
    }
    get A() {
        return this.a;
    }
    /**
     * @override
     * @inheritDoc
     */
    toString() {
        return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.a + ")";
    }
    /**
     * @override
     * @inheritDoc
     */
    lighten(amount) {
        return new ColourRGBA(this.r, this.g, this.b, this.a + amount / 255);
    }
    /**
     * @override
     * @inheritDoc
     */
    darken(amount) {
        return new ColourRGBA(this.r, this.g, this.b, this.a - amount / 255);
    }
    /**
     * Adds an alpha channel to the a given RGB colour
     * @param {ColourRGB} colour - the colour to add the alpha channel to
     * @param {number} alpha  -the alpha channel value
     * @return {ColourRGBA} the new colour
     */
    static addAlpha(colour, alpha) {
        return new ColourRGBA(colour.R, colour.G, colour.B, alpha);
    }
}
/**
 * Represents a base builder class that can build component objects
 * @template T
 */
class AbstractComponentBuilder extends HasCentre {
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        builder.setCentre(this.centre);
        return this;
    }
}
// 130 is the maximal value for temp as seen in BeamNG's Tacho2 app
const TEMP = { colour: "#A00", maxValue: 130 };
const FUEL = { colour: "#00F", maxValue: 1 };
const BRAKE = { colour: "#F00", maxValue: 1 };
const THROTTLE = { colour: "#0F0", maxValue: 1 };
/**
 * Represents a class that can generate the various bar displayers such as temperature and fuel bars
 */
class AbstractBarCollectionBuilder extends HasCentre {
    constructor() {
        super(...arguments);
        this.capStyle = "butt";
    }
    setArcWidth(width) {
        this.arcWidth = width;
        return this;
    }
    setCapStyle(capStyle) {
        this.capStyle = capStyle;
        return this;
    }
    /**
     * Creates the arc bar for the gauge displayer
     * @param {number} radius - the radius of the arc bar
     * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
     * @param {NumberRange} arcRange - the range of angles of the arc bar
     * @returns {ArcBar} the arc bar
     */
    createArcBar(radius, arcBarData, arcRange) {
        let style = new Style(arcBarData.colour, this.arcWidth);
        let bgStyle = new Style("rgba(255, 255, 255, 0.25)", this.arcWidth);
        let arcBar = new ArcBar(radius, arcRange, style, bgStyle, this.centre);
        arcBar.setCapStyle(this.capStyle);
        return arcBar;
    }
    /**
     * Creates the gauge arc displayer, with the given ArcBar
     * @param {ArcBar} arcBar - the arc bar to use
     * @param {number} maxValue - the maximum value of the arc bar
     * @returns {ArcBarDisplayer} the created ArcBarDisplayer
     */
    createGaugeDisplayerFromArcBar(arcBar, maxValue) {
        let valRange = new NumberRange(0, maxValue);
        return new ArcBarDisplayer(valRange, arcBar);
    }
    /**
     * Creates a new ArcBarDisplayer. Similar to {@link createGaugeDisplayerFromArcBar}, but creates the ArcBar as well
     * @param {number} radius - the radius of the ArcBar
     * @param {ArcBarData} arcBarData - the arc bar data to use
     * @param {NumberRange} arcRange - the angle range of the ArcBar
     * @returns {ArcBarDisplayer} the created ArcBarDisplayer
     * @protected
     */
    createGaugeDisplayer(radius, arcBarData, arcRange) {
        let arcBar = this.createArcBar(radius, arcBarData, arcRange);
        return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        builder.setCentre(this.centre);
        return this;
    }
}
/**
 * Represents a data displayer than can draw to a canvas
 * @template T
 * T is the type/object that will be used to perform updates
 */
class AbstractDataDisplayer extends Drawable {
    /**
     * @constructor
     */
    constructor() {
        super();
    }
}
/**
 * Represents a completion bar in an arc shape
 */
class ArcBar extends Drawable {
    /**
     * Constructor
     * By default, the bar is 100% complete
     * @param {number} radius - the radius of the arc
     * @param {NumberRange} angles - the starting and end angles of the arc
     * @param {BaseStyle} styling - the styling to apply to the arc
     * @param {BaseStyle} bgStyling - the styling to apply to the background of the arc
     * @param {Vector} centre - the centre of the arc bar
     */
    constructor(radius, angles, styling, bgStyling, centre) {
        super();
        this.radius = radius;
        this.angles = angles;
        this.styling = styling;
        this.bgStyling = bgStyling;
        this.centre = centre;
        this.invert = false;
        this.bgArc = new Arc(radius, angles, this.bgStyling, centre, centre.clone());
        this.mainArc = this.bgArc.changeStyling(this.styling);
    }
    /**
     * Sets whether to invert the arc bar
     * @param {boolean} invert - whether to invert the arc bar or not
     */
    invertArcs(invert) {
        this.invert = invert;
    }
    /**
     * Sets the cap style to the ends of the arc bar
     * @param {"round" | "butt"} style - the cap style to apply
     */
    setCapStyle(style) {
        this.bgArc.setCapStyle(style);
        this.mainArc.setCapStyle(style);
    }
    /**
     * @param {number} perc - the percentage full to set the bar to be (between [0,1])
     */
    setPercentageAlong(perc) {
        let angles = this.bgArc.getAngles();
        if (this.invert) {
            let angle = angles.getLinearRatio(1 - perc);
            this.mainArc.setStartAngle(angle);
        }
        else {
            let angle = angles.getLinearRatio(perc);
            this.mainArc.setEndAngle(angle);
        }
    }
    /**
     * @Override
     * @inheritDoc
     */
    draw(ctx) {
        this.bgArc.draw(ctx);
        this.mainArc.draw(ctx);
    }
}
class LinearGradient extends AbstractGradient {
    /**
     * @constructor
     * @param {Vector} startPos - the start position of the gradient
     * @param {Vector} endPos - the end position of the gradient
     * @param {string[]} colourStops - the colours in the gradient
     */
    constructor(startPos, endPos, colourStops) {
        super(colourStops);
        this.startPos = startPos;
        this.endPos = endPos;
    }
    /**
     * @override
     * @inheritDoc
     */
    initGradient(ctx) {
        return ctx.createLinearGradient(this.startPos.x(), this.startPos.y(), this.endPos.x(), this.endPos.y());
    }
}
class RadialGradient extends AbstractGradient {
    /**
     * @constructor
     * @param {Vector} centre - the start position of the gradient
     * @param {number} startRadius - the start radius of the circle
     * @param {number} endRadius - the end radius of the circle
     * @param {string[]} colourStops - the colours in the gradient
     */
    constructor(centre, startRadius, endRadius, colourStops) {
        super(colourStops);
        this.centre = centre;
        this.startRadius = startRadius;
        this.endRadius = endRadius;
    }
    /**
     * @override
     * @inheritDoc
     */
    initGradient(ctx) {
        return ctx.createRadialGradient(this.centre.x(), this.centre.y(), this.startRadius, this.centre.x(), this.centre.y(), this.endRadius);
    }
}
/**
 * Represents text of a given font and position
 */
class Text extends Drawable {
    /**
     * @constructor
     * @param {Font} font - the font to use for the text
     * @param {string} text - the text to display
     * @param {Vector} position - the position the text will be displayed at
     * @param {BaseStyle} style - the text colour/style
     */
    constructor(font, text, position, style) {
        super();
        this.font = font;
        this.text = text;
        this.position = position;
        this.style = style;
    }
    setText(text) {
        this.text = text;
    }
    setColour(colour) {
        if (!this.style) {
            this.style = Style.noStrokeFill(colour);
        }
        else if (this.style instanceof Style) {
            this.style = this.style.changeColour(colour);
        }
        else {
            console.warn("setColour() not implemented for " + typeof this.style + " yet!");
        }
    }
    /**
     * @Override
     * @inheritDoc
     */
    draw(ctx) {
        this.font.apply(ctx);
        this.style.setVars(ctx);
        ctx.fillText(this.text, this.position.x(), this.position.y());
        Canvas.resetTransformationState(ctx);
    }
}
class AccentTriangleBuilder extends AbstractPointerBuilder {
    constructor() {
        super(...arguments);
        /** Whether accent keeps the width of the main pointer, or has it's value reduced by {@link accentScale} */
        this.keepWidth = true;
    }
    setKeepWidth(value) {
        this.keepWidth = value;
        return this;
    }
    setColours(value) {
        this.colours = value;
        return this;
    }
    setAccentScale(value) {
        this.accentScale = value;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        let dialStyle = Style.noStrokeFill(this.colours.dial);
        let primaryStyle = Style.unitStrokeFill(this.colours.main);
        let secondaryStyle = Style.unitStrokeFill(this.colours.accent);
        let accentLength = this.keepWidth ? this.length : this.length * this.accentScale;
        let mainBuilder = new DualTriangleNoDialBuilder()
            .setCentre(this.centre)
            .setWidth(this.width)
            .setLength(this.length)
            .setMinorScale(this.minorScale)
            .setPointerRange(this.pointerRange)
            .setStartAngle(this.startAngle)
            .setValueRange(this.valueRange)
            .setTipStyle(primaryStyle);
        let accentBuilder = new DualTriangleNoDialBuilder()
            .useAsBase(mainBuilder)
            .setWidth(this.width * this.accentScale)
            .setLength(accentLength)
            .setTipStyle(secondaryStyle);
        let dial = new Circle(this.width * 0.8, dialStyle, this.centre);
        return new AccentPointer(this.centre, this.pointerRange, mainBuilder.build(), accentBuilder.build(), dial);
    }
}
/**
 * Creates a new simple pointer with a main pointer and a shorter pointer that faces the opposing direction, however, it
 * does not contain a middle dial component. Both pointers are triangles.
 */
class DualTriangleNoDialBuilder extends AbstractPointerBuilder {
    setTipStyle(value) {
        this.tipStyle = value;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        let major = Triangle.newIsosceles(this.width, this.length, this.tipStyle, this.centre, this.startAngle);
        let minor = Triangle.newIsosceles(this.width, this.length * this.minorScale, this.tipStyle, this.centre, this.startAngle);
        return new SimplePointer(this.centre, this.valueRange, this.pointerRange, major, minor, null);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        return super.useAsBase(builder).setTipStyle(builder.tipStyle);
    }
}
/**
 * Represents an object that can be rotated around a centre point
 */
class Rotatable extends Moveable {
    /**
     * @constructor
     * @param {Vector} [centre] - the centre. Defaults to (0,0)
     * @param {Vector} [rotCentre] - the rotational centre. Defaults to (0,0)
     * @param {number} [angle] - the angle around the centre. Defaults to 0
     */
    constructor(centre = new Vector(), rotCentre = new Vector(), angle = 0) {
        super(centre);
        this.rotCentre = rotCentre;
        this.angle = angle;
    }
    /**
     * Sets the angle of rotation
     * @param {number} angle - the angle to set
     */
    setAngle(angle) {
        this.angle = angle;
    }
    /**
     * Sets the centre of rotation for this shape
     * @param {Vector} centre - the new centre of rotation
     */
    setRotationalCentre(centre) {
        this.rotCentre = centre;
    }
}
/**
 * Test classes for creating new tachometer/boost apps.
 * Allows only partial pieces of the app to be built to run/view them,
 */
class AbstractTestTachometerApp extends AbstractTachometerApp {
    /**
     * @override
     * @inheritDoc
     */
    createBarCollection() {
        let builder = this.createBarCollectionBuilder();
        this.brakeGauge = builder === null || builder === void 0 ? void 0 : builder.buildBrakeBar();
        this.throttleGauge = builder === null || builder === void 0 ? void 0 : builder.buildThrottleBar();
        this.tempGauge = builder === null || builder === void 0 ? void 0 : builder.buildTempBar();
        this.fuelGauge = builder === null || builder === void 0 ? void 0 : builder.buildFuelBar();
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        // Re-draw if necessary before the foreground canvas does so
        if (this.bgNeedsRedraw)
            this.drawBackgroundCanvas();
        this.canvas.show(true);
        this.canvas.clear();
        let ctx = this.canvas.get2DContext();
        this.getComponents().forEach(component => component === null || component === void 0 ? void 0 : component.draw(ctx));
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        (_a = this.engine) === null || _a === void 0 ? void 0 : _a.setCurrRPM(data.currRPM);
        (_b = this.gearbox) === null || _b === void 0 ? void 0 : _b.setGear(data.gear);
        (_c = this.pBrake) === null || _c === void 0 ? void 0 : _c.update(data.pBrakeEnabled);
        (_d = this.speedo) === null || _d === void 0 ? void 0 : _d.update(data.speed);
        (_e = this.RPMGauge) === null || _e === void 0 ? void 0 : _e.update(this.engine);
        (_f = this.fuelGauge) === null || _f === void 0 ? void 0 : _f.update(data.fuel);
        (_g = this.tempGauge) === null || _g === void 0 ? void 0 : _g.update(data.temp);
        (_h = this.brakeGauge) === null || _h === void 0 ? void 0 : _h.update(data.brake);
        (_j = this.throttleGauge) === null || _j === void 0 ? void 0 : _j.update(data.throttle);
        (_k = this.gear) === null || _k === void 0 ? void 0 : _k.update({
            gearbox: this.gearbox,
            shouldShift: this.engine.shouldShiftUp()
        });
        (_l = this.indicators) === null || _l === void 0 ? void 0 : _l.update({
            left: data.indicators.left,
            right: data.indicators.right
        });
        this.bgNeedsRedraw = (_m = this.background) === null || _m === void 0 ? void 0 : _m.updateLighting(this.getLightColour(data.lightState));
    }
}
class AbstractTestBoostApp extends AbstractBoostApp {
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        var _a, _b;
        // Re-draw if necessary before the foreground canvas does so
        if (this.bgNeedsRedraw)
            this.drawBackgroundCanvas();
        this.canvas.show(true);
        this.canvas.clear();
        let ctx = this.canvas.get2DContext();
        (_a = this.gauge) === null || _a === void 0 ? void 0 : _a.draw(ctx);
        (_b = this.pressure) === null || _b === void 0 ? void 0 : _b.draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        var _a, _b;
        this.turbo.setBoost(data.boost);
        (_a = this.gauge) === null || _a === void 0 ? void 0 : _a.update(this.turbo);
        (_b = this.pressure) === null || _b === void 0 ? void 0 : _b.update(data.boost);
    }
}
/**
 * Represents a base component that makes up part of the whole gauge
 * @template T
 * T is the object that will update this update with new values
 */
class AbstractGaugeComponent extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {FullGauge} gauge - the gauge to display on
     */
    constructor(gauge) {
        super();
        this.gauge = gauge;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.gauge.draw(ctx);
    }
}
/**
 * Represents a component that displays via a text displayer
 * @template T, S
 * T is the text displayer to use
 * S is the type that will be used to perform updates
 */
class AbstractTextDisplayerComponent extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {T} textDisplayer - the displayer that will display the text
     */
    constructor(textDisplayer) {
        super();
        this.textDisplayer = textDisplayer;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.textDisplayer.draw(ctx);
    }
}
/**
 * Represents a component that can highlight two shapes representing vehicle indicators
 */
class IndicatorsComponent extends AbstractDataDisplayer {
    /**
     * @constructor
     * Note that any styling applied to either indicator will be overridden
     * @param {AbstractShape} leftIndicator - the left indicator
     * @param {AbstractShape} rightIndicator - the right indicator
     * @param {Style} baseStyle - the base style, supplying whether the indicators will be filled and
     * any stroke applicable. The colour is overridden here.
     */
    constructor(leftIndicator, rightIndicator, baseStyle) {
        super();
        this.initIndicators(leftIndicator, rightIndicator, baseStyle);
    }
    /**
     * Creates two styles where the stroke width and whether they are filled are determined by the passed style, and whose
     * colours are the primary and secondary colour of {@link IndicatorsComponent.COLOURS} respectively
     * @param {Style} baseStyle - the base style
     * @returns {Style[]} the two styles created
     * @private
     */
    static createStyles(baseStyle) {
        return [
            baseStyle.changeColour(IndicatorsComponent.COLOURS.getPrimary()),
            baseStyle.changeColour(IndicatorsComponent.COLOURS.getSecondary())
        ];
    }
    /**
     * Creates the indicators with the given shapes and base style
     * @param {AbstractShape} leftShape - the left indicator shape
     * @param {AbstractShape} rightShape - the right indicator shape
     * @param {Style} baseStyle - the base style to apply (stroke width and whether it is filled are used)
     * @private
     */
    initIndicators(leftShape, rightShape, baseStyle) {
        this.leftIndicator = new MultiStateComponent(IndicatorsComponent.createStyles(baseStyle), leftShape);
        this.rightIndicator = new MultiStateComponent(IndicatorsComponent.createStyles(baseStyle), rightShape);
        // Ensure correct starting style
        this.leftIndicator.update(0);
        this.rightIndicator.update(0);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.leftIndicator.update(Math.floor(data.left));
        this.rightIndicator.update(Math.floor(data.right));
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.leftIndicator.draw(ctx);
        this.rightIndicator.draw(ctx);
    }
}
IndicatorsComponent.COLOURS = new ColourPriority("grey", "#00FF00");
class MultiStateComponent extends AbstractDataDisplayer {
    constructor(states, object) {
        super();
        this.states = states;
        this.object = object;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.object.draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     * @param {number} data - a number that represents the state to change to. Should be a number between `0->n`, where
     * `n` is the the number of different states this component has minus 1.
     */
    update(data) {
        let newState = this.states[data];
        if (this.currentState === newState)
            return;
        this.object = this.object.changeStyling(newState);
        this.currentState = newState;
    }
}
/**
 * Represents a component that displays a value and the units it is in
 */
class UnitisedComponent extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {TextDisplayer} valueDisplayer - the displayer for the value
     * @param {TextDisplayer} unitDisplayer - the displayer for the unit
     * @param {Quantity} quantity - the quantity type for displaying and converting values
     */
    constructor(valueDisplayer, unitDisplayer, quantity) {
        super();
        this.valueDisplayer = valueDisplayer;
        this.unitDisplayer = unitDisplayer;
        this.quantity = quantity;
    }
    /**
     * @return {Quantity} the unit instance
     */
    getQuantity() {
        return this.quantity;
    }
    /**
     * @returns {number} the index of the current unit
     */
    getIndexOfCurrent() {
        return this.quantity.getUnitIndex();
    }
    /**
     * Sets the selected unit to the unit at the given index
     * @param {number} index - the index to set
     */
    setIndexOfCurrent(index) {
        this.quantity.setUnitIndex(index);
    }
    /**
     * Cycles the unit
     */
    cycleUnit() {
        this.quantity.cycleUnit();
        this.unitDisplayer.update(this.quantity.getUnitName());
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        let conversion = this.quantity.convert(data);
        this.valueDisplayer.update(conversion.value);
        this.unitDisplayer.update(conversion.units);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.valueDisplayer.draw(ctx);
        this.unitDisplayer.draw(ctx);
    }
}
/**
 * Represents a builder class for creating a text parking brake component
 */
class TextParkingBrakeBuilder extends AbstractComponentBuilder {
    /**
     * Creates the dual colour text displayer
     * @returns {DualColourTextDisplayer} the dual text displayer
     */
    createPBrakeText() {
        let font = new Font(this.font.FONT_NAME, this.font.FONT_SIZE, true);
        let text = new Text(font, "PARK", this.centre, Style.noStrokeFill(""));
        return new DualColourTextDisplayer(text, this.colourScheme.PARKING_BRAKE);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        this.setCentre(builder.centre);
        this.setFont(builder.font);
        this.setColourScheme(builder.colourScheme);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new TextParkingBrakeComponent(this.createPBrakeText());
    }
}
applyMixins(TextParkingBrakeBuilder, [HasColourScheme, HasFont]);
/**
 * Represents a builder that can build the temperature, fuel, throttle and brake values as arc bars,
 * where pairs of which arc placed along the same radius.
 * The throttle and brake bars default to being inverted while the temperature and fuel bars default
 * to being normal. This can be inverted with the {@link invertArcDirections} flag in the constructor
 */
class PairedBarCollectionBuilder extends AbstractBarCollectionBuilder {
    constructor() {
        super(...arguments);
        this.invertArcDirections = false;
    }
    setInnerRadius(innerRadius) {
        this.innerRadius = innerRadius;
        return this;
    }
    setOuterRadius(outerRadius) {
        this.outerRadius = outerRadius;
        return this;
    }
    setTempFuelArcRange(arcRangeTF) {
        this.arcRangeTF = arcRangeTF;
        return this;
    }
    setThottleBrakeArcRange(arcRangeTB) {
        this.arcRangeTB = arcRangeTB;
        return this;
    }
    setInvertArcDirections(invert) {
        this.invertArcDirections = invert;
        return this;
    }
    /**
     * Creates an end gauge displayer, positioned at the end of the inner part of the gauge
     * @param {number} radius - the radius of the arc bar
     * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
     * @returns {ArcBarDisplayer} the created arc bar displayer
     */
    createEndGaugeDisplayer(radius, arcBarData) {
        let arcBar = this.createArcBar(radius, arcBarData, this.arcRangeTB);
        // This arc bar is inverted by default, so un-invert if inversion is set to true
        arcBar.invertArcs(!this.invertArcDirections);
        return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
    }
    /**
     * Creates an end gauge displayer, positioned at the start of the inner part of the gauge
     * @param {number} radius - the radius of the arc bar
     * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
     * @returns {ArcBarDisplayer} the created arc bar displayer
     */
    createStartGaugeDisplayer(radius, arcBarData) {
        let arcBar = this.createArcBar(radius, arcBarData, this.arcRangeTF);
        arcBar.invertArcs(this.invertArcDirections);
        return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setInvertArcDirections(builder.invertArcDirections);
        this.setArcWidth(builder.arcWidth);
        this.setInnerRadius(builder.innerRadius);
        this.setOuterRadius(builder.outerRadius);
        this.setCapStyle(builder.capStyle);
        this.setTempFuelArcRange(builder.arcRangeTF);
        this.setThottleBrakeArcRange(builder.arcRangeTB);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    buildTempBar() {
        return this.createStartGaugeDisplayer(this.innerRadius, TEMP);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildFuelBar() {
        return this.createStartGaugeDisplayer(this.outerRadius, FUEL);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildBrakeBar() {
        return this.createEndGaugeDisplayer(this.innerRadius, BRAKE);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildThrottleBar() {
        return this.createEndGaugeDisplayer(this.outerRadius, THROTTLE);
    }
}
/**
 * Represents a builder than can builder the four arc bars in a row
 */
class SequentialBarCollectionBuilder extends AbstractBarCollectionBuilder {
    constructor() {
        super(...arguments);
        this.invertArcDirection = false;
    }
    setStartingRadius(startingRadius) {
        this.startingRadius = startingRadius;
        return this;
    }
    setSpacing(spacing) {
        this.spacing = spacing;
        return this;
    }
    setArcRange(arcRange) {
        this.arcRange = arcRange;
        return this;
    }
    setInvertArcDirection(invertArcDirection) {
        this.invertArcDirection = invertArcDirection;
        return this;
    }
    /**
     * Returns the radius at which a particular arc bar will sit at, given its sequence number
     * @param {number} seqNumber - the sequence number (1 -> 4)
     * @returns {number}
     * @private
     */
    calculateRadius(seqNumber) {
        return this.startingRadius + (seqNumber * this.spacing);
    }
    /**
     * Creates a new ArcBarDisplayer, given the order at which is sits in sequence and the data about the arc bar
     * @param {number} seqNumber - the sequence number (1 -> 4)
     * @param {ArcBarData} arcBarData - the arc bar data
     * @returns {ArcBarDisplayer} the created ArcBarDisplayer
     * @protected
     */
    createSequentialGaugeDisplayer(seqNumber, arcBarData) {
        return this.createGaugeDisplayer(this.calculateRadius(seqNumber), arcBarData, this.arcRange);
    }
    /**
     * @override
     * @inheritDoc
     * Inverts the arc direction with the value of invertArcDirection
     */
    createArcBar(radius, arcBarData, arcRange) {
        let arcBar = super.createArcBar(radius, arcBarData, arcRange);
        arcBar.invertArcs(this.invertArcDirection);
        return arcBar;
    }
    /**
     * @override
     * @inheritDoc
     */
    buildTempBar() {
        return this.createSequentialGaugeDisplayer(3, TEMP);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildFuelBar() {
        return this.createSequentialGaugeDisplayer(4, FUEL);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildBrakeBar() {
        return this.createSequentialGaugeDisplayer(2, BRAKE);
    }
    /**
     * @override
     * @inheritDoc
     */
    buildThrottleBar() {
        return this.createSequentialGaugeDisplayer(1, THROTTLE);
    }
}
/**
 * Represents a class that can builder a component with a full gauge piece
 */
class AbstractFullGaugeBuilder extends AbstractComponentBuilder {
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setCtx(builder.ctx);
        return this;
    }
    /**
     * @returns {FullGauge} the full gauge created
     */
    createFullGauge() {
        return new FullGauge(this.createTicks(), this.createNumbering(), this.createPointer(), this.createArcBar());
    }
}
applyMixins(AbstractFullGaugeBuilder, [HasFontName, CanDraw]);
class AbstractGearBuilder extends AbstractComponentBuilder {
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setColourScheme(builder.colourScheme);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new GearComponent(this.createTextDisplayer(), this.createShiftPrompt());
    }
}
applyMixins(AbstractGearBuilder, [HasColourScheme]);
class AbstractIndicatorsBuilder extends AbstractComponentBuilder {
    constructor() {
        super(...arguments);
        this.unlitStyle = new Style("", 0, true);
    }
    setUnlitStyle(unlitStyle) {
        this.unlitStyle = unlitStyle;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setUnlitStyle(builder.unlitStyle);
        return this;
    }
}
/**
 * Represents a builder that can create an unitised component
 */
class AbstractUnitisedBuilder extends AbstractComponentBuilder {
    setQuantity(value) {
        this.quantity = value;
        return this;
    }
    setValueFontSize(value) {
        this.valueFontSize = value;
        return this;
    }
    setUnitFontSize(value) {
        this.unitFontSize = value;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        this.setQuantity(builder.quantity);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new UnitisedComponent(new TextDisplayer(this.createValueText()), new TextDisplayer(this.createUnitText()), this.quantity);
    }
    /**
     * @return {BaseStyle} the style for the unit text
     */
    getUnitStyle() {
        return Style.noStrokeFill(this.colourScheme.UNIT);
    }
    /**
     * @return {BaseStyle} the style for the value text
     */
    getValueStyle() {
        return Style.noStrokeFill(this.colourScheme.VALUE);
    }
    /**
     * Creates a text object
     * @param {number} fontSize - the size of the font to use
     * @param {Vector} position - the position to place the text
     * @param {BaseStyle} style - the styling to apply
     * @return {Text} the text created
     */
    createText(fontSize, position, style) {
        let font = new Font(this.fontName, fontSize, true);
        return new Text(font, "", position, style);
    }
}
applyMixins(AbstractUnitisedBuilder, [HasFontName, HasColourScheme]);
/**
 * Represents an object that can display data that is bounded between two values, ie. is discrete in
 * nature.
 * T is the type/object that will be used to perform updates
 */
class AbstractBoundedDataDisplayer extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {NumberRange} VALUE_RANGE - the value range possible to display
     */
    constructor(VALUE_RANGE) {
        super();
        this.VALUE_RANGE = VALUE_RANGE;
    }
    getValueRange() {
        return this.VALUE_RANGE.clone();
    }
    /**
     * Sets the value of an ArcBar instance
     * @param {number} value - the value to set
     * @param {ArcBar} arcBar - the arc bar to set the value to
     */
    setValueOf(value, arcBar) {
        let perc = this.getPerc(value);
        arcBar.setPercentageAlong(perc);
    }
    /**
     * Returns the percentage complete this displayer will be, given a value
     * @param {number} value - the value to consider
     * @returns {number} the percentage [0,1] complete this displayer will be
     */
    getPerc(value) {
        return this.VALUE_RANGE.getNormLinearRatio(value);
    }
}
/**
 * Represents a list of numbers, arranged in an arc
 */
class ArcNumbering extends Moveable {
    /**
     * @constructor
     * The colour of the numbering text defaults to white.
     * @param {Vector} centre - the centre of the display
     * @param {number} radius - the distance between the centre and each number
     * @param {[number]} numbers - the list of numbers to display
     * @param {NumberRange} arcRange - the angle range that the numbers will occupy
     * @param {Font} font - the font to display the numbering text in
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
     */
    constructor(centre, radius, numbers, arcRange, font, ctx, drawStartAndEndNumbers = true) {
        super(centre);
        this.radius = radius;
        this.numbers = numbers;
        this.arcRange = arcRange;
        this.font = font;
        this.ctx = ctx;
        this.drawStartAndEndNumbers = drawStartAndEndNumbers;
        /** @type string[] */
        this.colour = Array(numbers.length).fill("white");
        this.text = this.generateText();
    }
    /**
     * Sets the colour of the numbering text
     * @param {string | string[]} colour - the colour(s) to set. If an array is given, then every
     * number will be given the corresponding colour in that array. The length of the array must
     * therefore be equal to the number of numbers
     */
    setColour(colour) {
        if (typeof colour === "string") {
            this.colour = Array(this.numbers.length).fill(colour);
        }
        else if (Array.isArray(colour)) {
            this.colour = colour;
        }
        this.text = this.generateText();
    }
    /**
     * Returns the position of one of the numbers on the gauge, rotated to the position it will appear
     * at
     * @param {number} numberIndex - the index of the number
     * @return {Vector} the position of this number
     */
    getRotatePosition(numberIndex) {
        const INITPOS = new Vector(this.radius, 0);
        const ANGLERANGE = this.arcRange.getDifference();
        // -1 to show a number at both ends
        let percentAlong = numberIndex / (this.numbers.length - 1);
        // Add the start angle to ensure the first number starts at the lowest angle
        let angle = percentAlong * ANGLERANGE + this.arcRange.getLower();
        return INITPOS.rotateAboutOrigin(angle);
    }
    /**
     * Returns the position a particular number will be placed at
     * @param {number} numberIndex - the index of the number
     * @returns {Vector} the position this number will be placed at
     */
    getNumberPosition(numberIndex) {
        let totalPos = new Vector();
        // Get the position rotated around the centre
        totalPos.add(this.getRotatePosition(numberIndex));
        // Add in the font fixing for centring
        // totalPos.add(this.font.getCentreFix(this.CTX, numberIndex.toString()));
        // And translate it to the centre of the displayer
        totalPos.add(this.centre);
        return totalPos;
    }
    /**
     * Generates and returns the list of numbers in text form
     * @returns {Text[]} the numbers in text form
     */
    generateText() {
        let text = [];
        for (let i = 0; i < this.numbers.length; i++) {
            if (!this.drawStartAndEndNumbers && (i === 0 || i === this.numbers.length - 1))
                continue;
            let position = this.getNumberPosition(i);
            let style = Style.noStrokeFill(this.colour[i]);
            let numText = new Text(this.font, this.numbers[i].toString(), position, style);
            text.push(numText);
        }
        return text;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.text.forEach(text => text.draw(ctx));
    }
}
/**
 * Represents an object that can update and display a single piece of information to a full gauge's
 * worth of displayers
 */
class FullGauge extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {ArcTicks} ticks - the ticks that show regular intervals along the gauge
     * @param {ArcNumbering} numbering - the numbers that show the value at set intervals
     * @param {AbstractGaugePointer} pointer - the pointer that pointers to the current value. Can be
     * <b>null</b>
     * @param {ArcBarDisplayer | LimitedArcBarDisplayer} bar - the bar that shows the current value.
     * Can be <b>null</b>
     */
    constructor(ticks, numbering, pointer, bar) {
        super();
        this.ticks = ticks;
        this.numbering = numbering;
        this.pointer = pointer;
        this.bar = bar;
    }
    /**
     * Returns the elements as a list. The order of the list is in their drawn order, from first drawn
     * to last drawn. Note that some values may be <b>null</b>
     * @returns {Drawable[]}
     */
    elementsToList() {
        return [this.bar, this.numbering, this.ticks, this.pointer];
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        if (this.bar)
            this.bar.update(data.arcBar);
        if (this.ticks instanceof CamoArcTicks)
            this.ticks.update(data.ticks);
        if (this.pointer)
            this.pointer.update(data.pointer);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        let elements = this.elementsToList();
        elements.forEach(element => element === null || element === void 0 ? void 0 : element.draw(ctx));
    }
}
/**
 * Represents a list of lines ("ticks") that follow an arc curve.
 * Useful for representing an RPM gauge or a gauge with set interval values
 */
class ArcTicks extends Moveable {
    /**
     * @constructor
     * By default: <ul>
     *  <li>End ticks are drawn</li>
     *  <li>Major (big) ticks are spaced every 4th tick</li>
     *  <li>Ticks are coloured white</li>
     *  <li>Tick length is 10</li>
     *  <li>Tick width is 4</li>
     *  <li>Tick are centred</li>
     * </ul>
     * Use the relevant set method to adjust as necessary
     * @param {Vector} centre - the centre of the display
     * @param {number} radius - the distance between the display centre and each tick's centre. Note
     * that for non-centred ticks, this radii is the _smallest_ radii of the ticks
     * @param {number} numTicks - the number of ticks to have
     * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
     */
    constructor(centre, radius, numTicks, arcRange) {
        super(centre);
        this.radius = radius;
        this.numTicks = numTicks;
        this.arcRange = arcRange;
        this.drawEndTicks = true;
        this.majorSpacing = 4;
        this.colour = "white";
        this.tickLength = 10;
        this.tickWidth = 4;
        this.areCentred = true;
        // -1 as element 0 starts at angleRange.lower and element N ends at angleRange.upper
        // so include upper bound as element N (not N+1)
        this.angleSpacing = this.arcRange.getDifference() / (this.numTicks - 1);
        this.ticks = this.generateTicks();
    }
    /**
     * Sets whether or not to draw end ticks
     * @param {boolean} drawEndTicks - whether to draw end ticks
     */
    setDrawEndTicks(drawEndTicks) {
        if (this.drawEndTicks === drawEndTicks)
            return;
        this.drawEndTicks = drawEndTicks;
        this.ticks = this.generateTicks();
        // Remove the two end ticks from the count
        if (!this.drawEndTicks)
            this.numTicks -= 2;
    }
    /**
     * Sets whether to centre the ticks or not
     * @param {boolean} areCentred - whether to centre the ticks
     */
    setCentring(areCentred) {
        if (this.areCentred === areCentred)
            return;
        this.areCentred = areCentred;
        this.ticks = this.generateTicks();
    }
    /**
     * Sets the tick length
     * @param {number} length - the length to set
     */
    setTickLength(length) {
        if (this.tickLength === length)
            return;
        this.tickLength = length;
        this.ticks = this.generateTicks();
    }
    /**
     * Sets the spacing between major ticks
     * @param {number} spacing - the spacing to set
     */
    setMajorSpacing(spacing) {
        if (this.majorSpacing === spacing)
            return;
        this.majorSpacing = spacing;
        this.ticks = this.generateTicks();
    }
    /**
     * Sets the tick width
     * @param {number} width - the width to set
     */
    setTickWidth(width) {
        if (this.tickWidth === width)
            return;
        this.tickWidth = width;
    }
    /**
     * Sets the tick's colour
     * @param {string} colour - the colour to set
     */
    setTickColour(colour) {
        this.colour = colour;
    }
    /**
     * Generates a list of ticks as pairs of radii
     * @returns {[[Vector, Vector]]} the ticks, as pairs of inner and outer radii
     */
    generateTicks() {
        let ticks = [];
        let currAngle = this.arcRange.getLower();
        for (let i = 0; i < this.numTicks; i++) {
            let isMajor = i % this.majorSpacing !== 0;
            let isEndTick = i === 0 || i === this.numTicks - 1;
            // Only draw end ticks if wanted
            if (!isEndTick || this.drawEndTicks)
                ticks.push(this.addTick(currAngle, isMajor));
            currAngle += this.angleSpacing;
        }
        return ticks;
    }
    /**
     * Returns the tick radii for a non centred tick
     * @param {boolean} isMinor - whether this tick is a minor tick
     * @returns {number[]} the tick's start and end radii
     */
    getTickRadiiNonCentred(isMinor) {
        let r1 = this.getTickRadius(false);
        let r2 = this.getTickRadius(true);
        // Half size for minor ticks
        if (isMinor)
            r2 += (r1 - r2) / 2;
        return [r1, r2];
    }
    /**
     * Returns the tick radii for a centred tick
     * @param {boolean} isMinor - whether this tick is a minor tick
     * @returns {[number, number]} the tick's start and end radii
     */
    getTickRadiiCentred(isMinor) {
        let r1 = this.getTickRadius(false);
        let r2 = this.getTickRadius(true);
        if (isMinor) {
            // Make it smaller but also centre the change
            let size = this.tickLength / 2;
            r1 -= size;
            r2 += size;
        }
        return [r1, r2];
    }
    /**
     * Returns the tick radii
     * @param {boolean} isMinor - whether this tick is a minor tick
     * @returns {[number, number]} the tick's start and end radii
     */
    getTickRadii(isMinor) {
        return this.areCentred ? this.getTickRadiiNonCentred(isMinor) : this.getTickRadiiCentred(isMinor);
    }
    /**
     * Returns an RPM tick, as a pair of radii, of the given inputs. The radii returned are the
     * outer and inner radii of the tick.
     * @param {number} angle - the angle this tick sits at around the RPM
     * @param {boolean} isMinor - whether this tick is representing a minor point on the gauge (ie.
     * a thousand on an RPM gauge)
     * @returns {[Vector, Vector]} the radii of the tick
     */
    addTick(angle, isMinor) {
        let radii = this.getTickRadii(isMinor);
        return [getRelCircularPoint(this.centre, radii[0], angle), getRelCircularPoint(this.centre, radii[1], angle)];
    }
    /**
     * Returns the radius on the RPM gauge a tick will start/end at
     * @param {boolean} isInner - whether to return the inner or outer radius
     * @returns {number}
     */
    getTickRadius(isInner) {
        if (isInner)
            return this.radius - this.tickLength;
        else
            return this.radius + this.tickLength;
    }
    /**
     * Draws a tick to a canvas object
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {[Vector, Vector]} tick - the tick's start and end positions
     * @param {string} colour - the colour to draw the tick in
     */
    drawTick(ctx, tick, colour) {
        new Line(tick[0], tick[1], new Style(colour, this.tickWidth)).draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.ticks.forEach(tick => this.drawTick(ctx, tick, this.colour));
    }
}
/**
 * Represents an object that can display text
 */
class TextDisplayer extends AbstractDataDisplayer {
    /**
     * @constructor
     * @param {Text} text - the text to display
     */
    constructor(text) {
        super();
        this.text = text;
    }
    /**
     * @override
     * @inheritDoc
     * @param {string} data - the new text
     */
    update(data) {
        this.text.setText(data);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.text.draw(ctx);
    }
}
/**
 * Represents a component that can display the current boost value of a turbo object in the form of
 * a full gauge
 */
class BoostGaugeComponent extends AbstractGaugeComponent {
    /**
     * @constructor
     * @param {FullGauge} fullGauge - the gauge to display on
     */
    constructor(fullGauge) {
        super(fullGauge);
    }
    /**
     * @override
     * @param {Turbo} object - the engine of the vehicle to display info about
     */
    updateGauge(object) {
        const VALUE = object.getBoost();
        let updateData = {
            ticks: object.getNormBoost(),
            pointer: VALUE,
            arcBar: VALUE
        };
        this.gauge.update(updateData);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.updateGauge(data);
    }
}
/**
 * Represents a component that displays the current gear
 */
class GearComponent extends AbstractTextDisplayerComponent {
    /**
     * @constructor
     * @param {TextDisplayer} textDisplayer - the text displayer that will display the gear
     * @param {Drawable} shiftPrompt - the shift prompter
     */
    constructor(textDisplayer, shiftPrompt) {
        super(textDisplayer);
        this.shiftPrompt = shiftPrompt;
        this.shouldShift = false;
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.textDisplayer.update(data.gearbox.getGearName());
        this.shouldShift = data.shouldShift;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        if (this.shouldShift)
            this.shiftPrompt.draw(ctx);
        super.draw(ctx);
    }
}
/**
 * Represents a component that can draw and update the vehicles RPM as a full gauge
 */
class RPMComponent extends AbstractGaugeComponent {
    /**
     * @constructor
     * @param {FullGauge} gauge - the gauge to display the RPM on
     */
    constructor(gauge) {
        super(gauge);
    }
    /**
     * @override
     * @inheritDoc
     */
    updateGauge(object) {
        let value = object.getCurrentRPM();
        let updateData = {
            ticks: object.getCurrentRPMRatio(),
            pointer: value,
            arcBar: value
        };
        this.gauge.update(updateData);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.updateGauge(data);
    }
}
/**
 * Represents a textual representation of the parking brake
 */
class TextParkingBrakeComponent extends AbstractTextDisplayerComponent {
    /**
     * @constructor
     * @param {DualColourTextDisplayer} textDisplayer - the displayer
     */
    constructor(textDisplayer) {
        super(textDisplayer);
    }
    /**
     * @override
     * @inheritDoc
     * @param {boolean} data - whether the parking brake is on
     */
    update(data) {
        this.textDisplayer.changeTextColour(data);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.textDisplayer.draw(ctx);
    }
}
/**
 * Represents a pressure gauge builder class that can build a FullGauge object
 */
class AbstractPressureGaugeBuilder extends AbstractFullGaugeBuilder {
    setMaxBoost(maxBoost) {
        this.maxBoost = maxBoost;
        return this;
    }
    setMaxBoostConverted(maxBoostConverted) {
        this.maxBoostConverted = maxBoostConverted;
        return this;
    }
    createValueRange() {
        return new NumberRange(-this.maxBoost, this.maxBoost);
    }
    /**
     * Creates and returns a numbering system with numbers arranged in an arc
     * @param {number} radius - the radius of the arc
     * @param {number} fontSize - the font size for the numbers
     * @param {number} numNumbers - the number of numbers to show
     * @param {NumberRange} angleRange - the min and max angles for the start and end numbers
     * @param {string} colour - the colour of the text
     * @return {ArcNumbering} the numbering system created
     */
    createBasicNumbering(radius, fontSize, numNumbers, angleRange, colour) {
        let numbers = generateEquidistantValues(-this.maxBoostConverted, this.maxBoostConverted, numNumbers, this.getDecimalPlacesToShow());
        let arcNumbering = createBasicNumbering(radius, fontSize, this.fontName, numbers, this.centre, angleRange, this.ctx);
        arcNumbering.setColour(colour);
        return arcNumbering;
    }
    /**
     * @return {number} the number of decimal places that will be used for the numbering system
     */
    getDecimalPlacesToShow() {
        return this.maxBoostConverted > 10 ? 0 : 1;
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setMaxBoostConverted(builder.maxBoostConverted);
        this.setFontName(builder.fontName);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new BoostGaugeComponent(this.createFullGauge());
    }
}
applyMixins(AbstractPressureGaugeBuilder, [HasFontName]);
/**
 * Represents an RPM gauge builder class that can build a FullGauge object
 */
class AbstractRPMGaugeBuilder extends AbstractFullGaugeBuilder {
    setEngine(engine) {
        this.engine = engine;
        return this;
    }
    setArcRange(arcRange) {
        this.arcRange = arcRange;
        return this;
    }
    /**
     * Creates and returns a numbering system with numbers arranged in an arc
     * @param {number} radius - the radius of the arc
     * @param {number} fontSize - the font size for the numbers
     * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
     * @return {ArcNumbering} the numbering system created
     */
    createBasicNumbering(radius, fontSize, drawStartAndEndNumbers = true) {
        let numbering = createBasicNumbering(radius, fontSize, this.fontName, this.getNumbersToDisplay(), this.centre, this.arcRange, this.ctx, drawStartAndEndNumbers);
        numbering.setColour(this.getNumberColours());
        return numbering;
    }
    /**
     * Returns the numbers to display for the engine RPM
     * @return {number[]} the numbers to display
     */
    getNumbersToDisplay() {
        let numbers = this.getRPMNumbers();
        let numNums = numbers.length;
        if (numNums > AbstractRPMGaugeBuilder.MAXNUMS)
            numbers = this.squishRPMs(numbers);
        return numbers;
    }
    /**
     * Returns the colours for each RPM thousand, with 'white' denoting smaller than max RPM, and
     * 'red' denoting >= max RPM
     * @returns {string[]} the RPM thousand colours
     */
    getNumberColours() {
        return this.getRPMNumbers().map(n => (n * 1000 < this.engine.getMaxRPM() ? "white" : "red"));
    }
    /**
     * Returns the RPM whole thousand numbers for the engine
     * @returns {number[]} the RPM whole thousands
     */
    getRPMNumbers() {
        return arithmeticSeries(0, 1, this.engine.getRedlineThousand() + 1);
    }
    /**
     * @returns {number} the angle at which redline begins for the gauge
     */
    getRedlineAngle() {
        return this.arcRange.getLinearRatio(this.engine.getRedlineRPMRatio());
    }
    createRedlineRange() {
        return new NumberRange(this.getRedlineAngle(), this.arcRange.getUpper());
    }
    createValueRange() {
        return new NumberRange(0, this.engine.getRedLineRPM());
    }
    /**
     * Reduces the number of numbers to a more suitable amount. The maximal amount is dictated by <b>
     * AbstractRPMGaugeBuilder.MAXNUMS </b>
     * @param {[number]} numbers - the numbers to reduce
     * @return {[number]} the reduced numbers
     */
    squishRPMs(numbers) {
        const MAXNUMS = AbstractRPMGaugeBuilder.MAXNUMS;
        let gapBetweenTerms = Math.floor(numbers.length / MAXNUMS) + 1;
        return partition(numbers, gapBetweenTerms);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setFontName(builder.fontName);
        this.setEngine(builder.engine);
        this.setArcRange(builder.arcRange);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new RPMComponent(this.createFullGauge());
    }
}
// The maximum number of numbers to show for the numbering system
AbstractRPMGaugeBuilder.MAXNUMS = 15;
applyMixins(AbstractRPMGaugeBuilder, [HasFontName, HasColourScheme]);
/**
 * Represents a component that can builder a gear component that displays the current gear and a shift prompter in the
 * shape of an arrow on the top left side (relative to the gear text)
 */
class ArrowShifterGearBuilder extends AbstractGearBuilder {
    setShifterPosition(shifterPosition) {
        this.shifterPosition = shifterPosition;
        return this;
    }
    setShifterStyle(shifterStyle) {
        this.shifterStyle = shifterStyle;
        return this;
    }
    setArrowScale(arrowScale) {
        this.arrowScale = arrowScale;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    createShiftPrompt() {
        let arrow = new Arrow(this.arrowScale, this.shifterStyle, this.shifterPosition, this.shifterPosition);
        // Angle up
        arrow.setAngle(1.5 * Math.PI);
        return arrow;
    }
    /**
     * @override
     * @inheritDoc
     */
    createTextDisplayer() {
        return new TextDisplayer(this.text);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setArrowScale(builder.arrowScale);
        this.setText(builder.text);
        this.setShifterStyle(builder.shifterStyle);
        this.setShifterPosition(builder.shifterPosition);
        return this;
    }
}
applyMixins(ArrowShifterGearBuilder, [HasColourScheme, HasText]);
class RectangleShifterGearBuilder extends AbstractGearBuilder {
    setRectangle(rectangle) {
        this.rectangle = rectangle;
        return this;
    }
    setTextStyle(textStyle) {
        this.textStyle = textStyle;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    createShiftPrompt() {
        return this.rectangle;
    }
    /**
     * @override
     * @inheritDoc
     */
    createTextDisplayer() {
        // Manually apply a fix to centre the text properly; automatic way not handled by Beam's version of chrome yet
        const POS = Vector.add(this.centre, new Vector(0, 2));
        if (!this.textStyle)
            this.textStyle = Style.noStrokeFill(this.colourScheme.GEAR.getPrimary());
        let text = new Text(this.font, "", POS, this.textStyle);
        return new TextDisplayer(text);
    }
}
applyMixins(RectangleShifterGearBuilder, [HasFont]);
/**
 * Represents a gear component builder that can build a gear component that has a text display for the gear and a ring
 * that outlines this text for a shift prompter
 */
class RingShifterGearBuilder extends AbstractGearBuilder {
    setRingRadius(ringRadius) {
        this.ringRadius = ringRadius;
        return this;
    }
    setRingWidth(ringWidth) {
        this.ringWidth = ringWidth;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    createShiftPrompt() {
        let style = new Style(this.colourScheme.GEAR.getSecondary(), this.ringWidth);
        return new Circle(this.ringRadius, style, this.centre);
    }
    /**
     * @override
     * @inheritDoc
     */
    createTextDisplayer() {
        // Manually apply a fix to centre the text properly; automatic way not handled by Beam's version of chrome yet
        const POS = Vector.add(this.centre, new Vector(0, 2));
        const STYLE = Style.noStrokeFill(this.colourScheme.GEAR.getPrimary());
        let text = new Text(this.font, "", POS, STYLE);
        return new TextDisplayer(text);
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setFont(builder.font);
        this.setRingWidth(builder.ringWidth);
        this.setRingRadius(builder.ringRadius);
        return this;
    }
}
applyMixins(RingShifterGearBuilder, [HasFont]);
/**
 * Represents a builder class for creating an indicators component where both indicators are mirror versions of one
 * another
 */
class AbstractMirroredIndicatorsBuilder extends AbstractIndicatorsBuilder {
    setDistance(value) {
        this.distance = value;
        return this;
    }
    /**
     * Returns the position for either the left or right indicator (controlled using the {@link isLeft} parameter)
     * @param {boolean} isLeft - whether to return te position for the left indicator
     * @returns {Vector} the position for that indicator
     * @protected
     */
    getPositioning(isLeft) {
        const SPACING = this.distance / 2;
        let padding = isLeft ? -SPACING : SPACING;
        return Vector.add(this.centre, new Vector(padding, 0));
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setCentre(builder.centre);
        this.setDistance(builder.distance);
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    build() {
        return new IndicatorsComponent(this.createIndicatorShape(true), this.createIndicatorShape(false), this.unlitStyle);
    }
}
class FloatingUnitisedBuilder extends AbstractUnitisedBuilder {
    setUnitPosition(unitPosition) {
        this.unitPosition = unitPosition;
        return this;
    }
    setValuePosition(valuePosition) {
        this.valuePosition = valuePosition;
        return this;
    }
    createUnitText() {
        return this.createText(this.unitFontSize, this.unitPosition, this.getUnitStyle());
    }
    createValueText() {
        return this.createText(this.valueFontSize, this.valuePosition, this.getValueStyle());
    }
}
/**
 * Represents a builder that can build an unitised component that has its 'value' text stacked on top of its 'unit' text
 */
class StackedUnitisedBuilder extends AbstractUnitisedBuilder {
    setPadding(value) {
        this.padding = value;
        return this;
    }
    /**
     * Returns the position of one of the texts, given whether they are the top or bottom element
     * @param {boolean} isTop - whether the position returned will be for the top element
     * @return {Vector} the position
     */
    getPosition(isTop) {
        let yCoord = isTop ? -this.padding : this.padding;
        return Vector.add(this.centre, new Vector(0, yCoord));
    }
    /**
     * @override
     * @inheritDoc
     */
    createValueText() {
        return this.createText(this.valueFontSize, this.getPosition(true), this.getValueStyle());
    }
    /**
     * @override
     * @inheritDoc
     */
    createUnitText() {
        return this.createText(this.unitFontSize, this.getPosition(false), this.getUnitStyle());
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setPadding(builder.padding);
        this.setColourScheme(builder.colourScheme);
        this.setUnitFontSize(builder.unitFontSize);
        this.setValueFontSize(builder.valueFontSize);
        this.setFontName(builder.fontName);
        return this;
    }
}
applyMixins(StackedUnitisedBuilder, [HasFontName]);
/**
 * Represents a bar display in an arc format
 */
class ArcBarDisplayer extends AbstractBoundedDataDisplayer {
    /**
     * @constructor
     * @param {NumberRange} valueRange - the value range possible to display
     * @param {ArcBar} arcBar - the arc bar that will show the value
     */
    constructor(valueRange, arcBar) {
        super(valueRange);
        this.arcBar = arcBar;
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.setValueOf(data, this.arcBar);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.arcBar.draw(ctx);
    }
}
/**
 * Represents an arc bar displayer, where a part of the end of the bar has a cap on it.
 * Useful for bars that have a 'warning' area where the bar shouldn't exceed
 */
class LimitedArcBarDisplayer extends AbstractBoundedDataDisplayer {
    /**
     * @constructor
     * @param {NumberRange} valueRange - the value range of the displayer that marks the lowest and highest
     * values that will be displayed
     * @param {ArcBar} mainArcBar - the arc bar that will show the current value
     * @param {ArcBar} limitArcBar - the arc bar that will show the 'limit' part of the bar
     */
    constructor(valueRange, mainArcBar, limitArcBar) {
        super(valueRange);
        this.mainArcBar = mainArcBar;
        this.limitArcBar = limitArcBar;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.mainArcBar.draw(ctx);
        this.limitArcBar.draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.setValueOf(data, this.mainArcBar);
    }
}
/**
 * Represents arc ticks where there are two groups of colouring, specified by a threshold value
 */
class DualColourArcTicks extends ArcTicks {
    /**
     * @constructor
     * @see ArcTicks for default parameters and how to change them
     * @param {Vector} centre - the centre of the display
     * @param {number} radius - the distance between the display centre and each tick's centre
     * @param {number} numTicks - the number of ticks to have
     * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
     * @param {ColourPriority} colours - the colours for the tick
     * @param {number} threshold - the threshold value. Defaults to 0
     */
    constructor(centre, radius, numTicks, arcRange, colours, threshold = 0) {
        super(centre, radius, numTicks, arcRange);
        this.colours = colours;
        this.threshold = threshold;
    }
    /**
     * Returns the accent colour of a tick based on whether it has surpassed a threshold.
     * More specifically, a tick that surpasses the threshold will return the secondary colour, and
     * vice versa for the primary colour
     * @param {boolean} isThresholdPassed - whether the tick being drawn is over the current threshold
     * @returns {string} the accent colour
     */
    getAccentColour(isThresholdPassed) {
        return isThresholdPassed ? this.colours.getSecondary() : this.colours.getPrimary();
    }
    /**
     * Returns whether a particular tick is past the threshold or not
     * @param {number} tickIndex - the tick's index
     * @returns {boolean} whether this tick is past the threshold or not
     */
    isTickPassedThreshold(tickIndex) {
        if (this.drawEndTicks)
            // -1 as indexes start at 0
            return tickIndex / (this.numTicks - 1) >= this.threshold;
        // No end tick at the start so shift everything up by 1 index
        else
            return (tickIndex + 1) / (this.numTicks + 1) >= this.threshold;
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        for (let i = 0; i < this.numTicks; i++) {
            let colour = this.getAccentColour(this.isTickPassedThreshold(i));
            this.drawTick(ctx, this.ticks[i], colour);
        }
    }
}
/**
 * Represents a pointer that points at the angle that the value represents
 */
class AbstractGaugePointer extends AbstractBoundedDataDisplayer {
    /**
     * @constructor
     * @param {Vector} centre - the centre of the pointer
     * @param {NumberRange} valueRange - the value range possible to displayer
     * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
     */
    constructor(centre, valueRange, arcAngles) {
        super(valueRange);
        this.centre = centre;
        this.arcAngles = arcAngles;
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        let perc = this.getPerc(data);
        let angle = this.arcAngles.getLinearRatio(perc);
        this.setActiveAngle(angle);
    }
    /**
     * Returns the angle 180deg added to the current angle. Note that the value returned will
     * always be +180deg from the current, regardless of whether this makes the angle bigger than
     * 360deg
     * @param {number} angle - the angle to get the inverse of
     * @returns {number} the angle 180deg plus the current angle, in radians
     */
    getInvAngle(angle) {
        return angle + Math.PI;
    }
}
/**
 * Represents text that can be displayed in two different colours, given a particular condition is
 * true or false
 */
class DualColourTextDisplayer extends TextDisplayer {
    /**
     * @constructor
     * @param {Text} text - the text to displayer
     * @param {ColourPriority} colours - the colours
     */
    constructor(text, colours) {
        super(text);
        this.colours = colours;
    }
    /**
     * Changes the colour of the text
     * @param {boolean} useFirstColour - whether to use the primary colour
     */
    changeTextColour(useFirstColour) {
        this.text.setColour(this.colours.getFromBool(useFirstColour));
    }
}
/**
 * Represents a drawable shape
 */
class AbstractShape extends Rotatable {
    /**
     * @constructor
     * @param {BaseStyle} styling - the styling to apply to the shape
     * @param {Vector} [centre] - the centre point of the shape. Defaults to (0,0)
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(styling, centre = new Vector(), rotationalCentre = new Vector()) {
        super(centre, rotationalCentre);
        this.styling = styling;
        this.setRotationalCentre(rotationalCentre);
    }
    /**
     * @Override
     * @inheritDoc
     */
    draw(ctx) {
        ctx.beginPath();
        this.applyRotation(ctx);
        this.drawContinue(ctx);
        this.applyStyling(ctx);
        Canvas.resetTransformationState(ctx);
    }
    /**
     * Applies the styling of this shape to a 2D canvas context
     * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to apply this
     * shapes styling to
     */
    applyStyling(ctx) {
        this.styling.apply(ctx);
    }
    /**
     * Applies the rotation transformation of a canvas 2D context for drawing the rotated shape
     * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to rotate
     */
    applyRotation(ctx) {
        ctx.translate(this.rotCentre.x(), this.rotCentre.y());
        ctx.rotate(this.angle);
        ctx.translate(-this.rotCentre.x(), -this.rotCentre.y());
    }
}
/**
 * Represents a shape comprised of multiple other shapes
 */
class MultiShape extends Rotatable {
    /**
     * @constructor
     * @param {AbstractShape[]} shapes - the list of shapes
     * @param {Vector} centre - the centre point (should be the average position of all shapes).
     * Defaults to (0,0)
     * @param {Vector} [rotCentre] - the centre of rotation. Defaults to (0,0)
     */
    constructor(shapes, centre = new Vector(), rotCentre = new Vector()) {
        super(centre, rotCentre);
        this.shapes = shapes;
    }
    /**
     * Adds a shape to the list of shapes
     * @param {AbstractShape} shape - the shape to add
     */
    addShape(shape) {
        this.shapes.push(shape);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.shapes.forEach(shape => shape.draw(ctx));
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Fusion Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the fusion version of the boost app
 */
class FusionBoostApp extends AbstractBoostApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(FUSION_THEME, baseRadius, document, bngApi, FusionPressureGaugeBuilder, FusionBoostBackground);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPressureReadout() {
        return this.setDefaultBuilderValues(FusionStackedUnitisedBuilder)
            .setQuantity(this.getQuantityInstance())
            .build();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
class FusionPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
    /**
     * @override
     * @inheritDoc
     */
    createTicks() {
        let ticks = new ArcTicks(this.centre, FusionPressureGaugeBuilder.OUTER_TICK_BASE_RADIUS, 41, FUSION_THEME.MAIN_ANGLE_RANGE);
        ticks.setTickLength(6);
        ticks.setTickWidth(2);
        ticks.setMajorSpacing(10);
        ticks.setTickColour(this.colourScheme.TICKS.getSecondary());
        return ticks;
    }
    /**
     * @override
     * @inheritDoc
     */
    createArcBar() {
        return null;
    }
    /**
     * @override
     * @inheritDoc
     */
    createNumbering() {
        // The font size for the numbering; decrease as number of digits to display increases
        const FONTSIZE = 10 - Math.floor(this.maxBoostConverted).toString().length;
        return this.createBasicNumbering(50, FONTSIZE, 5, FUSION_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPointer() {
        return FusionThemeHelper.createPointer(this.centre, this.createValueRange(), FusionPressureGaugeBuilder.OUTER_TICK_BASE_RADIUS, 38, this.radius, this.ctx);
    }
}
FusionPressureGaugeBuilder.OUTER_TICK_BASE_RADIUS = 65;
applyMixins(FusionPressureGaugeBuilder, [HasColourScheme, HasRadius]);
class FusionStackedUnitisedBuilder extends StackedUnitisedBuilder {
    /**
     * @constructor
     * Sets the value font size to 16.
     * Sets the unit font size to 12.
     * Sets the padding to 10
     */
    constructor() {
        super();
        this.setValueFontSize(16);
        this.setUnitFontSize(12);
        this.setPadding(10);
    }
    /**
     * Returns the gradient style for a text element
     * @param {Vector} position - the position the text element will be placed at
     * @param {number} fontSize - the size of the font which will be used to render the text
     * @return {Style} the style object
     */
    getGradient(position, fontSize) {
        return Style.noStrokeFill(new LinearGradient(Vector.add(position, new Vector(0, -fontSize / 2)), Vector.add(position, new Vector(0, fontSize / 2)), AbstractGradient.distributeEvenly(["white", this.colourScheme.UNIT])).createGradient(this.ctx));
    }
    /**
     * @override
     * @inheritDoc
     */
    getUnitStyle() {
        return this.getGradient(this.getPosition(false), this.unitFontSize);
    }
    /**
     * @override
     * @inheritDoc
     */
    getValueStyle() {
        return this.getGradient(this.getPosition(true), this.valueFontSize);
    }
}
applyMixins(FusionStackedUnitisedBuilder, [CanDraw]);
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background elements that can be drawn to the background canvas for the fusion
 * version of the boost app
 */
class FusionBoostBackground extends FusionBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        this.drawMainBackground(72, 60);
        this.drawGlass(60);
        this.drawInnerDivider(39, 5);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Fusion Tachometer App Class //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the fusion version of the tachometer app
 */
class FusionTachometerApp extends AbstractTachometerApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(FUSION_THEME, baseRadius, document, bngApi, FusionRPMGaugeBuilder, FusionTachometerBackground);
    }
    /**
     * Creates the gear gradient
     * @param {Vector} position - the position of the gear text
     * @param {number} fontSize - the font size of the gear text
     * @return {LinearGradient} the gradient
     */
    static createGearGradient(position, fontSize) {
        return new LinearGradient(position, Vector.sub(position, new Vector(0, fontSize)), AbstractGradient.distributeEvenly(["#888888", "white"]));
    }
    /**
     * @override
     * @inheritDoc
     */
    getLightColour(lightState) {
        switch (lightState) {
            case 0:
                return "rgba(255, 255, 255, 0.25)";
            case 1:
                return "rgba(0, 255, 0, 0.5)";
            case 2:
                return "rgba(0, 0, 255, 0.5)";
        }
    }
    /**
     * @override
     * @inheritDoc
     */
    createGearComponent() {
        const FONTSIZE = 40;
        const TEXT_POS = Vector.add(this.centre, new Vector(20, 45));
        const SHIFTER_POS = Vector.add(this.centre, new Vector(13, 25));
        const FONT = new Font(this.theme.FONT_NAME, FONTSIZE, false);
        const STYLE = Style.noStrokeFill(FusionTachometerApp.createGearGradient(TEXT_POS, FONTSIZE).createGradient(this.canvas.get2DContext()));
        return this.setDefaultBuilderValues(ArrowShifterGearBuilder)
            .setText(new Text(FONT, "", TEXT_POS, STYLE))
            .setShifterPosition(SHIFTER_POS)
            .setShifterStyle(STYLE)
            .setArrowScale(1.25)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createIndicatorsComponent() {
        return new ArrowIndicatorsBuilder()
            .setCentre(Vector.add(this.centre, new Vector(-30, 20)))
            .setDistance(10)
            .setScale(1.7)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createBarCollectionBuilder() {
        return new PairedBarCollectionBuilder()
            .setCentre(this.centre)
            .setInnerRadius(130)
            .setOuterRadius(140)
            .setArcWidth(6)
            .setTempFuelArcRange(new NumberRange(Math.PI * 2.20, Math.PI * 2.45))
            .setThottleBrakeArcRange(new NumberRange(Math.PI * 1.85, Math.PI * 2.10))
            .setCapStyle("round")
            .setInvertArcDirections(true);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPBrakeComponent() {
        return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
            .setCentre(Vector.add(this.centre, new Vector(-31, 55)))
            .setFont(new Font(this.theme.FONT_NAME, 16, true))
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createSpeedoComponent() {
        return this.setDefaultBuilderValues(FusionSpeedometer)
            .setQuantity(this.getQuantityInstance())
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    getNewUnitInstance() {
        let unit = new UnitConversion(Quantity.speed());
        let formatter = new MinLengthFormatter(3);
        return new Quantity(unit, formatter);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
class FusionSpeedometer extends AbstractUnitisedBuilder {
    /**
     * @constructor
     * Sets font name to {@link FUSION_THEME}'s FONT_NAME
     */
    constructor() {
        super();
        this.setFontName(FUSION_THEME.FONT_NAME);
    }
    /**
     * Returns the styling for a component piece of the text
     * @param {Vector} basePos - the position the text object will sit at
     * @param {number} fontSize - the size of the font that will be used
     * @return {Style} the style created
     */
    getStyle(basePos, fontSize) {
        let padding = new Vector(0, fontSize / 2);
        return Style.noStrokeFill(new LinearGradient(Vector.sub(basePos, padding), Vector.add(basePos, padding), AbstractGradient.distributeEvenly(["white", this.colourScheme.UNIT])).createGradient(this.ctx));
    }
    /**
     * @override
     * @inheritDoc
     */
    createText(fontSize, pos) {
        let font = new Font(this.fontName, fontSize, true);
        return new Text(font, "", pos, this.getStyle(pos, fontSize));
    }
    /**
     * @override
     * @inheritDoc
     */
    createUnitText() {
        const POS = Vector.add(this.centre, new Vector(52, -18));
        return this.createText(18, POS);
    }
    /**
     * @override
     * @inheritDoc
     */
    createValueText() {
        const POS = Vector.add(this.centre, new Vector(-15, -25));
        return this.createText(46, POS);
    }
}
applyMixins(FusionSpeedometer, [HasColourScheme, CanDraw]);
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents a builder class for creating the velocity version of the RPM component
 */
class FusionRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
    /**
     * @constructor
     * Sets arc range to {@link FusionThemeHelper.MAIN_ANGLE_RANGE}
     */
    constructor() {
        super();
        this.setArcRange(FUSION_THEME.MAIN_ANGLE_RANGE);
    }
    /**
     * @override
     * @inheritDoc
     */
    createTicks() {
        // The RPM spacing between two ticks
        const TICK_SPACING = 100;
        // The number of ticks
        const NUM_TICKS = Math.floor(this.engine.getRedLineRPM() / TICK_SPACING) + 1;
        // The number of ticks between one major tick and another
        const MAJOR_TICK_SPACING = 1000 / TICK_SPACING;
        let ticks = new DualColourArcTicks(this.centre, FusionRPMGaugeBuilder.INNER_RPM_RADIUS, NUM_TICKS, this.arcRange, new ColourPriority(this.colourScheme.TICKS.getSecondary(), "red"), this.engine.getRedlineRPMRatio());
        ticks.setTickWidth(2);
        ticks.setTickLength(10);
        ticks.setMajorSpacing(MAJOR_TICK_SPACING);
        return ticks;
    }
    /**
     * @override
     * @inheritDoc
     */
    createNumbering() {
        return this.createBasicNumbering(110, 18);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPointer() {
        return FusionThemeHelper.createPointer(this.centre, this.createValueRange(), FusionRPMGaugeBuilder.INNER_RPM_RADIUS, 88, FusionRPMGaugeBuilder.BASERADIUS, this.ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    createArcBar() {
        return null;
    }
}
FusionRPMGaugeBuilder.BASERADIUS = 150;
// The inner radius of the RPM arc
FusionRPMGaugeBuilder.INNER_RPM_RADIUS = 134;
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background of the unknown tachometer app.
 * Responsible for drawing the necessary background elements
 */
class FusionTachometerBackground extends FusionBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} radius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, radius, colourScheme) {
        super(ctx, centre, radius, colourScheme);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        // The inner radius at which the ticks are place at
        const TICKRADIUS = 120;
        this.drawMainBackground(144, TICKRADIUS);
        this.drawGlass(TICKRADIUS);
        this.drawInnerDivider(90, 8);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Ringularity Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the nu version of the boost app
 */
class RingularityBoostApp extends AbstractBoostApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(RINGULARITY_THEME, baseRadius, document, bngApi, RingularityPressureGaugeBuilder, RingularityBoostBackground);
    }
    createPressureReadout() {
        return this.setDefaultBuilderValues(StackedUnitisedBuilder)
            .setQuantity(this.getQuantityInstance())
            .setValueFontSize(18)
            .setUnitFontSize(10)
            .setPadding(12)
            .build();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
class RingularityPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
    /**
     * Creates and returns a Style object for the arc bar with a gradient from the given colours
     * @param {string[]} colours - the colours to use for the gradient
     * @returns {Style} the gradient style created
     * @private
     */
    getGradientStyle(colours) {
        return RingularityThemeHelper.getGradientStyle(colours, RingularityPressureGaugeBuilder.RADIUS, this.centre, 24, this.ctx);
    }
    createArcBar() {
        let mainStyle = this.getGradientStyle(RingularityThemeHelper.getArcbarColourPair(this.colourScheme));
        let backgroundStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(40, 40, 40)"));
        let mainArcBar = new ArcBar(RingularityPressureGaugeBuilder.RADIUS, RINGULARITY_THEME.MAIN_ANGLE_RANGE.clone(), mainStyle, backgroundStyle, this.centre);
        return new ArcBarDisplayer(this.createValueRange(), mainArcBar);
    }
    createNumbering() {
        // The font size for the numbering; decrease as number of digits to display increases
        const FONTSIZE = 10 - Math.floor(this.maxBoostConverted).toString().length;
        return this.createBasicNumbering(48, FONTSIZE, 5, RINGULARITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
    }
    createPointer() {
        return null;
    }
    createTicks() {
        let ticks = new ArcTicks(this.centre, 62, 17, RINGULARITY_THEME.MAIN_ANGLE_RANGE);
        ticks.setTickWidth(2);
        ticks.setTickLength(5);
        return ticks;
    }
}
RingularityPressureGaugeBuilder.RADIUS = 57;
applyMixins(RingularityPressureGaugeBuilder, [HasColourScheme]);
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background elements that can be drawn to the background canvas for the Ringularity
 * version of the boost app
 */
class RingularityBoostBackground extends RingularityBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
    }
    /**
     * Draws the background rectangles for both the unit and value
     * @private
     */
    drawUnitAndValueBackgrounds() {
        new Rectangle(48, 24, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.add(this.centre, new Vector(-24, -25)), true).draw(this.ctx);
        new Rectangle(48, 18, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.add(this.centre, new Vector(-24, 3)), true).draw(this.ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        this.drawGlassInnerCircle(this.baseRadius);
        this.drawMainBackground(60, RingularityPressureGaugeBuilder.RADIUS, 33);
        this.drawGaugeArcStrokeLines(2, [42, 72]);
        this.drawUnitAndValueBackgrounds();
        this.drawBottomRightArc(RingularityPressureGaugeBuilder.RADIUS, 26);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Ringularity Tachometer App Class //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the Ringularity version of the tachometer app
 */
class RingularityTachometerApp extends AbstractTachometerApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(RINGULARITY_THEME, baseRadius, document, bngApi, RingularityRPMGaugeBuilder, RingularityTachometerBackground);
    }
    /**
     * @override
     * @inheritDoc
     */
    createGearComponent() {
        const BG_STYLE = new Style("#666", 3);
        const TEXT_CENTRE = Vector.add(this.centre, new Vector(-26, 30));
        const WIDTH = 44;
        const HEIGHT = 56;
        return this.setDefaultBuilderValues(RectangleShifterGearBuilder)
            .setCentre(TEXT_CENTRE)
            .setFont(new Font(this.theme.FONT_NAME, 34, true))
            .setTextStyle(new Style(this.colourScheme.GEAR.getPrimary(), 4, true))
            .setRectangle(new Rectangle(WIDTH, HEIGHT, BG_STYLE, Vector.sub(TEXT_CENTRE, new Vector(WIDTH / 2, HEIGHT / 2))))
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createIndicatorsComponent() {
        return this.setDefaultBuilderValues(LineIndicatorsBuilder)
            .setUnlitStyle(new Style("black", 5))
            .setDistance(110)
            .setYCoordinates(3, 58)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createBarCollectionBuilder() {
        return new PairedBarCollectionBuilder()
            .setCentre(this.centre)
            .setInnerRadius(107)
            .setOuterRadius(123)
            .setArcWidth(10)
            .setTempFuelArcRange(new NumberRange(2.315 * Math.PI, 2.475 * Math.PI))
            .setThottleBrakeArcRange(new NumberRange(2.025 * Math.PI, 2.185 * Math.PI))
            .setInvertArcDirections(true)
            .setCapStyle('butt');
    }
    /**
     * @override
     * @inheritDoc
     */
    createPBrakeComponent() {
        return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
            .setCentre(Vector.add(this.centre, new Vector(25, 47)))
            .setFont(new Font(RINGULARITY_THEME.FONT_NAME, 14, true))
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createSpeedoComponent() {
        return this.setDefaultBuilderValues(FloatingUnitisedBuilder)
            .setUnitFontSize(18)
            .setValueFontSize(44)
            .setValuePosition(Vector.add(this.centre, new Vector(0, -28)))
            .setUnitPosition(Vector.add(this.centre, new Vector(26, 15)))
            .setQuantity(this.getQuantityInstance())
            .build();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
class RingularityRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
    /**
     * @constructor
     * Sets arc range to {@link RINGULARITY_THEME.MAIN_ANGLE_RANGE}
     */
    constructor() {
        super();
        this.setArcRange(RINGULARITY_THEME.MAIN_ANGLE_RANGE);
    }
    /**
     * Creates and returns a Style object for the arc bar with a gradient from the given colours
     * @param {string[]} colours - the colours to use for the gradient
     * @returns {Style} the gradient style created
     * @private
     */
    getGradientStyle(colours) {
        return RingularityThemeHelper.getGradientStyle(colours, RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.centre, 43, this.ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    createArcBar() {
        let mainStyle = this.getGradientStyle(RingularityThemeHelper.getArcbarColourPair(this.colourScheme));
        let limitStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(255, 0, 0)"));
        let backgroundStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(40, 40, 40)"));
        let mainArcBar = new ArcBar(RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.arcRange.clone(), mainStyle, backgroundStyle, this.centre);
        let limitArcBar = new ArcBar(RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.createRedlineRange(), limitStyle, backgroundStyle, this.centre);
        return new LimitedArcBarDisplayer(this.createValueRange(), mainArcBar, limitArcBar);
    }
    /**
     * @override
     * @inheritDoc
     */
    createNumbering() {
        return this.createBasicNumbering(105, 18, false);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPointer() {
        return null;
    }
    /**
     * @override
     * @inheritDoc
     */
    createTicks() {
        // The RPM spacing between two ticks
        const TICKSPACING = 250;
        let numTicks = Math.floor(this.engine.getRedLineRPM() / TICKSPACING) + 1;
        let ticks = new ArcTicks(this.centre, RingularityRPMGaugeBuilder.INNER_RPM_RADIUS + 11, numTicks, this.arcRange);
        ticks.setTickWidth(2);
        ticks.setTickLength(7);
        ticks.setDrawEndTicks(false);
        return ticks;
    }
}
// The inner radius of the RPM arc
RingularityRPMGaugeBuilder.INNER_RPM_RADIUS = 116;
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background of the Ringularity tachometer app.
 * Responsible for drawing the necessary background elements
 */
class RingularityTachometerBackground extends RingularityBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} baseRadius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, baseRadius, colourScheme) {
        super(ctx, centre, baseRadius, colourScheme);
    }
    /**
     * Draws the background rectangles for the speedometer value and unit
     * @private
     */
    drawSpeedometer() {
        this.drawSpeedometerValue();
        // Speedometer unit
        new Rectangle(44, 26, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.add(this.centre, new Vector(3, 2)), true).draw(this.ctx);
    }
    /**
     * Draws the background rectangle for the speedometers value
     * @private
     */
    drawSpeedometerValue() {
        let background = new Rectangle(116, 48, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.add(this.centre, new Vector(-58, -54)), true);
        background.draw(this.ctx);
        if (this.lightColour !== "#000") {
            background
                .changeStyling(new Style(this.lightColour, 3))
                .draw(this.ctx);
        }
    }
    /**
     * Draws the background rectangle for the gear
     * @private
     */
    drawGear() {
        const WIDTH = 44;
        const HEIGHT = 56;
        new Rectangle(WIDTH, HEIGHT, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.sub(Vector.add(this.centre, new Vector(-26, 30)), new Vector(WIDTH / 2, HEIGHT / 2))).draw(this.ctx);
    }
    /**
     * Draws the background rectangle for the parking brake
     * @private
     */
    drawParkingBrake() {
        new Rectangle(44, 24, Style.noStrokeFill(this.colourScheme.BACKGROUND), Vector.add(this.centre, new Vector(3, 34)), true).draw(this.ctx);
    }
    draw() {
        super.draw();
        this.drawGlassInnerCircle(this.baseRadius);
        this.drawMainBackground(130, RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, 60);
        this.drawSpeedometer();
        this.drawGear();
        this.drawParkingBrake();
        this.drawBottomRightArc(116, 44);
        this.drawGaugeArcStrokeLines(4, [88, 144]);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Velocity Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the velocity version of the boost app
 */
class VelocityBoostApp extends AbstractBoostApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(VELOCITY_THEME, baseRadius, document, bngApi, VelocityPressureGaugeBuilder, VelocityBoostBackground);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPressureReadout() {
        return this.setDefaultBuilderValues(StackedUnitisedBuilder)
            .setCentre(Vector.add(this.centre, new Vector(40, 38)))
            .setQuantity(this.getQuantityInstance())
            .setValueFontSize(16)
            .setUnitFontSize(8)
            .setPadding(8)
            .build();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents a builder class for creating the velocity version of the pressure gauge component
 */
class VelocityPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
    /**
     * @override
     * @inheritDoc
     */
    createTicks() {
        let ticks = new CamoArcTicks(this.centre, VelocityPressureGaugeBuilder.RADIUS, 17, VELOCITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.TICKS);
        ticks.setTickWidth(2);
        ticks.setTickLength(10);
        return ticks;
    }
    /**
     * @override
     * @inheritDoc
     */
    createNumbering() {
        // The font size for the numbering; decrease as number of digits to display increases
        const FONTSIZE = 12 - Math.floor(this.maxBoostConverted).toString().length;
        return this.createBasicNumbering(45, FONTSIZE, 5, VELOCITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPointer() {
        const COLOUR = this.colourScheme.POINTER;
        let colours = {
            main: COLOUR.getSecondary(),
            accent: COLOUR.getPrimary(),
            dial: COLOUR.getSecondary()
        };
        return new AccentTriangleBuilder()
            .setCentre(this.centre)
            .setWidth(16)
            .setLength(VelocityPressureGaugeBuilder.RADIUS)
            .setValueRange(this.createValueRange())
            .setPointerRange(VELOCITY_THEME.MAIN_ANGLE_RANGE)
            .setColours(colours)
            .setMinorScale(0.5)
            .setAccentScale(0.35)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createArcBar() {
        let style = new Style(this.colourScheme.ARC_BAR.getPrimary(), 20);
        let bgStyle = new Style(this.colourScheme.ARC_BAR.getSecondary(), 20);
        let arcBar = new ArcBar(VelocityPressureGaugeBuilder.RADIUS, VELOCITY_THEME.MAIN_ANGLE_RANGE, style, bgStyle, this.centre);
        return new ArcBarDisplayer(this.createValueRange(), arcBar);
    }
}
VelocityPressureGaugeBuilder.RADIUS = 65;
applyMixins(VelocityPressureGaugeBuilder, [HasColourScheme]);
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background elements that can be drawn to the background canvas for the velocity
 * version of the boost app
 */
class VelocityBoostBackground extends VelocityBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} radius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, radius, colourScheme) {
        super(ctx, centre, radius, colourScheme);
    }
    /**
     * Draws the background to the parking brake
     */
    drawUnit() {
        const LEFTX = this.centre.x() + 16;
        const RANGE = new NumberRange(Math.PI * 0.08, Math.PI * 0.24);
        const STYLE = Style.noStrokeFill("black");
        new RoundCornerRectangleBR(this.baseRadius, RANGE, this.centre, LEFTX, STYLE).draw(this.ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        this.drawMainBackground(45);
        this.drawInnerDivider(4, 32);
        this.drawInnerGlass(31);
        this.drawUnit();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Velocity Tachometer App Class  //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the velocity version of the tachometer app
 */
class VelocityTachometerApp extends AbstractTachometerApp {
    /**
     * @constructor
     * @param {number} baseRadius - the radius of the outermost part of the app
     * @param {Document} document - the document element the app uses
     * @param {any} bngApi - the bngApi service
     */
    constructor(baseRadius, document, bngApi) {
        super(VELOCITY_THEME, baseRadius, document, bngApi, VelocityRPMGaugeBuilder, VelocityTachometerBackground);
    }
    /**
     * @override
     * @inheritDoc
     */
    createGearComponent() {
        return this.setDefaultBuilderValues(RingShifterGearBuilder)
            .setFont(new Font(this.theme.FONT_NAME, 34, true))
            .setRingRadius(30)
            .setRingWidth(6)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createIndicatorsComponent() {
        return new ArrowIndicatorsBuilder()
            .setCentre(Vector.add(this.centre, new Vector(80, 74)))
            .setDistance(60)
            .setScale(1.5)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createBarCollectionBuilder() {
        return new PairedBarCollectionBuilder()
            .setCentre(this.centre)
            .setInnerRadius(65)
            .setOuterRadius(75)
            .setArcWidth(6)
            .setTempFuelArcRange(new NumberRange(Math.PI * 0.5, Math.PI * 1.15))
            .setThottleBrakeArcRange(new NumberRange(Math.PI * 1.35, Math.PI * 2))
            .setInvertArcDirections(false);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPBrakeComponent() {
        return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
            .setCentre(Vector.add(this.centre, new Vector(60, 115)))
            .setFont(new Font(this.theme.FONT_NAME, 16, true))
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createSpeedoComponent() {
        return this.setDefaultBuilderValues(StackedUnitisedBuilder)
            .setCentre(Vector.add(this.centre, new Vector(80, 62)))
            .setValueFontSize(40)
            .setUnitFontSize(16)
            .setQuantity(this.getQuantityInstance())
            .setPadding(12)
            .build();
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents a builder class for creating the velocity version of the RPM component
 */
class VelocityRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
    /**
     * @constructor
     * Sets arc range to {@link VELOCITY_THEME.MAIN_ANGLE_RANGE}
     */
    constructor() {
        super();
        this.setArcRange(VELOCITY_THEME.MAIN_ANGLE_RANGE);
    }
    /**
     * @override
     * @inheritDoc
     */
    createTicks() {
        // The RPM spacing between two ticks
        const TICKSPACING = 250;
        let numTicks = Math.floor(this.engine.getRedLineRPM() / TICKSPACING) + 1;
        let ticks = new CamoArcTicks(this.centre, VelocityRPMGaugeBuilder.INNER_RPM_RADIUS, numTicks, this.arcRange, this.colourScheme.TICKS);
        ticks.setTickWidth(2);
        ticks.setTickLength(15);
        return ticks;
    }
    /**
     * @override
     * @inheritDoc
     */
    createNumbering() {
        return this.createBasicNumbering(100, 20);
    }
    /**
     * @override
     * @inheritDoc
     */
    createPointer() {
        const COLOUR = this.colourScheme.POINTER;
        let colours = {
            main: COLOUR.getSecondary(),
            accent: COLOUR.getPrimary(),
            dial: COLOUR.getSecondary()
        };
        return new AccentTriangleBuilder()
            .setCentre(this.centre)
            .setWidth(38)
            .setLength(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS)
            .setValueRange(this.createValueRange())
            .setPointerRange(this.arcRange)
            .setColours(colours)
            .setMinorScale(0.5)
            .setAccentScale(0.35)
            .build();
    }
    /**
     * @override
     * @inheritDoc
     */
    createArcBar() {
        // The width of the arc bar
        const ARC_BAR_WIDTH = 30;
        const COLOURS = this.colourScheme.ARC_BAR;
        let mainBarStyle = new Style(COLOURS.getPrimary(), ARC_BAR_WIDTH);
        let limitBarStyle = new Style("#FF0000", ARC_BAR_WIDTH);
        let backgroundStyle = new Style(COLOURS.getSecondary(), ARC_BAR_WIDTH, false);
        let mainBar = new ArcBar(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS, this.arcRange, mainBarStyle, backgroundStyle, this.centre);
        let limitBar = new ArcBar(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS, this.createRedlineRange(), limitBarStyle, backgroundStyle, this.centre);
        return new LimitedArcBarDisplayer(this.createValueRange(), mainBar, limitBar);
    }
}
// The inner radius of the RPM arc
VelocityRPMGaugeBuilder.INNER_RPM_RADIUS = 135;
////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Represents the background of the velocity tachometer app.
 * Responsible for drawing the necessary background elements
 */
class VelocityTachometerBackground extends VelocityBackground {
    /**
     * @constructor
     * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
     * @param {Vector} centre - the centre of the background
     * @param {number} radius - the base radius from the centre
     * @param {ColourScheme} colourScheme - the colour scheme to apply
     */
    constructor(ctx, centre, radius, colourScheme) {
        super(ctx, centre, radius, colourScheme);
    }
    /**
     * Draws the background to the temperature and oil bars
     */
    drawBarCollection() {
        const WIDTH = 25;
        const RADIUS = 70;
        const RANGESTART = new NumberRange(Math.PI * 0.5, Math.PI * 1.15);
        const RANGEEND = new NumberRange(Math.PI * 1.35, Math.PI * 2);
        // Draw the background to the arc bars on the start side
        let style = new Style("black", WIDTH);
        new Arc(RADIUS, RANGESTART, style, this.centre).draw(this.ctx);
        // Draw the background to the arc bars on the end side
        let style2 = new Style("black", WIDTH);
        new Arc(RADIUS, RANGEEND, style2, this.centre).draw(this.ctx);
    }
    /**
     * Applies lighting, skewed to the top left corner
     */
    applyLights() {
        this.ctx.filter = "drop-shadow(-8px -8px 8px " + this.lightColour + ")";
    }
    /**
     * Draws the background to the speedometer
     */
    drawSpeedo() {
        let range = new NumberRange(Math.PI * 0.05, Math.PI * 0.21);
        // Don't apply everything yet as lighting may need to be done
        this.ctx.beginPath();
        new RoundCornerRectangleBR(this.baseRadius, range, this.centre, VelocityTachometerBackground.BRLEFTX, null).drawContinue(this.ctx);
        this.ctx.lineWidth = 1;
        this.ctx.fillStyle = "black";
        // Apply lighting if necessary
        if (this.lightColour !== "#000") {
            this.applyLights();
            this.ctx.fill();
            Canvas.resetFilter(this.ctx);
        }
        else {
            this.ctx.fill();
        }
        Canvas.resetTransformationState(this.ctx);
    }
    /**
     * Draws the background to the parking brake
     */
    drawPBrake() {
        let range = new NumberRange(Math.PI * 0.23, Math.PI * 0.32);
        let style = Style.noStrokeFill("black");
        new RoundCornerRectangleBR(this.baseRadius, range, this.centre, VelocityTachometerBackground.BRLEFTX, style).draw(this.ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw() {
        super.draw();
        this.drawMainBackground(70);
        this.drawInnerGlass(81);
        this.drawBarCollection();
        this.drawInnerDivider(10, 85);
        this.drawSpeedo();
        this.drawPBrake();
    }
}
// The bottom right backgrounds' leftmost x coordinate for rounded rectangles
VelocityTachometerBackground.BRLEFTX = 173;
/**
 * Represents a builder class for creating an indicators component where both indicators are arrows
 */
class ArrowIndicatorsBuilder extends AbstractMirroredIndicatorsBuilder {
    setScale(value) {
        this.scale = value;
        return this;
    }
    /**
     * @override
     * @inheritDoc
     */
    createIndicatorShape(isLeft) {
        // If left, rotate around 180deg
        let angle = isLeft ? Math.PI : 0;
        let position = this.getPositioning(isLeft);
        let arrow = new Arrow(this.scale, this.unlitStyle, position);
        arrow.setRotationalCentre(position);
        arrow.setAngle(angle);
        return arrow;
    }
    /**
     * @override
     * @inheritDoc
     */
    useAsBase(builder) {
        super.useAsBase(builder);
        this.setScale(builder.scale);
        return this;
    }
}
class LineIndicatorsBuilder extends AbstractMirroredIndicatorsBuilder {
    setYCoordinates(start, end) {
        this.startY = start;
        this.endY = end;
        return this;
    }
    createIndicatorShape(isLeft) {
        let basePos = this.getPositioning(isLeft);
        return new Line(Vector.add(basePos, new Vector(0, this.startY)), Vector.add(basePos, new Vector(0, this.endY)), this.unlitStyle);
    }
}
/**
 * Represents an arc tick component that changes individual tick colour based on whether it meets a,
 * threshold value and whose threshold value can be changed
 */
class CamoArcTicks extends DualColourArcTicks {
    /**
     * @constructor
     * @see ArcTicks for default parameters and how to change them
     * @param {Vector} centre - the centre of the display
     * @param {number} radius - the distance between the display centre and each tick's centre
     * @param {number} numTicks - the number of ticks to have
     * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
     * @param {ColourPriority} colours - the colours for the tick
     */
    constructor(centre, radius, numTicks, arcRange, colours) {
        super(centre, radius, numTicks, arcRange, colours);
    }
    /**
     * @override
     * @inheritDoc
     */
    update(data) {
        this.threshold = data;
    }
}
/**
 * Represents a pointer object, wherein an accent is displayed over the pointer
 */
class AccentPointer extends AbstractGaugePointer {
    /**
     * @constructor
     * @param {Vector} centre - the centre of the pointer
     * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
     * @param {SimplePointer} bgPointer - the background pointer
     * @param {SimplePointer} accentPointer - the accent pointer
     * @param {Drawable} pointerDial - the centre dial part of the pointers
     */
    constructor(centre, arcAngles, bgPointer, accentPointer, pointerDial) {
        super(centre, bgPointer.getValueRange(), arcAngles);
        this.bgPointer = bgPointer;
        this.accentPointer = accentPointer;
        this.pointerDial = pointerDial;
        this.setRotationalCentre(this.centre);
    }
    /**
     * @override
     * @inheritDoc
     */
    setActiveAngle(angle) {
        this.accentPointer.setActiveAngle(angle);
        this.bgPointer.setActiveAngle(angle);
    }
    /**
     * @override
     * @inheritDoc
     */
    setRotationalCentre(centre) {
        this.accentPointer.setRotationalCentre(centre);
        this.bgPointer.setRotationalCentre(centre);
    }
    /**
     * @override
     * Draws the pointer pieces to a canvas.
     * Note that pointerDial overrides the pointer dials specified in the pointer objects
     * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
     */
    draw(ctx) {
        this.bgPointer.drawPointers(ctx);
        this.accentPointer.drawPointers(ctx);
        this.pointerDial.draw(ctx);
    }
}
/**
 * Represents a gauge pointer as a collection of the centre dial, minor pointer and major pointer
 */
class SimplePointer extends AbstractGaugePointer {
    /**
     * @constructor
     * @param {Vector} centre - the centre of the pointer
     * @param {NumberRange} valueRange - the value range possible to displayer
     * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
     * @param {Rotatable} majorPointer - the major part of the pointer
     * @param {Rotatable} minorPointer - the minor part of the pointer (points to the inverse angle)
     * @param {Drawable} pointerDial - the pointer dial at the centre
     */
    constructor(centre, valueRange, arcAngles, majorPointer, minorPointer, pointerDial) {
        super(centre, valueRange, arcAngles);
        this.majorPointer = majorPointer;
        this.minorPointer = minorPointer;
        this.pointerDial = pointerDial;
        this.setCentre(this.centre);
        this.setRotationalCentre(this.centre);
        this.setActiveAngle(0);
    }
    /**
     * Draws the pointers
     * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
     * @public
     */
    drawPointers(ctx) {
        this.majorPointer.draw(ctx);
        this.minorPointer.draw(ctx);
    }
    /**
     * @override
     * @inheritDoc
     */
    setActiveAngle(angle) {
        // An angle of 0 means the pointer is at the bottom -> -Math.PI/2
        // angle -= Math.PI/2;
        this.majorPointer.setAngle(angle);
        this.minorPointer.setAngle(this.getInvAngle(angle));
    }
    /**
     * @override
     * @inheritDoc
     */
    setRotationalCentre(centre) {
        this.majorPointer.setRotationalCentre(centre);
        this.minorPointer.setRotationalCentre(centre);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.drawPointers(ctx);
        this.pointerDial.draw(ctx);
    }
    /**
     * Sets the centres of the major and minor pointers
     * @param {Vector} centre - the centre to set
     */
    setCentre(centre) {
        this.majorPointer.setCentre(centre);
        this.minorPointer.setCentre(centre);
    }
}
/**
 * Represents a pointer with only one moving piece and a middle dial
 */
class UniPointer extends AbstractGaugePointer {
    /**
     * @constructor
     * @param {Vector} centre - the centre of the pointer
     * @param {NumberRange} valueRange - the value range possible to displayer
     * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
     * @param {Rotatable} piece - the piece that rotates
     * @param {Drawable} dial - the dial piece
     */
    constructor(centre, valueRange, arcAngles, piece, dial) {
        super(centre, valueRange, arcAngles);
        this.piece = piece;
        this.dial = dial;
        this.setRotationalCentre(this.centre);
    }
    /**
     * @override
     * @inheritDoc
     */
    setActiveAngle(angle) {
        this.piece.setAngle(angle);
    }
    /**
     * @override
     * @inheritDoc
     */
    setRotationalCentre(centre) {
        this.piece.setRotationalCentre(centre);
    }
    /**
     * @override
     * @inheritDoc
     */
    draw(ctx) {
        this.piece.draw(ctx);
        this.dial.draw(ctx);
    }
}
/**
 * Represents a drawable arc
 */
class Arc extends AbstractShape {
    /**
     * Constructor
     * Cap style defaults to "round"
     * @param {number} radius - the radius of the arc
     * @param {NumberRange} angles - the starting and end angles of the arc
     * @param {BaseStyle} styling - the styling to apply to the arc
     * @param {Vector} [centre] - the centre of the arc. Defaults to (0,0)
     * @param {Vector} [rotationalCentre] - the rotational centre of the arc. Defaults to (0,0)
     */
    constructor(radius, angles, styling, centre, rotationalCentre) {
        super(styling, centre, rotationalCentre);
        this.radius = radius;
        this.angles = angles;
        this.capStyle = "butt";
    }
    /**
     * @param {number} startAngle - the starting angle of the arc to set
     */
    setStartAngle(startAngle) {
        this.angles.setLower(startAngle);
    }
    /**
     * @param {number} endAngle - the ending angle of the arc to set
     */
    setEndAngle(endAngle) {
        this.angles.setUpper(endAngle);
    }
    getStartAngle() {
        return this.angles.getLower();
    }
    getEndAngle() {
        return this.angles.getUpper();
    }
    getAngles() {
        return this.angles;
    }
    /**
     * Sets the cap style to the ends of the arc bar
     * @param {"round" | "butt"} style - the cap style to apply
     */
    setCapStyle(style) {
        this.capStyle = style;
    }
    /**
     * @Override
     * @inheritDoc
     */
    drawContinue(ctx) {
        ctx.lineCap = this.capStyle;
        ctx.arc(this.centre.x(), this.centre.y(), this.radius, this.angles.getLower(), this.angles.getUpper());
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let arc = new Arc(this.radius, this.angles.clone(), styling, this.centre.clone(), this.rotCentre.clone());
        arc.angle = this.angle;
        return arc;
    }
}
/**
 * Represents a drawable arrow to a canvas. By default, (rotation of 0) the arrow points right and
 * the base dimensions are 10x10 px
 */
class Arrow extends AbstractShape {
    /**
     * @constructor
     * @param {number} scale - the scale factor of the arrow
     * @param {BaseStyle} styling - the styling to apply to the arrow
     * @param {Vector} [centre] - the centre point of the arrow (defaults to (0,0))
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Optional, and if {@link centre} is
     * supplied, this is used. Else, defaults to (0,0)
     */
    constructor(scale, styling, centre, rotationalCentre) {
        super(styling, centre, rotationalCentre || (centre === null || centre === void 0 ? void 0 : centre.clone()));
        this.scale = scale;
    }
    /**
     * @Override
     * @inheritDoc
     */
    drawContinue(ctx) {
        // Begins bottom right of rectangular base, heading counter-clockwise
        // Bottom half
        ctx.translate(this.centre.x(), this.centre.y());
        ctx.moveTo(Arrow.X_COORDS.BASE * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
        ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
        ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, Arrow.Y_COORDS.ARR_START * this.scale);
        ctx.lineTo(Arrow.X_COORDS.ARR_END * this.scale, 0);
        // Top half
        ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, -Arrow.Y_COORDS.ARR_START * this.scale);
        ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, -Arrow.Y_COORDS.BASE_BOT * this.scale);
        ctx.lineTo(Arrow.X_COORDS.BASE * this.scale, -Arrow.Y_COORDS.BASE_BOT * this.scale);
        ctx.lineTo(Arrow.X_COORDS.BASE * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let arrow = new Arrow(this.scale, styling, this.centre.clone(), this.rotCentre.clone());
        arrow.angle = this.angle;
        return arrow;
    }
}
Arrow.X_COORDS = {
    BASE: 0,
    ARR_START: 5,
    ARR_END: 10
};
Arrow.Y_COORDS = {
    BASE_BOT: 2.5,
    ARR_START: 5
};
/**
 * Represents a drawable line
 */
class Line extends AbstractShape {
    /**
     * Constructor
     * @param {Vector} point1 - the start point
     * @param {Vector} point2 - the end point
     * @param {BaseStyle} styling - the styling to apply to the line
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(point1, point2, styling, rotationalCentre) {
        super(styling, rotationalCentre);
        this.point1 = point1;
        this.point2 = point2;
        this.point1 = point1;
        this.point2 = point2;
    }
    /**
     * @Override
     * @inheritDoc
     */
    setCentre(centre) {
        let oldCentre = this.centre;
        super.setCentre(centre);
        let translation = Vector.sub(this.centre, oldCentre);
        this.translate(translation);
    }
    /**
     * Translates both end points by the given vector
     * @param {Vector} translation the translation vector
     */
    translate(translation) {
        this.point1.add(translation);
        this.point2.add(translation);
    }
    /**
     * @Override
     * @inheritDoc
     */
    drawContinue(ctx) {
        ctx.moveTo(this.point1.x(), this.point1.y());
        ctx.lineTo(this.point2.x(), this.point2.y());
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let line = new Line(this.point1.clone(), this.point2.clone(), styling, this.rotCentre.clone());
        line.angle = this.angle;
        return line;
    }
}
/**
 * Represent a rectangle
 */
class Rectangle extends AbstractShape {
    /**
     * Constructor
     * @param {number} width - the width of the rectangle
     * @param {number} height - the height of the rectangle
     * @param {BaseStyle} styling - the styling to apply
     * @param {Vector} [centre] - the position of the top left point. Defaults to (0,0)
     * @param {boolean} [isFillCentred] - whether to centre the X position of the rectangle with the
     * fill style. Defaults to false
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(width, height, styling, centre, isFillCentred = false, rotationalCentre) {
        super(styling, centre, rotationalCentre);
        this.width = width;
        this.height = height;
        this.isFillCentred = isFillCentred;
    }
    /**
     * @Override
     * @inheritDoc
     */
    setCentre(centre) {
        super.setCentre(centre);
        if (this.isFillCentred)
            this.centre.addX(-this.width / 4);
    }
    /**
     * @Override
     * @inheritDoc
     */
    drawContinue(ctx) {
        ctx.rect(this.centre.x(), this.centre.y(), this.width, this.height);
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let rectangle = new Rectangle(this.width, this.height, styling, this.centre, this.isFillCentred, this.rotCentre.clone());
        rectangle.angle = this.angle;
        return rectangle;
    }
}
/**
 * Represents a rectangle with a rounded bottom-right corner
 */
class RoundCornerRectangleBR extends AbstractShape {
    /**
     * Constructor
     * @param {number} arcRadius - the rounded part's arc radius
     * @param {NumberRange} arcAngles - the rounded part's arc angle range
     * @param {Vector} arcCentre - the rounded part's arc centre point
     * @param {number} leftX - the leftmost point on the x dimension
     * @param {BaseStyle} styling - the style to apply to this shape
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(arcRadius, arcAngles, arcCentre, leftX, styling, rotationalCentre) {
        super(styling, rotationalCentre);
        this.arcRadius = arcRadius;
        this.arcCentre = arcCentre;
        this.leftX = leftX;
        this.ARC = new Arc(arcRadius, arcAngles, styling, arcCentre, this.rotCentre.clone());
        this.leftX = leftX;
    }
    /**
     * @override
     * @inheritDoc
     */
    drawContinue(ctx) {
        this.ARC.drawContinue(ctx);
        ctx.lineTo(this.leftX, getRelCircularPoint(this.arcCentre, this.arcRadius, this.ARC.getEndAngle()).y());
        ctx.lineTo(this.leftX, getRelCircularPoint(this.arcCentre, this.arcRadius, this.ARC.getStartAngle()).y());
    }
    /**
     * @override
     * @inheritDoc
     */
    changeStyling(styling) {
        let roundCornerRectangleBR = new RoundCornerRectangleBR(this.arcRadius, this.ARC.getAngles(), this.arcCentre, this.leftX, styling, this.rotCentre.clone());
        roundCornerRectangleBR.angle = this.angle;
        return roundCornerRectangleBR;
    }
}
/**
 * Represents a drawable circle
 */
class Circle extends Arc {
    /**
     * Constructor
     * @param {number} radius - the radius of the circle
     * @param {BaseStyle} styling - the styling to apply to the circle
     * @param {Vector} [centre] - the centre of the circle. Defaults to (0,0)
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(radius, styling, centre, rotationalCentre) {
        super(radius, new NumberRange(0, 2 * Math.PI), styling, centre, rotationalCentre);
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let circle = new Circle(this.radius, styling, this.centre.clone(), this.rotCentre.clone());
        circle.angle = this.angle;
        return circle;
    }
}
/**
 * Represents a drawable triangle
 */
class Triangle extends Line {
    /**
     * Constructor
     * @param {Vector} point1 - the first vertex
     * @param {Vector} point2 - the second vertex
     * @param {Vector} point3 - the third vertex
     * @param {BaseStyle} styling - the styling to apply to the triangle
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(point1, point2, point3, styling, rotationalCentre) {
        super(point1, point2, styling, rotationalCentre);
        this.point3 = point3;
        // Calculate and set centre
        this.setCentre(this.calculateCentrePoint());
    }
    /**
     * @Override
     * @inheritDoc
     */
    translate(translation) {
        super.translate(translation);
        this.point3.add(translation);
    }
    /**
     * Constructs and returns an isosceles triangle.
     * The rotational centre will be set to (0,0)
     * @param {number} baseWidth - the width of the base
     * @param {number} height - the height
     * @param {BaseStyle} styling - the styling to apply to the triangle
     * @param {Vector} centre - the point to put the triangle's centre to
     * @param {number} [angle] - the angle to rotate the triangle by. By default, the triangle will
     * face right at 0 radians
     * @returns {Triangle} the triangle created
     */
    static newIsosceles(baseWidth, height, styling, centre, angle = 0) {
        let p1 = new Vector(baseWidth / 2, 0).rotateAboutOrigin(angle);
        let p2 = new Vector(-baseWidth / 2, 0).rotateAboutOrigin(angle);
        let p3 = new Vector(0, height).rotateAboutOrigin(angle);
        let triangle = new Triangle(p1, p2, p3, styling, new Vector());
        triangle.setCentre(centre);
        return triangle;
    }
    /**
     * Calculates the centre point of the triangle
     * @returns {Vector}
     */
    calculateCentrePoint() {
        let sum = new Vector();
        sum.add(this.point1);
        sum.add(this.point2);
        sum.add(this.point3);
        return Vector.div(sum, 3);
    }
    /**
     * @Override
     * @inheritDoc
     */
    drawContinue(ctx) {
        super.drawContinue(ctx);
        ctx.lineTo(this.point3.x(), this.point3.y());
        ctx.lineTo(this.point1.x(), this.point1.y());
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let triangle = new Triangle(this.point1.clone(), this.point2.clone(), this.point3.clone(), styling, this.rotCentre.clone());
        triangle.angle = this.angle;
        return triangle;
    }
}
class Wedge extends Arc {
    /**
     * Constructor
     * @param {number} radius - the radius of the wedge
     * @param {NumberRange} angles - the starting and end angles of the wedge
     * @param {BaseStyle} styling - the styling to apply to the wedge
     * @param {Vector} [centre] - the centre of the wedge. Defaults to (0,0)
     * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
     */
    constructor(radius, angles, styling, centre, rotationalCentre) {
        super(radius, angles, styling, centre, rotationalCentre);
    }
    /**
     * @Override
     * @inheritDoc
     */
    draw(ctx) {
        ctx.beginPath();
        ctx.moveTo(this.centre.x(), this.centre.y());
        super.drawContinue(ctx);
        this.styling.apply(ctx);
        Canvas.resetTransformationState(ctx);
    }
    /**
     * @Override
     * @inheritDoc
     */
    changeStyling(styling) {
        let wedge = new Wedge(this.radius, this.angles.clone(), styling, this.centre.clone(), this.rotCentre.clone());
        wedge.angle = this.angle;
        return wedge;
    }
}
