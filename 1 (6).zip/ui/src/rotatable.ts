import { Moveable } from "./moveable";
import { Vector } from "./maths/vector";

/**
 * Represents an object that can be rotated around a centre point
 */
export abstract class Rotatable extends Moveable {
  /**
   * @constructor
   * @param {Vector} [centre] - the centre. Defaults to (0,0)
   * @param {Vector} [rotCentre] - the rotational centre. Defaults to (0,0)
   * @param {number} [angle] - the angle around the centre. Defaults to 0
   */
  protected constructor(centre = new Vector(), protected rotCentre = new Vector(), protected angle = 0) {
    super(centre);
  }

  /**
   * Sets the angle of rotation
   * @param {number} angle - the angle to set
   */
  public setAngle(angle: number): void {
    this.angle = angle;
  }

  /**
   * Sets the centre of rotation for this shape
   * @param {Vector} centre - the new centre of rotation
   */
  public setRotationalCentre(centre: Vector): void {
    this.rotCentre = centre;
  }
}
