import { Dimensions } from "./types/dimensions";

interface ScaledCanvasRenderingContext2D extends CanvasRenderingContext2D {
  scaleFactor: number;
}

/**
 * Represents a canvas object that can be drawn on
 */
export class Canvas {
  private element: HTMLCanvasElement;
  // The scale of the drawing on the canvas
  private scaleFactor = 1;

  /**
   * @constructor
   * @param {Document} document - the document object this canvas is on
   * @param {string} ID - the canvas's identifier string
   * @param {number} baseSize - the width and height of the canvas __without__ any scaling being applied. In the context
   * of this being a canvas for an app, this should be set to the default/starting width of the app
   */
  constructor(document: Document, private readonly ID: string, private readonly baseSize: number) {
    this.element = document.getElementById(this.ID) as HTMLCanvasElement;
    // Change the canvas size to match the dimensions of the app container
    this.setElementDimensions(this.getContainerDimensions());
  }

  /**
   * @returns {Dimensions} the current dimensions of the app container that this canvas is container within
   * @private
   */
  private getContainerDimensions(): Dimensions {
    // The app container is 3 levels above
    return this.element.parentElement.parentElement.parentElement.getBoundingClientRect();
    // return { width: 1000, height: 1000 };
  }

  /**
   * Sets the dimensions of the canvas element
   * @param {Dimensions} newDimensions - the new dimensions to set
   * @private
   */
  private setElementDimensions(newDimensions: Dimensions): void {
    this.element.width = newDimensions.width;
    this.element.height = newDimensions.height;
  }

  /**
   * @return {Dimensions} the initial dimensions of the canvas
   */
  public getCurrentDimensions(): Dimensions {
    return { width: this.element.width, height: this.element.height };
  }

  /**
   * Resizes the canvas's dimensions
   * @param {number} newSize - the size to set
   */
  public resize(newSize: number): void {
    this.scaleFactor = newSize / this.baseSize;
    this.setElementDimensions({ width: newSize, height: newSize });
  }

  /**
   * Shows or hides the canvas
   * @param {boolean} show - whether to show or hide the canvas
   */
  public show(show: boolean): void {
    this.element.style.opacity = show ? "1" : "0";
  }

  /**
   * @returns {CanvasRenderingContext2D} the 2D context of the canvas
   */
  public get2DContext(): CanvasRenderingContext2D {
    let ctx = this.element.getContext("2d") as ScaledCanvasRenderingContext2D;
    /* Add a scale factor parameter to the context
       Nothing outside of this class needs to know about this, since this is a parameter ONLY for
       this class to use when resetting the transform of the context */
    ctx.scaleFactor = this.scaleFactor;
    return ctx;
  }

  /**
   * Clears the canvas of all content drawn on it
   */
  public clear(): void {
    let ctx = this.get2DContext();
    // Width/height will change, and current max is 750
    ctx.clearRect(0, 0, 2160, 2160);
  }

  /**
   * Sets a listener to a canvas for the left and right click action by a mouse
   * @param {(event: Event) => void} leftFunc - the function to perform on a left click
   * @param {(event: Event) => void} rightFunc - the function to perform on a right click
   */
  public setupCanvasClick(leftFunc: (event: Event) => void, rightFunc: (event: Event) => void): void {
    // Remove any previous event listeners
    this.removeEventListeners();

    this.element.addEventListener("mousedown", function (event) {
      switch (event.button) {
        case 0:
          leftFunc(event);
          break;
        case 2:
          rightFunc(event);
          break;
      }
    });
  }

  /**
   * Removes all event listeners from this canvas element
   * @private
   */
  private removeEventListeners(): void {
    let newElement = this.element.cloneNode(false);
    this.element.replaceWith(newElement);
    this.element = document.getElementById(this.ID) as HTMLCanvasElement;
  }

  /**
   * Resets the transformation of a canvas's 2D context
   * @param {CanvasRenderingContext2D} ctx - the context to reset the transformation of
   */
  public static resetTransformationState(ctx: CanvasRenderingContext2D): void {
    let sctx = ctx as ScaledCanvasRenderingContext2D;
    sctx.setTransform(1, 0, 0, 1, 0, 0);
    /* Keep the scaling as this is global for the whole canvas.
       Other classes need not know about this, as this should be encapsulated.
       Not the best solution, but it allows complete global control over scaling via one line of
       code */
    sctx.scale(sctx.scaleFactor, sctx.scaleFactor);
  }

  /**
   * Resets the filter to prevent lingering filters
   * @param {CanvasRenderingContext2D} ctx - the canvas context to reset the filter of
   */
  public static resetFilter(ctx: CanvasRenderingContext2D): void {
    ctx.filter = "none";
    ctx.shadowBlur = 0;
    ctx.shadowColor = "none";
  }

  /**
   * Draws a shape to a canvas, preserving transparency of that shape. Any previously filled in
   * parts of the canvas will be drawn over
   * @param {(CanvasRenderingContext2D) => void} drawFunc - the function that will draw to the
   * canvas. Should take in the <b>ctx</b> object for drawing
   * @param {CanvasRenderingContext2D} ctx - the canvas context to draw to
   */
  public static drawTransparency(drawFunc: (x: CanvasRenderingContext2D) => void, ctx: CanvasRenderingContext2D): void {
    // Clear the area for alpha to work
    ctx.globalCompositeOperation = "destination-out";
    drawFunc(ctx);

    // Then draw the actual
    ctx.globalCompositeOperation = "source-over";
    drawFunc(ctx);
  }
}
