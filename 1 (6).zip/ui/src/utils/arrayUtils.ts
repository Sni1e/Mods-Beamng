import { NumberRange } from "../maths/numberRange";
import { truncate } from "./mathsUtils";

/**
 * Returns the next value in an array, given a current value, looping around to the start if
 * the value is at the end of the array
 * @param {T[]} array - the array of elements
 * @param {T} selected - the currently selected value
 * @template T
 */
export function getNextElement<T>(array: T[], selected: T): T {
  // Find next index, looping back around to 0 if necessary
  let index = array.indexOf(selected);
  index = (index + 1) % array.length;

  return array[index];
}

/**
 * Returns a list of numbers, going from {@link startValue} to {@link endValue}, generating in
 * total {@link totalNumbers} numbers
 * @param {number} startValue - the first value
 * @param {number} endValue - the last value
 * @param {number} totalNumbers - the number of numbers to return
 * @param {number} [decimalPlaces] - the number of decimal places each number can have. Defaults
 * to 0
 * @returns {number[]} the numbers generated
 */
export function generateEquidistantValues(
  startValue: number,
  endValue: number,
  totalNumbers: number,
  decimalPlaces = 0
): number[] {
  let array = [];
  let range = new NumberRange(startValue, endValue);

  for (let i = 0; i < totalNumbers; i++) {
    let perc = i / (totalNumbers - 1);
    let number = truncate(range.getLinearRatio(perc), decimalPlaces);
    array.push(number);
  }

  return array;
}

/**
 * Creates an arithmetic series.
 * More formally, it generates an array of form [a, a+d, a+2d, ..., a+(n-1)d] where
 * <b>a=start-term</b>, <b>d=gap-between-terms</b> and <b>n=number-of-terms</b>
 * Examples:
 *  (  0,  1, 5) -> [0,1,2,3,4]
 *  (  2,  5, 3) -> [2,7,12]
 *  (-10, 15, 4) -> [-10,5,20,45]
 * @param {number} start - the starting term
 * @param {number} gap - the gap between two terms
 * @param {number} numTerms - the number of terms to generate
 * @return {number[]} the series generated
 */
export function arithmeticSeries(start: number, gap: number, numTerms: number): number[] {
  return Array.from({ length: numTerms }, (_, i) => start + i * gap);
}

/**
 * Partitions an array by keeping all elements whose index exist in the arithmetic sequence
 * [0,d,2d,...] and returns it. The original array is not affected
 * Examples:
 *  ([0,1,2,3,4,5,6,7,8,9], 2) -> [0,2,4,6,8]
 *  ([0,1,2,3,4,5,6,7,8,9], 3) -> [0,3,6,9]
 *  ([0,1,2,3,4,5,6,7,8,9], 4) -> [0,4,8]
 * @param {number[]} arr - the array to partition
 * @param {number} gapInTerms - the index 'gap' between terms
 * @returns {number[]} the partitioned array
 */
export function partition(arr: number[], gapInTerms: number): number[] {
  return arr.filter((_, i) => i % gapInTerms === 0);
}

/**
 * Converts a string to an array.
 * By default, an array of each character is returned, however the {@link groupingSize} parameter allows for grouping by
 * a different size.
 * Examples:
 *  ("abcde"    ) => ["a", "b", "c", "d", "e"]
 *  ("abcde",  2) => ["ab", "cd", "e"]
 *  ("abcde",  4) => ["abcd", "e"]
 *  ("abcde", 10) => ["abcde"]
 * @param {string} string
 * @param {number} groupingSize
 * @returns {string[]}
 */
export function stringToArray(string: string, groupingSize = 1): string[] {
  return string.match(new RegExp('.{1,' + groupingSize + '}', 'g'));
}












