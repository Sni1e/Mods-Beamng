import { Vector } from "../maths/vector";
import { NumberRange } from "../maths/numberRange";
import { stringToArray } from "./arrayUtils";

/**
 * Returns the coordinates of a point on a circle, whose centre is the origin (0,0)
 * @param {number} radius - the radius of the circle
 * @param {number} angle - the angle along the circle the point is
 * @returns {Vector} the point
 */
export function getCircularPoint(radius: number, angle: number): Vector {
  return new Vector(radius * Math.cos(angle), radius * Math.sin(angle));
}

/**
 * Returns the coordinates of a point on a circle, whose centre is specified
 * @param {Vector} relCentre - the centre of the circle to rotate around
 * @param {number} radius - the radius of the circle
 * @param {number} angle - the angle along the circle the point is
 * @returns {Vector} the point
 */
export function getRelCircularPoint(relCentre: Vector, radius: number, angle: number): Vector {
  return Vector.add(relCentre, getCircularPoint(radius, angle));
}

/**
 * Adds two numbers together, wrapping back to the start if this the result reaches/exceeds the wrapping value.
 * Example: (3, 4, 5) => 2
 * @param {number} number1 - the first number
 * @param {number} number2 - the first number
 * @param {number} wrapPoint - the wrapping point
 */
export function wrapAdd(number1: number, number2: number, wrapPoint: number): number {
  return (number1 + number2) % wrapPoint;
}

/**
 * Returns a new NumberRange which represents the remaining circle, given the current 'portion' of that circle, in
 * NumberRange form.
 * @param {NumberRange} angles - the 'portion' of that circle
 * @returns {NumberRange} the remaining 'portion' of that circle
 */
export function getRemainingCircle(angles: NumberRange): NumberRange {
  let upper = angles.getUpper();
  return new NumberRange(upper, upper + angles.getLower());
}

/**
 * Rounds a number to a specified amount of significant figures
 * @param {number} number - the number to round
 * @param {number} sigFigs - the number of significant figures to round to
 * @returns {number} the rounded number to the specified amount of significant figures
 */
export function sigFigs(number: number, sigFigs: number): number {
  let prec = Number.parseFloat(number.toString()).toPrecision(sigFigs);
  return Number.parseFloat(prec);
}

/**
 * Adds in 0's preceding the number until the number of digits is equal to what is specified.
 * Note that if the number of digits requested is <= the number of digits already in the number
 * passed, the resultant string is simply that number passed in string form.
 * Examples:
 *    ( 24, 3) -> "024"
 *    (260, 5) -> "00260"
 *    (454, 3) -> "454"
 *    (999, 2) -> "999"
 * @param {number} number - the number to modify
 * @param {number} numDigits - the number of digits the resultant number must contain
 * @return {string} the resultant number, in string form
 */
export function precede(number: number, numDigits: number): string {
  let numStr = number.toString();
  let length = numStr.length;

  if (length >= numDigits) return numStr;

  return "0".repeat(numDigits - length) + numStr;
}

/**
 * Truncates a number to an amount of decimal places
 * @param {number} number - the number to truncate
 * @param {number} decimalPlaces - the number of decimal place to truncate to
 * @returns {number} the truncated number
 */
export function truncate(number: number, decimalPlaces: number): number {
  let truncate = Number.parseFloat(number.toString()).toFixed(decimalPlaces);
  return Number.parseFloat(truncate);
}

/**
 * Returns the last number of digits of a number. If the number of digits passed is more than the number of digits in
 * the number, then the whole number is returned as is.
 * Examples:
 *   (123, 2) => 23
 *   (123, 5) => 123
 *   (123, 1) => 3
 * @param {number} number - the number to get the last digits of
 * @param {number} numDigits - the number of last digits to return
 * @returns {number} the last {@link numDigits} of {@link number}
 */
export function lastDigitsOf(number: number, numDigits: number): number {
  let numStr = number.toString();
  let length = numStr.length;

  if (length >= numDigits) return Number.parseFloat(numStr.substring(length - numDigits));

  return number;
}

/**
 * Converts a single hex string character to its equivalent denary value.
 * Note that if a letter is passed, any capitalisation is ignored.
 * @param {string} hex - the hex charter to convert. Must be (0, 9) or (A-F)
 * @returns {number}
 * @throws {Error} if the digit passed is not a hexadecimal digit or more than one character is passed in the string
 */
function hexDigitValue(hex: string): number {
  hex = hex.toUpperCase();

  if (hex.length !== 1) throw new Error("Hex digit must be a single character");

  if (Number.isInteger(Number(hex))) return Number.parseFloat(hex);

  switch (hex) {
    case "A": return 10;
    case "B": return 11;
    case "C": return 12;
    case "D": return 13;
    case "E": return 14;
    case "F": return 15;
  }

  throw new Error("Digit is not a hex character");
}

/**
 * Converts a hexadecimal string into its denary value
 * @param {string} hex - the hex string to convert
 * @returns {number} the denary value of {@link hex}
 */
export function hexadecimalToDenary(hex: string): number {
  let str = hex
    .toString()
    .replace("#", "");

  return stringToArray(str)
    .map((digit, index, arr) => hexDigitValue(digit) * Math.pow(16, arr.length - 1 - index))
    .reduce((prev, curr) => prev + curr);
}






