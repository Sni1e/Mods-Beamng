import { Vector } from "../maths/vector";
import { NumberRange } from "../maths/numberRange";
import { ArcNumbering } from "../gauges/dataDisplayers/arcNumbering";
import { Font } from "../text/font";

/**
 * Creates and returns a numbering system with numbers arranged in an arc
 * @param {number} radius - the radius of the arc
 * @param {number} fontSize - the font size for the numbers
 * @param {string} fontName - the name of the font to use
 * @param {[number]} numbers - the list of numbers to display
 * @param {Vector} centre - the centre point
 * @param {NumberRange} arcRange - the arc range the numbers will fit to
 * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
 * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
 * @return {ArcNumbering} the numbering system created
 */
export function createBasicNumbering(
  radius: number,
  fontSize: number,
  fontName: string,
  numbers: number[],
  centre: Vector,
  arcRange: NumberRange,
  ctx: CanvasRenderingContext2D,
  drawStartAndEndNumbers = true
): ArcNumbering {
  let font = new Font(fontName, fontSize, true);
  return new ArcNumbering(centre, radius, numbers, arcRange, font, ctx, drawStartAndEndNumbers);
}
