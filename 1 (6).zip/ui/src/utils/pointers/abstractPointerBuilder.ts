import { Builder } from "../../builder";
import { AbstractGaugePointer } from "../../gauges/dataDisplayers/pointers/abstractGaugePointer";
import { Vector } from "../../maths/vector";
import { NumberRange } from "../../maths/numberRange";

/**
 * @template T
 * T is the type of pointer than can be created by this builder
 */
export abstract class AbstractPointerBuilder<T extends AbstractGaugePointer> implements Builder<T> {
  protected startAngle = -Math.PI / 2;
  protected centre: Vector;
  protected width: number;
  protected length: number;
  protected valueRange: NumberRange;
  protected pointerRange: NumberRange;
  // The scale of the minor part of the pointer
  protected minorScale = 0.6;

  public setStartAngle(value: number): this {
    this.startAngle = value;
    return this;
  }

  public setCentre(centre: Vector): this {
    this.centre = centre.clone();
    return this;
  }

  public setWidth(width: number): this {
    this.width = width;
    return this;
  }

  public setLength(length: number): this {
    this.length = length;
    return this;
  }

  public setValueRange(valueRange: NumberRange): this {
    this.valueRange = valueRange.clone();
    return this;
  }

  public setPointerRange(pointerRange: NumberRange): this {
    this.pointerRange = pointerRange.clone();
    return this;
  }

  public setMinorScale(minorScale: number): this {
    this.minorScale = minorScale;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractPointerBuilder<T>): AbstractPointerBuilder<T> {
    this.setWidth(builder.width);
    this.setCentre(builder.centre);
    this.setLength(builder.length);
    this.setMinorScale(builder.minorScale);
    this.setPointerRange(builder.pointerRange);
    this.setStartAngle(builder.startAngle);
    this.setValueRange(builder.valueRange);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public abstract build(): T;
}
