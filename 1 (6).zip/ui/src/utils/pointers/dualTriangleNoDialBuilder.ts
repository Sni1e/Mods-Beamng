import { Style } from "../../styles/style";
import { SimplePointer } from "../../gauges/dataDisplayers/pointers/simplePointer";
import { Triangle } from "../../shapes/triangle";
import { AbstractPointerBuilder } from "./abstractPointerBuilder";

/**
 * Creates a new simple pointer with a main pointer and a shorter pointer that faces the opposing direction, however, it
 * does not contain a middle dial component. Both pointers are triangles.
 */
export class DualTriangleNoDialBuilder extends AbstractPointerBuilder<SimplePointer> {
  private tipStyle: Style;

  public setTipStyle(value: Style): this {
    this.tipStyle = value;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): SimplePointer {
    let major = Triangle.newIsosceles(this.width, this.length, this.tipStyle, this.centre, this.startAngle);
    let minor = Triangle.newIsosceles(
      this.width,
      this.length * this.minorScale,
      this.tipStyle,
      this.centre,
      this.startAngle
    );
    return new SimplePointer(this.centre, this.valueRange, this.pointerRange, major, minor, null);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: DualTriangleNoDialBuilder): DualTriangleNoDialBuilder {
    return (
      super.useAsBase(builder) as DualTriangleNoDialBuilder
    ).setTipStyle(builder.tipStyle);
  }
}
