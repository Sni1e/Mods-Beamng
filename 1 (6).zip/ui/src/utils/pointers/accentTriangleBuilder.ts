import { AbstractPointerBuilder } from "./abstractPointerBuilder";
import { AccentPointer } from "../../gauges/dataDisplayers/pointers/accentPointer";
import { Style } from "../../styles/style";
import { Circle } from "../../shapes/circle";
import { DualTriangleNoDialBuilder } from "./dualTriangleNoDialBuilder";

type Colours = { dial: string; main: string; accent: string };

export class AccentTriangleBuilder extends AbstractPointerBuilder<AccentPointer> {
  private colours: Colours;
  private accentScale: number;
  /** Whether accent keeps the width of the main pointer, or has it's value reduced by {@link accentScale} */
  private keepWidth = true;

  public setKeepWidth(value: boolean): AccentTriangleBuilder {
    this.keepWidth = value;
    return this;
  }

  public setColours(value: Colours): AccentTriangleBuilder {
    this.colours = value;
    return this;
  }

  public setAccentScale(value: number): AccentTriangleBuilder {
    this.accentScale = value;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): AccentPointer {
    let dialStyle = Style.noStrokeFill(this.colours.dial);
    let primaryStyle = Style.unitStrokeFill(this.colours.main);
    let secondaryStyle = Style.unitStrokeFill(this.colours.accent);

    let accentLength = this.keepWidth ? this.length : this.length * this.accentScale;

    let mainBuilder = new DualTriangleNoDialBuilder()
      .setCentre(this.centre)
      .setWidth(this.width)
      .setLength(this.length)
      .setMinorScale(this.minorScale)
      .setPointerRange(this.pointerRange)
      .setStartAngle(this.startAngle)
      .setValueRange(this.valueRange)
      .setTipStyle(primaryStyle);

    let accentBuilder = new DualTriangleNoDialBuilder()
      .useAsBase(mainBuilder)
      .setWidth(this.width * this.accentScale)
      .setLength(accentLength)
      .setTipStyle(secondaryStyle);

    let dial = new Circle(this.width * 0.8, dialStyle, this.centre);

    return new AccentPointer(this.centre, this.pointerRange, mainBuilder.build(), accentBuilder.build(), dial);
  }
}
