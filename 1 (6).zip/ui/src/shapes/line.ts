import { AbstractShape } from "./abstractShape";
import { Vector } from "../maths/vector";
import { BaseStyle } from "../styles/baseStyle";
import { Style } from "../styles/style";

/**
 * Represents a drawable line
 */
export class Line extends AbstractShape {
  /**
   * Constructor
   * @param {Vector} point1 - the start point
   * @param {Vector} point2 - the end point
   * @param {BaseStyle} styling - the styling to apply to the line
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(
    protected readonly point1: Vector,
    protected readonly point2: Vector,
    styling: BaseStyle,
    rotationalCentre?: Vector
  ) {
    super(styling, rotationalCentre);
    this.point1 = point1;
    this.point2 = point2;
  }

  /**
   * @Override
   * @inheritDoc
   */
  public setCentre(centre: Vector): void {
    let oldCentre = this.centre;
    super.setCentre(centre);
    let translation = Vector.sub(this.centre, oldCentre);

    this.translate(translation);
  }

  /**
   * Translates both end points by the given vector
   * @param {Vector} translation the translation vector
   */
  public translate(translation: Vector): void {
    this.point1.add(translation);
    this.point2.add(translation);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    ctx.moveTo(this.point1.x(), this.point1.y());
    ctx.lineTo(this.point2.x(), this.point2.y());
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Line {
    let line = new Line(this.point1.clone(), this.point2.clone(), styling, this.rotCentre.clone());
    line.angle = this.angle;
    return line;
  }
}
