import { AbstractShape } from "./abstractShape";
import { Vector } from "../maths/vector";
import { BaseStyle } from "../styles/baseStyle";

/**
 * Represents a drawable arrow to a canvas. By default, (rotation of 0) the arrow points right and
 * the base dimensions are 10x10 px
 */
export class Arrow extends AbstractShape {
  private static X_COORDS = {
    BASE: 0,
    ARR_START: 5,
    ARR_END: 10
  };

  private static Y_COORDS = {
    BASE_BOT: 2.5,
    ARR_START: 5
  };

  /**
   * @constructor
   * @param {number} scale - the scale factor of the arrow
   * @param {BaseStyle} styling - the styling to apply to the arrow
   * @param {Vector} [centre] - the centre point of the arrow (defaults to (0,0))
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Optional, and if {@link centre} is
   * supplied, this is used. Else, defaults to (0,0)
   */
  constructor(private readonly scale: number, styling: BaseStyle, centre?: Vector, rotationalCentre?: Vector) {
    super(styling, centre, rotationalCentre || centre?.clone());
  }

  /**
   * @Override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    // Begins bottom right of rectangular base, heading counter-clockwise

    // Bottom half
    ctx.translate(this.centre.x(), this.centre.y());
    ctx.moveTo(Arrow.X_COORDS.BASE * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
    ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
    ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, Arrow.Y_COORDS.ARR_START * this.scale);
    ctx.lineTo(Arrow.X_COORDS.ARR_END * this.scale, 0);
    // Top half
    ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, -Arrow.Y_COORDS.ARR_START * this.scale);
    ctx.lineTo(Arrow.X_COORDS.ARR_START * this.scale, -Arrow.Y_COORDS.BASE_BOT * this.scale);
    ctx.lineTo(Arrow.X_COORDS.BASE * this.scale, -Arrow.Y_COORDS.BASE_BOT * this.scale);
    ctx.lineTo(Arrow.X_COORDS.BASE * this.scale, Arrow.Y_COORDS.BASE_BOT * this.scale);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Arrow {
    let arrow = new Arrow(this.scale, styling, this.centre.clone(), this.rotCentre.clone());
    arrow.angle = this.angle;
    return arrow;
  }
}
