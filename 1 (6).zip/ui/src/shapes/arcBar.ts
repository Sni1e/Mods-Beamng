import { Drawable } from "../drawable";
import { NumberRange } from "../maths/numberRange";
import { Vector } from "../maths/vector";
import { Arc } from "./arc";
import { BaseStyle } from "../styles/baseStyle";

/**
 * Represents a completion bar in an arc shape
 */
export class ArcBar extends Drawable {
  private invert = false;
  private bgArc: Arc;
  private mainArc: Arc;

  /**
   * Constructor
   * By default, the bar is 100% complete
   * @param {number} radius - the radius of the arc
   * @param {NumberRange} angles - the starting and end angles of the arc
   * @param {BaseStyle} styling - the styling to apply to the arc
   * @param {BaseStyle} bgStyling - the styling to apply to the background of the arc
   * @param {Vector} centre - the centre of the arc bar
   */
  constructor(
    private readonly radius: number,
    private readonly angles: NumberRange,
    private readonly styling: BaseStyle,
    private readonly bgStyling: BaseStyle,
    private readonly centre: Vector
  ) {
    super();
    this.bgArc = new Arc(radius, angles, this.bgStyling, centre, centre.clone());
    this.mainArc = this.bgArc.changeStyling(this.styling);
  }

  /**
   * Sets whether to invert the arc bar
   * @param {boolean} invert - whether to invert the arc bar or not
   */
  public invertArcs(invert: boolean): void {
    this.invert = invert;
  }

  /**
   * Sets the cap style to the ends of the arc bar
   * @param {"round" | "butt"} style - the cap style to apply
   */
  public setCapStyle(style: "round" | "butt"): void {
    this.bgArc.setCapStyle(style);
    this.mainArc.setCapStyle(style);
  }

  /**
   * @param {number} perc - the percentage full to set the bar to be (between [0,1])
   */
  public setPercentageAlong(perc: number): void {
    let angles = this.bgArc.getAngles();

    if (this.invert) {
      let angle = angles.getLinearRatio(1 - perc);
      this.mainArc.setStartAngle(angle);
    } else {
      let angle = angles.getLinearRatio(perc);
      this.mainArc.setEndAngle(angle);
    }
  }

  /**
   * @Override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.bgArc.draw(ctx);
    this.mainArc.draw(ctx);
  }
}
