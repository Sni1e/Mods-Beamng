import { AbstractShape } from "./abstractShape";
import { Arc } from "./arc";
import { getRelCircularPoint } from "../utils/mathsUtils";
import { Vector } from "../maths/vector";
import { BaseStyle } from "../styles/baseStyle";
import { NumberRange } from "../maths/numberRange";
import { Style } from "../styles/style";

/**
 * Represents a rectangle with a rounded bottom-right corner
 */
export class RoundCornerRectangleBR extends AbstractShape {
  private readonly ARC: Arc;

  /**
   * Constructor
   * @param {number} arcRadius - the rounded part's arc radius
   * @param {NumberRange} arcAngles - the rounded part's arc angle range
   * @param {Vector} arcCentre - the rounded part's arc centre point
   * @param {number} leftX - the leftmost point on the x dimension
   * @param {BaseStyle} styling - the style to apply to this shape
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(
    private readonly arcRadius: number,
    arcAngles: NumberRange,
    private readonly arcCentre: Vector,
    private readonly leftX: number,
    styling: BaseStyle,
    rotationalCentre?: Vector
  ) {
    super(styling, rotationalCentre);
    this.ARC = new Arc(arcRadius, arcAngles, styling, arcCentre, this.rotCentre.clone());
    this.leftX = leftX;
  }

  /**
   * @override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    this.ARC.drawContinue(ctx);
    ctx.lineTo(this.leftX, getRelCircularPoint(this.arcCentre, this.arcRadius, this.ARC.getEndAngle()).y());
    ctx.lineTo(this.leftX, getRelCircularPoint(this.arcCentre, this.arcRadius, this.ARC.getStartAngle()).y());
  }

  /**
   * @override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): RoundCornerRectangleBR {
    let roundCornerRectangleBR = new RoundCornerRectangleBR(
      this.arcRadius,
      this.ARC.getAngles(),
      this.arcCentre,
      this.leftX,
      styling,
      this.rotCentre.clone()
    );
    roundCornerRectangleBR.angle = this.angle;
    return roundCornerRectangleBR;
  }
}
