import { AbstractShape } from "./abstractShape";
import { NumberRange } from "../maths/numberRange";
import { BaseStyle } from "../styles/baseStyle";
import { Vector } from "../maths/vector";

/**
 * Represents a drawable arc
 */
export class Arc extends AbstractShape {
  private capStyle: "round" | "butt" = "butt";

  /**
   * Constructor
   * Cap style defaults to "round"
   * @param {number} radius - the radius of the arc
   * @param {NumberRange} angles - the starting and end angles of the arc
   * @param {BaseStyle} styling - the styling to apply to the arc
   * @param {Vector} [centre] - the centre of the arc. Defaults to (0,0)
   * @param {Vector} [rotationalCentre] - the rotational centre of the arc. Defaults to (0,0)
   */
  constructor(
    protected readonly radius: number,
    protected readonly angles: NumberRange,
    styling: BaseStyle,
    centre?: Vector,
    rotationalCentre?: Vector
  ) {
    super(styling, centre, rotationalCentre);
  }

  /**
   * @param {number} startAngle - the starting angle of the arc to set
   */
  public setStartAngle(startAngle: number): void {
    this.angles.setLower(startAngle);
  }

  /**
   * @param {number} endAngle - the ending angle of the arc to set
   */
  public setEndAngle(endAngle: number): void {
    this.angles.setUpper(endAngle);
  }

  public getStartAngle(): number {
    return this.angles.getLower();
  }

  public getEndAngle(): number {
    return this.angles.getUpper();
  }

  public getAngles(): NumberRange {
    return this.angles;
  }

  /**
   * Sets the cap style to the ends of the arc bar
   * @param {"round" | "butt"} style - the cap style to apply
   */
  public setCapStyle(style: "round" | "butt"): void {
    this.capStyle = style;
  }

  /**
   * @Override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    ctx.lineCap = this.capStyle;
    ctx.arc(this.centre.x(), this.centre.y(), this.radius, this.angles.getLower(), this.angles.getUpper());
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Arc {
    let arc = new Arc(this.radius, this.angles.clone(), styling, this.centre.clone(), this.rotCentre.clone());
    arc.angle = this.angle;
    return arc;
  }
}
