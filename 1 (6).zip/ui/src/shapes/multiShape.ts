import { Rotatable } from "../rotatable";
import { AbstractShape } from "./abstractShape";
import { Vector } from "../maths/vector";

/**
 * Represents a shape comprised of multiple other shapes
 */
export class MultiShape extends Rotatable {
  /**
   * @constructor
   * @param {AbstractShape[]} shapes - the list of shapes
   * @param {Vector} centre - the centre point (should be the average position of all shapes).
   * Defaults to (0,0)
   * @param {Vector} [rotCentre] - the centre of rotation. Defaults to (0,0)
   */
  constructor(private readonly shapes: AbstractShape[], centre = new Vector(), rotCentre = new Vector()) {
    super(centre, rotCentre);
  }

  /**
   * Adds a shape to the list of shapes
   * @param {AbstractShape} shape - the shape to add
   */
  public addShape(shape: AbstractShape): void {
    this.shapes.push(shape);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.shapes.forEach(shape => shape.draw(ctx));
  }
}
