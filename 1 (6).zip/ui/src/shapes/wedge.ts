import { NumberRange } from "../maths/numberRange";
import { BaseStyle } from "../styles/baseStyle";
import { Vector } from "../maths/vector";
import { Arc } from "./arc";
import { Canvas } from "../canvas";
import { Style } from "../styles/style";

export class Wedge extends Arc {
  /**
   * Constructor
   * @param {number} radius - the radius of the wedge
   * @param {NumberRange} angles - the starting and end angles of the wedge
   * @param {BaseStyle} styling - the styling to apply to the wedge
   * @param {Vector} [centre] - the centre of the wedge. Defaults to (0,0)
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(radius: number, angles: NumberRange, styling: BaseStyle, centre?: Vector, rotationalCentre?: Vector) {
    super(radius, angles, styling, centre, rotationalCentre);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    ctx.moveTo(this.centre.x(), this.centre.y());
    super.drawContinue(ctx);
    this.styling.apply(ctx);
    Canvas.resetTransformationState(ctx);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Wedge {
    let wedge = new Wedge(this.radius, this.angles.clone(), styling, this.centre.clone(), this.rotCentre.clone());
    wedge.angle = this.angle;
    return wedge;
  }
}
