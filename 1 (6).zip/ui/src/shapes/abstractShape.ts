import { Rotatable } from "../rotatable";
import { BaseStyle } from "../styles/baseStyle";
import { Vector } from "../maths/vector";
import { Canvas } from "../canvas";

/**
 * Represents a drawable shape
 */
export abstract class AbstractShape extends Rotatable {
  /**
   * @constructor
   * @param {BaseStyle} styling - the styling to apply to the shape
   * @param {Vector} [centre] - the centre point of the shape. Defaults to (0,0)
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  protected constructor(protected readonly styling: BaseStyle, centre = new Vector(), rotationalCentre = new Vector()) {
    super(centre, rotationalCentre);
    this.setRotationalCentre(rotationalCentre);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    this.applyRotation(ctx);
    this.drawContinue(ctx);
    this.applyStyling(ctx);
    Canvas.resetTransformationState(ctx);
  }

  /**
   * Applies the styling of this shape to a 2D canvas context
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to apply this
   * shapes styling to
   */
  private applyStyling(ctx: CanvasRenderingContext2D): void {
    this.styling.apply(ctx);
  }

  /**
   * Applies the rotation transformation of a canvas 2D context for drawing the rotated shape
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to rotate
   */
  private applyRotation(ctx: CanvasRenderingContext2D): void {
    ctx.translate(this.rotCentre.x(), this.rotCentre.y());
    ctx.rotate(this.angle);
    ctx.translate(-this.rotCentre.x(), -this.rotCentre.y());
  }

  /**
   * Draws the shape on a canvas context object. Unlike draw(), this method does not begin nor end
   * the path for the given context object. Before calling this method, beginPath() should be
   * called to ensure correct rendering
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
   */
  public abstract drawContinue(ctx: CanvasRenderingContext2D): void;

  /**
   * Creates a new shape with the same properties as this shape but with styling properties from the given style object
   * @param {BaseStyle} styling - the new styling to apply
   * @returns {AbstractShape} the new shape
   */
  public abstract changeStyling(styling: BaseStyle): AbstractShape;
}
