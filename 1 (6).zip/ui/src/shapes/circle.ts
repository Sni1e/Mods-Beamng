import { Arc } from "./arc";
import { NumberRange } from "../maths/numberRange";
import { Vector } from "../maths/vector";
import { BaseStyle } from "../styles/baseStyle";
import { Style } from "../styles/style";

/**
 * Represents a drawable circle
 */
export class Circle extends Arc {
  /**
   * Constructor
   * @param {number} radius - the radius of the circle
   * @param {BaseStyle} styling - the styling to apply to the circle
   * @param {Vector} [centre] - the centre of the circle. Defaults to (0,0)
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(radius: number, styling: BaseStyle, centre?: Vector, rotationalCentre?: Vector) {
    super(radius, new NumberRange(0, 2 * Math.PI), styling, centre, rotationalCentre);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Circle {
    let circle = new Circle(this.radius, styling, this.centre.clone(), this.rotCentre.clone());
    circle.angle = this.angle;
    return circle;
  }
}
