import { AbstractShape } from "./abstractShape";
import { BaseStyle } from "../styles/baseStyle";
import { Vector } from "../maths/vector";
import { Style } from "../styles/style";

/**
 * Represent a rectangle
 */
export class Rectangle extends AbstractShape {
  /**
   * Constructor
   * @param {number} width - the width of the rectangle
   * @param {number} height - the height of the rectangle
   * @param {BaseStyle} styling - the styling to apply
   * @param {Vector} [centre] - the position of the top left point. Defaults to (0,0)
   * @param {boolean} [isFillCentred] - whether to centre the X position of the rectangle with the
   * fill style. Defaults to false
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(
    private readonly width: number,
    private readonly height: number,
    styling: BaseStyle,
    centre?: Vector,
    private readonly isFillCentred = false,
    rotationalCentre?: Vector
  ) {
    super(styling, centre, rotationalCentre);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public setCentre(centre: Vector): void {
    super.setCentre(centre);

    if (this.isFillCentred) this.centre.addX(-this.width / 4);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    ctx.rect(this.centre.x(), this.centre.y(), this.width, this.height);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Rectangle {
    let rectangle = new Rectangle(
      this.width,
      this.height,
      styling,
      this.centre,
      this.isFillCentred,
      this.rotCentre.clone()
    );
    rectangle.angle = this.angle;
    return rectangle;
  }
}
