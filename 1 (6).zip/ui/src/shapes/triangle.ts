import { Line } from "./line";
import { BaseStyle } from "../styles/baseStyle";
import { Vector } from "../maths/vector";
import { Style } from "../styles/style";

/**
 * Represents a drawable triangle
 */
export class Triangle extends Line {
  /**
   * Constructor
   * @param {Vector} point1 - the first vertex
   * @param {Vector} point2 - the second vertex
   * @param {Vector} point3 - the third vertex
   * @param {BaseStyle} styling - the styling to apply to the triangle
   * @param {Vector} [rotationalCentre] - the rotation point during rotation. Defaults to (0,0)
   */
  constructor(
    point1: Vector,
    point2: Vector,
    private readonly point3: Vector,
    styling: BaseStyle,
    rotationalCentre: Vector
  ) {
    super(point1, point2, styling, rotationalCentre);
    // Calculate and set centre
    this.setCentre(this.calculateCentrePoint());
  }

  /**
   * @Override
   * @inheritDoc
   */
  public translate(translation: Vector): void {
    super.translate(translation);
    this.point3.add(translation);
  }

  /**
   * Constructs and returns an isosceles triangle.
   * The rotational centre will be set to (0,0)
   * @param {number} baseWidth - the width of the base
   * @param {number} height - the height
   * @param {BaseStyle} styling - the styling to apply to the triangle
   * @param {Vector} centre - the point to put the triangle's centre to
   * @param {number} [angle] - the angle to rotate the triangle by. By default, the triangle will
   * face right at 0 radians
   * @returns {Triangle} the triangle created
   */
  public static newIsosceles(
    baseWidth: number,
    height: number,
    styling: BaseStyle,
    centre: Vector,
    angle = 0
  ): Triangle {
    let p1 = new Vector(baseWidth / 2, 0).rotateAboutOrigin(angle);
    let p2 = new Vector(-baseWidth / 2, 0).rotateAboutOrigin(angle);
    let p3 = new Vector(0, height).rotateAboutOrigin(angle);

    let triangle = new Triangle(p1, p2, p3, styling, new Vector());
    triangle.setCentre(centre);
    return triangle;
  }

  /**
   * Calculates the centre point of the triangle
   * @returns {Vector}
   */
  public calculateCentrePoint(): Vector {
    let sum = new Vector();
    sum.add(this.point1);
    sum.add(this.point2);
    sum.add(this.point3);
    return Vector.div(sum, 3);
  }

  /**
   * @Override
   * @inheritDoc
   */
  public drawContinue(ctx: CanvasRenderingContext2D): void {
    super.drawContinue(ctx);
    ctx.lineTo(this.point3.x(), this.point3.y());
    ctx.lineTo(this.point1.x(), this.point1.y());
  }

  /**
   * @Override
   * @inheritDoc
   */
  public changeStyling(styling: BaseStyle): Triangle {
    let triangle = new Triangle(
      this.point1.clone(),
      this.point2.clone(),
      this.point3.clone(),
      styling,
      this.rotCentre.clone()
    );
    triangle.angle = this.angle;
    return triangle;
  }
}
