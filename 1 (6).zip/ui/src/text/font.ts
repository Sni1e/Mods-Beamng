import { Vector } from "../maths/vector";

/**
 * Represents a font for text displaying
 */
export class Font {
  /**
   * @constructor
   * @param {string} FONT_NAME - the font name
   * @param {number} FONT_SIZE - the font size
   * @param {boolean} IS_CENTRED - whether the text is centre
   */
  constructor(
    public readonly FONT_NAME: string,
    public readonly FONT_SIZE: number,
    public readonly IS_CENTRED: boolean
  ) {}

  /**
   * Applies the font to a canvas object so that the next time text is drawn on this canvas, this font styling is
   * applied
   * @param {CanvasRenderingContext2D} ctx
   */
  public apply(ctx: CanvasRenderingContext2D): void {
    ctx.textAlign = this.IS_CENTRED ? "center" : "left";
    ctx.textBaseline = this.IS_CENTRED ? "middle" : "alphabetic";
    ctx.font = this.FONT_SIZE + "px " + this.FONT_NAME;
  }

  /**
   * Returns the width and height of the font when rendering a text character
   * <b>Note: this will only be valid if the font is monospaced</b>
   * @param {CanvasRenderingContext2D} ctx - a canvas for trial rendering
   * @param {string} text - the text to render (should be of length 1)
   * @return {Vector} the width/height of the font when rending the passed text
   */
  private getFontDimensions(ctx: CanvasRenderingContext2D, text: string): Vector {
    this.apply(ctx);
    return new Vector(ctx.measureText(text).width, ctx.measureText(text).width);
  }

  /**
   * Returns the centre offset vector for rendering a particular piece of text to a position, such
   * that it is fully centred.
   * <b>Note: this will only work if the font is monospaced</b>
   * @param {CanvasRenderingContext2D} ctx - a canvas for trial rendering
   * @param {string} text - the text to get the centre offset vector of
   * @return {Vector} the centre offset vector
   */
  public getCentreFix(ctx: CanvasRenderingContext2D, text: string): Vector {
    let dims = this.getFontDimensions(ctx, text);
    dims.div(2);

    if (text.length === 1) return new Vector(-dims.x(), dims.y());
    // Height is the same as single characters
    else return new Vector(-dims.x(), this.getFontDimensions(ctx, "0").x() / 2);
  }
}
