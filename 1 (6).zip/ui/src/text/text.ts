import { Drawable } from "../drawable";
import { Font } from "./font";
import { Vector } from "../maths/vector";
import { Canvas } from "../canvas";
import { Style } from "../styles/style";
import { BaseStyle } from "../styles/baseStyle";

/**
 * Represents text of a given font and position
 */
export class Text extends Drawable {
  /**
   * @constructor
   * @param {Font} font - the font to use for the text
   * @param {string} text - the text to display
   * @param {Vector} position - the position the text will be displayed at
   * @param {BaseStyle} style - the text colour/style
   */
  constructor(
    private readonly font: Font,
    private text: string,
    private readonly position: Vector,
    private style: BaseStyle
  ) {
    super();
  }

  public setText(text: string): void {
    this.text = text;
  }

  public setColour(colour: string): void {
    if (!this.style) {
      this.style = Style.noStrokeFill(colour);
    } else if (this.style instanceof Style) {
      this.style = this.style.changeColour(colour);
    } else {
      console.warn("setColour() not implemented for " + typeof this.style + " yet!");
    }
  }

  /**
   * @Override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.font.apply(ctx);
    this.style.setVars(ctx);

    ctx.fillText(this.text, this.position.x(), this.position.y());
    Canvas.resetTransformationState(ctx);
  }
}
