/**
 * Represents a vehicle's engine
 */
export class Engine {
  // The tolerance between when to shift and the maximum engine RPM
  private static SHIFT_TOL = 200;

  private currRPM = 0;

  /**
   * @constructor
   * @param MAX_RPM - The maximum engine RPM (as gotten from the vehicles stats)
   * @param REDLINE_RPM - The next thousand from the maximum RPM, treated as the absolute maximum RPM
   */
  constructor(private readonly MAX_RPM: number, private readonly REDLINE_RPM: number) {}

  /**
   * Sets the current RPM
   * @param {number} rpm  - the RPM to set
   */
  public setCurrRPM(rpm: number): void {
    if (typeof rpm !== "undefined") this.currRPM = rpm;
  }

  /**
   * @return {number} the current RPM
   */
  public getCurrentRPM(): number {
    return this.currRPM;
  }

  /**
   * @return {number} the maximum RPM
   */
  public getMaxRPM(): number {
    return this.MAX_RPM;
  }

  /**
   * @return {number} the redline RPM
   */
  public getRedLineRPM(): number {
    return this.REDLINE_RPM;
  }

  /**
   * @return {number} the redline RPM divided by 1000
   */
  public getRedlineThousand(): number {
    return this.REDLINE_RPM / 1000;
  }

  /**
   * @returns {number} the ratio of current RPM to redline RPM
   */
  public getCurrentRPMRatio(): number {
    return this.currRPM / this.REDLINE_RPM;
  }

  /**
   * @returns {number} the ratio of maximum engine RPM and the redline (next thousand) RPM
   */
  public getRedlineRPMRatio(): number {
    return this.MAX_RPM / this.REDLINE_RPM;
  }

  /**
   * @returns {boolean} whether to shift up to the next gear
   */
  public shouldShiftUp(): boolean {
    return this.currRPM >= this.MAX_RPM - Engine.SHIFT_TOL;
  }
}
