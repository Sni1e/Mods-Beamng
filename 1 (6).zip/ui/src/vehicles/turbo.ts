/**
 * Represents a turbo
 */
export class Turbo {
  private currBoost = 0;

  /**
   * @constructor
   * @param {number} MAX_BOOST - the maximum boost this turbo can generate
   */
  constructor(private readonly MAX_BOOST: number) {}

  /**
   * Sets the current boost value
   * @param {number} boost - the value to set
   */
  public setBoost(boost: number): void {
    if (typeof boost !== "undefined") this.currBoost = boost;
  }

  /**
   * @returns {number} the maximum boost value
   */
  public getMaxBoost(): number {
    return this.MAX_BOOST;
  }

  /**
   * @returns {number} the current boost value
   */
  public getBoost(): number {
    return this.currBoost;
  }

  /**
   * @returns {number} the normalised boost value
   */
  public getNormBoost(): number {
    // Normalise from range [-1,1] to [0,1]
    return (this.currBoost / this.MAX_BOOST + 1) / 2;
  }
}
