/**
 * Represents a gearbox
 */
export class Gearbox {
  /**
   * Constructor
   * @param {number | string} gear - the currently selected gear
   */
  constructor(private gear: number | string) {}

  /**
   * Sets the current gear
   * @param {number | string} gear - the gear to set
   */
  public setGear(gear: number | string): void {
    this.gear = gear;
  }

  /**
   * @return {string} Returns the string name of the gear currently selected on this gearbox
   */
  public getGearName(): string {
    return typeof this.gear === "string" ? this.gear : Gearbox.getGearNameManual(this.gear);
  }

  /**
   * @returns {string | number} the gear number
   */
  public getGear(): string | number {
    return this.gear;
  }

  /**
   * Converts a gear number into its string name.
   * Mapping:
   *   < -1  -> R2...R(|n|+1)
   *   = -1  -> R
   *   =  0  -> N
   *  >=  1  -> 1...n
   * @param {number} gear - the gear number
   * @returns {string} the string name for this gear number
   */
  private static getGearNameManual(gear: number): string {
    let gearName;

    if (gear === 0) {
      gearName = "N";
    } else if (gear < 0) {
      // Add index of reverse gear if more than one exists
      if (gear < -1) gearName = "R" + Math.abs(gear);
      else gearName = "R";
    } else {
      gearName = gear.toString();
    }

    return gearName;
  }
}
