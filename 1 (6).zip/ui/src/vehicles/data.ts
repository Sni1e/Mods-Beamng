export interface IndicatorData {
  left: number;
  right: number;
}

export interface EngineData {
  redlineRPM: number;
  maxRPM: number;
}

export interface BoostData {
  boost: number;
}

export interface TachometerData {
  currRPM: number;
  gear: string | number;
  pBrakeEnabled: boolean;
  speed: number;
  fuel: number;
  temp: number;
  brake: number;
  throttle: number;
  indicators: IndicatorData;
  lightState: number;
}
