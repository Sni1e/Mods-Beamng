angular.module("beamng.apps").factory("TachometersAppBase", [
  function () {
    /**
     * @returns {boolean} whether the main script has loaded yet
     */
    function hasMainScriptLoaded() {
      return typeof AbstractAppContainer !== "undefined";
    }

    /**
     * Waits for the main script and then runs the given function when it has loaded.
     * If the main script does not load after 5s, an error is logged and the function remains uncalled
     * @param {Function} func - the function to run
     */
    function waitForMainScript(func) {
      // Poll every 0.1s
      let t = setInterval(() => {
        if (hasMainScriptLoaded()) {
          func();
          clearInterval(t);
          t = null;
        }
      }, 100);

      // Give up after 5s; assume it is not going to load after then
      setTimeout(() => {
        if (t) {
          console.error("Attempted to load class AbstractAppContainer; timed out!");
          clearInterval(t);
        }
      }, 5000);
    }

    /**
     * Creates a new app instance
     * @param {class<T>} appClass - the app class to create an instance of
     * @param {object} bngApi - the BeamNG api service
     * @param {object} UiUnits - the BeamNG UiUnits service
     * @param {number} radius - the default radius of the app
     * @param {class<S>} containerClass - the container class to wrap
     * the app in
     * @template T: ? extends {@link AbstractBaseApp}
     * @template S: ? extends {@link AbstractAppContainer}
     * @return {S}
     */
    function loadApp(appClass, bngApi, UiUnits, radius, containerClass) {
      let app = new appClass(radius, document, bngApi, UiUnits);
      return new containerClass(app);
    }

    /**
     * Creates a new tachometer app instance, wrapped in a container class
     * @param {class<T>} appClass - the app class to create an instance of
     * @param {object} bngApi - the BeamNG api service
     * @param {object} UiUnits - the BeamNG UiUnits service
     * @return {TachometerAppContainer} the app container created
     */
    function loadTachometerApp(appClass, bngApi, UiUnits) {
      return loadApp(appClass, bngApi, UiUnits, 150, TachometerAppContainer);
    }

    /**
     * Creates a new forced induction app instance, wrapped in a container class
     * @param {class<T>} appClass - the app class to create an instance of
     * @param {object} bngApi - the BeamNG api service
     * @param {object} UiUnits - the BeamNG UiUnits service
     * @return {BoostAppContainer} the app container created
     */
    function loadBoostApp(appClass, bngApi, UiUnits) {
      return loadApp(appClass, bngApi, UiUnits, 75, BoostAppContainer);
    }

    /**
     * Returns the app class for an app type and theme.
     * Note that the scripts MUST be loaded in order for the returned object to exist
     * @param {string} appType - the app type
     * @param {string} appTheme - the app theme
     * @return {AbstractBaseApp} the app class
     */
    function getAppClass(appType, appTheme) {
      switch (true) {
        case appTheme === "velocity" && appType === "tachometer":
          return VelocityTachometerApp;
        case appTheme === "velocity" && appType === "forcedInduction":
          return VelocityBoostApp;
        case appTheme === "fusion" && appType === "tachometer":
          return FusionTachometerApp;
        case appTheme === "fusion" && appType === "forcedInduction":
          return FusionBoostApp;
        case appTheme === "ringularity" && appType === "tachometer":
          return RingularityTachometerApp;
        case appTheme === "ringularity" && appType === "forcedInduction":
          return RingularityBoostApp;
      }
    }

    /**
     * Loads the additional scripts required for this app to function
     * @param {string} appType - the app type
     * @param {string} appTheme - the app theme
     * @param {object} bngApi - the BeamNG api service
     * @param {object} UiUnits - the BeamNG UiUnits service
     * @param {(AbstractAppContainer, AbstractAppContainer) => void} callback - the callback function to call once the app is setup
     */
    function createApp(appType, appTheme, bngApi, UiUnits, callback) {
      let isTachometerApp = appType === "tachometer";
      let appClass = getAppClass(appType, appTheme);

      let app = isTachometerApp
        ? loadTachometerApp(appClass, bngApi, UiUnits)
        : loadBoostApp(appClass, bngApi, UiUnits);
      let containerClass = isTachometerApp ? TachometerAppContainer : BoostAppContainer;

      callback(app, containerClass);
    }

    /**
     * Adds in the tachometersAppHandler script for loading everything else.
     * Acts as an interface between the app directive and the app logic
     * @param {string} appType - the app type
     * @param {string} appTheme - the app theme
     * @param {object} bngApi - the BeamNG api service
     * @param {object} UiUnits - the BeamNG UiUnits service
     * @param {(appCon: AbstractAppContainer, containerClass: class extends AbstractAppContainer) => void} callback - the callback function to call once the app is setup
     */
    function loadMainScript(appType, appTheme, bngApi, UiUnits, callback) {
      const ID = "tachometers";
      let task = () => createApp(appType, appTheme, bngApi, UiUnits, callback);

      let script = document.getElementById(ID);
      // If the script already exists, don't add it in again
      if (script) {
        if (!hasMainScriptLoaded()) {
          waitForMainScript(task);
        } else {
          task();
        }
      } else {
        script = document.createElement("script");
        script.src = "../../composite.all.js";
        script.id = ID;
        script.onload = task;
        document.head.append(script);
      }
    }

    // Public interface
    return {
      load: loadMainScript
    };
  }
]);
