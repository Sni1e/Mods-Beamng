// A dimension object
export type Dimensions = { width: number; height: number };

// A dimension object or null
export type NullableDimensions = Dimensions | null;
