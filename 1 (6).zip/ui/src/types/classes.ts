/* Pass class as parameter as new (...) => T */
export type Newable<T> = { new (...args: any[]): T; };