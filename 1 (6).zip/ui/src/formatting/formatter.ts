/**
 * @template T, S
 * T is the type of data that can be formatted
 * S is the type of data after formatting
 */
export interface Formatter<T, S> {
  /**
   * Formats the given data
   * @param {T} unformatted - the data to format
   * @returns {string} the formatted string
   */
  format(unformatted: T): S;
}
