import { Formatter } from "./formatter";

export class DecimalFormatter implements Formatter<number, string> {
  constructor(private readonly numDecimals: number) {}

  /**
   * @override
   * @inheritDoc
   */
  public format(unformatted: number): string {
    return unformatted.toFixed(this.numDecimals);
  }
}
