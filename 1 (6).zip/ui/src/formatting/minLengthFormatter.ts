import { Formatter } from "./formatter";
import { precede } from "../utils/mathsUtils";

export class MinLengthFormatter implements Formatter<number, string> {
  constructor(private readonly minDigits: number) {}

  /**
   * @override
   * @inheritDoc
   */
  public format(unformatted: number): string {
    return precede(Math.floor(unformatted), this.minDigits);
  }
}
