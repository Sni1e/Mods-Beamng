/**
 * Represents an object is drawable to a canvas context object
 */
export abstract class Drawable {
  /**
   * Draws the object to a canvas context object
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
   */
  public abstract draw(ctx: CanvasRenderingContext2D): void;
}
