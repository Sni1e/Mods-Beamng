import { AbstractBaseApp } from "./abstractBaseApp";
import { Turbo } from "../vehicles/turbo";
import { UnitisedComponent } from "../gauges/components/unitisedComponent";
import { BoostGaugeComponent } from "../gauges/components/boostGaugeComponent";
import { BoostData } from "../vehicles/data";
import { Quantity } from "../maths/units/quantity";
import { UnitConversion } from "../maths/units/unitConversion";
import { ConvertableUnit } from "../maths/units/convertableUnit";
import { DecimalFormatter } from "../formatting/decimalFormatter";
import { Theme } from "./themes/theme";
import { AbstractPressureGaugeBuilder } from "../gauges/components/builders/fullGauge/abstractPressureGaugeBuilder";
import { AbstractBackground } from "./abstractBackground";
import { Newable } from "../types/classes";

/**
 * Represents a forced induction app that can display data from a vehicle
 */
export abstract class AbstractBoostApp extends AbstractBaseApp<BoostData, number, BoostGaugeComponent> {
  protected turbo: Turbo = null;
  protected gauge: BoostGaugeComponent = null;
  protected pressure: UnitisedComponent = null;

  /**
   * @constructor
   * @param {Theme} theme - the theme of this app
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   * @param {Newable<AbstractPressureGaugeBuilder>} GaugeBuilder - the gauge builder class to use when creating pressure
   * gauge components
   * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
   */
  protected constructor(
    theme: Theme,
    baseRadius: number,
    document: Document,
    bngApi: any,
    GaugeBuilder: Newable<AbstractPressureGaugeBuilder>,
    Background: Newable<AbstractBackground>,
  ) {
    super(theme, baseRadius, document, bngApi, GaugeBuilder, Background);
  }

  /**
   * @override
   * @inheritDoc
   * @param {number} data - the maximum boost of the vehicle to initialise with
   */
  public sendInitialVehicleData(data: number): void {
    this.turbo = new Turbo(data);
    this.createComponents();
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: BoostData): void {
    this.turbo.setBoost(data.boost);

    this.gauge.update(this.turbo);
    this.pressure.update(data.boost);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();

    let ctx = this.canvas.get2DContext();
    this.gauge.draw(ctx);
    this.pressure.draw(ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createComponents(): void {
    this.gauge = this.createGauge();
    this.pressure = this.createPressureReadout();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected cycleUnit(): void {
    this.pressure.cycleUnit();
    this.updateGaugePrecision();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getIndexOfCurrUnit(): number {
    return this.pressure.getIndexOfCurrent();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected setIndexOfCurrUnit(index: number): void {
    this.pressure.setIndexOfCurrent(index);
    this.updateGaugePrecision();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getQuantityInstance(): Quantity {
    if (this.pressure) return this.pressure.getQuantity();
    else return this.getNewQuantityInstance();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected setDefaultGaugeBuilderValues(builder: Newable<AbstractPressureGaugeBuilder>): AbstractPressureGaugeBuilder {
    return (super.setDefaultGaugeBuilderValues(builder) as AbstractPressureGaugeBuilder)
      .setMaxBoost(this.getMaxBoostFromTurbo())
      .setMaxBoostConverted(this.getMaxBoostFromTurboConverted());
  }

  /**
   * @override
   * @inheritDoc
   */
  public isSetup(): boolean {
    return this.turbo !== null;
  }

  /**
   * @override
   * @inheritDoc
   */
  public getId(): string {
    return this.theme.BASE_ID + "FI";
  }

  /**
   * Updates the gauge's precision. Should be called whenever the unit on the pressure gauge changes
   */
  private updateGaugePrecision(): void {
    let quantity = this.pressure.getQuantity();
    let newDps = this.getGaugePrecision(quantity.getUnit());
    quantity.changeFormatter(new DecimalFormatter(newDps));
  }

  /**
   * Returns the number of decimal places that will be used for displaying any relevant values on
   * the pressure gauge
   * @param {ConvertableUnit} unit - the unit to use
   * @return {number} the number of decimal places
   */
  private getGaugePrecision(unit: ConvertableUnit): number {
    return UnitConversion.convert(unit, this.turbo.getMaxBoost()) > 10 ? 0 : 1;
  }

  /**
   * @return {Quantity} a new Unit instance for the pressure displayer
   */
  protected getNewQuantityInstance(): Quantity {
    let unit = new UnitConversion(Quantity.boost());
    let formatter = new DecimalFormatter(this.getGaugePrecision(unit.getUnit()));
    return new Quantity(unit, formatter);
  }

  /**
   * @returns {number} the maximum boost from the turbo
   * @protected
   */
  protected getMaxBoostFromTurbo(): number {
    return this.turbo.getMaxBoost();
  }

  /**
   * @returns {number} the maximum boost from the turbo, converted to the current units from {@link getQuantityInstance}
   * @protected
   */
  protected getMaxBoostFromTurboConverted(): number {
    let boost = this.getMaxBoostFromTurbo();
    let quantity = this.getQuantityInstance();
    return Number.parseFloat(quantity.convert(boost).value);
  }

  /**
   * Updates a boost app from a stream update event
   * @param {any} streams - the streams to update from
   * @param {AbstractBoostApp} app - the tachometer app to update
   */
  public static streamsUpdate(streams: any, app: AbstractBoostApp): void {
    if (!app || !streams || !streams.forcedInductionInfo) return;

    let forcedInductionInfo = streams.forcedInductionInfo;

    // Perform first time setup
    if (app.turbo === null) {
      app.sendInitialVehicleData(forcedInductionInfo.maxBoost);
      app.load();
    } else {
      app.update({ boost: forcedInductionInfo.boost });
      app.draw();
    }
  }

  /**
   * Creates the pressure readout component
   */
  protected abstract createPressureReadout(): UnitisedComponent;
}
