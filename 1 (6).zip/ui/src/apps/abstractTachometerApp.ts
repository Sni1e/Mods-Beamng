import { AbstractBaseApp } from "./abstractBaseApp";
import { Engine } from "../vehicles/engine";
import { Gearbox } from "../vehicles/gearbox";
import { RPMComponent } from "../gauges/components/RPMComponent";
import { IndicatorsComponent } from "../gauges/components/indicatorsComponent";
import { TextParkingBrakeComponent } from "../gauges/components/textParkingBrakeComponent";
import { UnitisedComponent } from "../gauges/components/unitisedComponent";
import { GearComponent } from "../gauges/components/gearComponent";
import { AbstractDataDisplayer } from "../gauges/dataDisplayers/abstractDataDisplayer";
import { AbstractBarCollectionBuilder } from "../gauges/components/builders/barCollection/abstractBarCollectionBuilder";
import { EngineData, TachometerData } from "../vehicles/data";
import { Quantity } from "../maths/units/quantity";
import { UnitConversion } from "../maths/units/unitConversion";
import { DecimalFormatter } from "../formatting/decimalFormatter";
import { Theme } from "./themes/theme";
import { AbstractRPMGaugeBuilder } from "../gauges/components/builders/fullGauge/abstractRPMGaugeBuilder";
import { AbstractBackground } from "./abstractBackground";
import { Newable } from "../types/classes";
import { lastDigitsOf } from "../utils/mathsUtils";

/**
 * Represents a base Tachometer modded app
 */
export abstract class AbstractTachometerApp extends AbstractBaseApp<TachometerData, EngineData, RPMComponent> {
  protected engine: Engine = null;
  protected gearbox: Gearbox = null;

  protected RPMGauge: RPMComponent = null;
  protected indicators: IndicatorsComponent = null;
  protected pBrake: TextParkingBrakeComponent = null;
  protected speedo: UnitisedComponent = null;
  protected gear: GearComponent = null;

  protected fuelGauge: AbstractDataDisplayer<number> = null;
  protected tempGauge: AbstractDataDisplayer<number> = null;
  protected throttleGauge: AbstractDataDisplayer<number> = null;
  protected brakeGauge: AbstractDataDisplayer<number> = null;

  /**
   * @constructor
   * @param {Theme} theme - the theme of this app
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   * @param {Newable<AbstractRPMGaugeBuilder>} GaugeBuilder - the gauge builder class to use when creating RPM gauge
   * components
   * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
   */
  protected constructor(
    theme: Theme,
    baseRadius: number,
    document: Document,
    bngApi: any,
    GaugeBuilder: Newable<AbstractRPMGaugeBuilder>,
    Background: Newable<AbstractBackground>,
  ) {
    super(theme, baseRadius, document, bngApi, GaugeBuilder, Background);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();

    let ctx = this.canvas.get2DContext();
    this.getComponents().forEach(component => component.draw(ctx));
  }

  /**
   * @override
   * @inheritDoc
   */
  protected cycleUnit(): void {
    this.speedo.cycleUnit();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createComponents(): void {
    this.RPMGauge = this.createGauge();
    this.speedo = this.createSpeedoComponent();
    this.indicators = this.createIndicatorsComponent();
    this.pBrake = this.createPBrakeComponent();
    this.gear = this.createGearComponent();
    this.createBarCollection();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getIndexOfCurrUnit(): number {
    return this.speedo.getIndexOfCurrent();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected setIndexOfCurrUnit(index: number): void {
    this.speedo.setIndexOfCurrent(index);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected setDefaultGaugeBuilderValues(builder: Newable<AbstractRPMGaugeBuilder>): AbstractRPMGaugeBuilder {
    return (super.setDefaultBuilderValues(builder) as AbstractRPMGaugeBuilder)
      .setEngine(this.engine);
  }

  /**
   * Creates the oil, fuel, brake and throttle gauges
   */
  protected createBarCollection(): void {
    let builder = this.createBarCollectionBuilder();
    this.brakeGauge = builder.buildBrakeBar();
    this.throttleGauge = builder.buildThrottleBar();
    this.tempGauge = builder.buildTempBar();
    this.fuelGauge = builder.buildFuelBar();
  }

  /**
   * Returns the list of components, treated as a list of AbstractDataDisplayer.
   * Note the order of components returned are in the order of being drawn. Should this be different
   * in a subclass, it is expected that that subclass will override this method
   * @returns {AbstractDataDisplayer[]}
   */
  protected getComponents(): AbstractDataDisplayer<any>[] {
    return [
      this.fuelGauge,
      this.tempGauge,
      this.throttleGauge,
      this.brakeGauge,
      this.RPMGauge,
      this.speedo,
      this.gear,
      this.indicators,
      this.pBrake
    ];
  }

  /**
   * @override
   * @inheritDoc
   */
  public sendInitialVehicleData(data: EngineData): void {
    this.engine = new Engine(data.maxRPM, data.redlineRPM);
    // Can use any initial value here as it will be overwritten later; default to neutral for now
    this.gearbox = new Gearbox(0);

    // Now safe to generate components
    this.createComponents();
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: TachometerData): void {
    this.engine.setCurrRPM(data.currRPM);
    this.gearbox.setGear(data.gear);

    this.pBrake.update(data.pBrakeEnabled);
    this.speedo.update(data.speed);
    this.RPMGauge.update(this.engine);
    this.fuelGauge.update(data.fuel);
    this.tempGauge.update(data.temp);
    this.brakeGauge.update(data.brake);
    this.throttleGauge.update(data.throttle);
    this.gear.update({
      gearbox: this.gearbox,
      shouldShift: this.engine.shouldShiftUp()
    });
    this.indicators.update({
      left: data.indicators.left,
      right: data.indicators.right
    });

    this.bgNeedsRedraw = this.background.updateLighting(this.getLightColour(data.lightState));
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getQuantityInstance(): Quantity {
    if (this.speedo) return this.speedo.getQuantity();
    else return this.getNewUnitInstance();
  }

  /**
   * @override
   * @inheritDoc
   */
  public isSetup(): boolean {
    return this.engine !== null;
  }

  /**
   * @override
   * @inheritDoc
   */
  public getId(): string {
    return this.theme.BASE_ID + "T";
  }

  /**
   * @return {Quantity} a new Quantity instance for the speedometer. This converts only to whole, integer values
   */
  protected getNewUnitInstance(): Quantity {
    let units = new UnitConversion(Quantity.speed());
    return new Quantity(units, new DecimalFormatter(0));
  }

  /**
   * Updates the app via the streams system
   * @param {any} electrics - the electrics stream
   * @param {any} engineInfo - the engineInfo stream
   */
  public updateFromStreams(electrics: any, engineInfo: any): void {
    this.update({
      pBrakeEnabled: electrics.parkingbrake_input === 1,
      temp: electrics.watertemp,
      fuel: engineInfo[11] / engineInfo[12],
      currRPM: engineInfo[4],
      speed: electrics.wheelspeed,
      gear: engineInfo[5],
      throttle: electrics.throttle_input,
      brake: electrics.brake_input,
      indicators: {
        left: electrics.signal_L,
        right: electrics.signal_R
      },
      lightState: AbstractTachometerApp.getLightState(electrics)
    });
  }

  /**
   * Returns the colour of the lights, given their state integer value
   * @param {number} lightState - the light state
   * @return {string} the light colour
   */
  protected getLightColour(lightState: number): string {
    return AbstractTachometerApp.getLightColour(lightState);
  }

  /**
   * Updates a tachometer app from a stream update event
   * @param {any} streams - the streams to update from
   * @param {AbstractTachometerApp} app - the tachometer app to update
   */
  public static streamsUpdate(streams: any, app: AbstractTachometerApp): void {
    // The last condition is there since it is possible for the engineInfo stream to exist, but not
    // to have received any engine info yet
    if (!app || !streams || !streams.engineInfo || !streams.electrics || !streams.engineInfo[1]) return;

    // Perform first time setup
    if (!app.engine) {
      let maxRPM = streams.engineInfo[1];
      app.sendInitialVehicleData({
        maxRPM: maxRPM,
        redlineRPM: (Math.floor(maxRPM / 1000) + 1) * 1000
      });
      app.load();
    } else {
      app.updateFromStreams(streams.electrics, streams.engineInfo);
      app.draw();
    }
  }

  /**
   * Returns the light colour, based on whether the lights are on and what type of lights are on.
   * Any value not of the below set returns "black".
   * All values returned are in hexadecimal format
   * @param {number} lightState - the state of the lights (0 = off, 1 = on, 2 = fog)
   */
  protected static getLightColour(lightState: number): string {
    switch (lightState) {
      case 0:
        return "#000";
      case 1:
        return "#0F0";
      case 2:
        return "#06F";
      default:
        return "#000";
    }
  }

  /**
   * Returns the state of the lights.
   * @param {any} electrics - the electrics stream to read the light state
   * @returns {number} the state of the lights (0 = off, 1 = on, 2 = fog)
   */
  protected static getLightState(electrics: any): number {
    if (electrics.lowbeam) return 1;
    else if (electrics.highbeam) return 2;
    else return 0;
  }

  /**
   * Creates the speedo component
   */
  protected abstract createSpeedoComponent(): UnitisedComponent;

  /**
   * Creates the indicators component
   */
  protected abstract createIndicatorsComponent(): IndicatorsComponent;

  /**
   * Creates the parking brake component
   */
  protected abstract createPBrakeComponent(): TextParkingBrakeComponent;

  /**
   * Creates the gear component
   */
  protected abstract createGearComponent(): GearComponent;

  /**
   * Creates the builder component for creating all of the arc bars
   * @returns {AbstractBarCollectionBuilder} the builder
   */
  protected abstract createBarCollectionBuilder(): AbstractBarCollectionBuilder;
}
