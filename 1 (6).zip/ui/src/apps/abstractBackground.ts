import { Canvas } from "../canvas";
import { Vector } from "../maths/vector";
import { ColourScheme } from "../colours/colourScheme";

/**
 * Represents a static background that can draw to a canvas and redraw periodically for a specific
 * app
 */
export abstract class AbstractBackground {
  // The colour of the lighting (black = none)
  protected lightColour = "#000";

  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw on
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  protected constructor(
    protected readonly ctx: CanvasRenderingContext2D,
    protected readonly centre: Vector,
    protected readonly baseRadius: number,
    protected readonly colourScheme: ColourScheme
  ) {}

  /**
   * Updates the lighting with the new colour. If this new colour is different, a re-draw is in
   * order and this method will return __true__ to indicated this
   * @param {string} lightColour - the colour of the lighting to set
   * @returns {boolean} whether the background needs a re-draw
   */
  public updateLighting(lightColour: string): boolean {
    if (this.lightColour !== lightColour) {
      this.lightColour = lightColour;
      return true;
    }

    return false;
  }

  /**
   * Draws to the internal instance canvas
   */
  public draw(): void {
    Canvas.resetTransformationState(this.ctx);
  }
}
