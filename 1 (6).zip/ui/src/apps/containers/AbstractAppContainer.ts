import { AbstractBaseApp } from "../abstractBaseApp";
import { Dimensions, NullableDimensions } from "../../types/dimensions";

/**
 * Represents a container object for an app tha can setup, update and maintain this app
 */
export abstract class AbstractAppContainer {
  // The initial dimensions
  protected initDimensions: NullableDimensions = null;
  // Whether the initial dimensions have been applied to the app yet
  protected hasInitDimensionsApplied = false;
  // A timer that will countdown to 0. A value of -1 means the timer is inactive
  protected resizingSaveTimer = -1;

  /**
   * @constructor
   * @param {AbstractBaseApp} app - the app
   */
  protected constructor(protected app: AbstractBaseApp<any, any, any>) {}

  /**
   * Sends streams data to the app. If the app is not yet setup, this method also setups the app and
   * handles the app being resized
   * @param {any} streams - the streams
   * @param {(streams: any, app: AbstractBaseApp) => void} appStreamUpdate - the update function to run on the app
   */
  protected onStreamsUpdate(
    streams: any,
    appStreamUpdate: (streams: any, app: AbstractBaseApp<any, any, any>) => void
  ): void {
    if (!this.app) return;

    appStreamUpdate(streams, this.app);

    if (!this.hasInitDimensionsApplied && this.initDimensions !== null && this.app.isSetup())
      this.applyInitDimensions();
    else
      this.updateResizeSaveTimer();
  }

  /**
   * Updates the resizing timer and saves the app if the timer reaches 0.
   * If the timer is not running, this method does nothing
   */
  private updateResizeSaveTimer(): void {
    // Timer not in action
    if (this.resizingSaveTimer === -1) return;

    // Timeout for saving
    if (this.resizingSaveTimer > 0) {
      this.resizingSaveTimer--;
    } else if (this.resizingSaveTimer === 0) {
      this.app.save();
      this.resizingSaveTimer = -1;
    }
  }

  /**
   * Resizes the app with the initial dimensions.
   */
  private applyInitDimensions(): void {
    this.app.resize(this.initDimensions.width);
    this.app.recreate(false);
    this.hasInitDimensionsApplied = true;
  }

  /**
   * Changes the dimensions of the app. Note that the width and height based should be equal (as of
   * right now, all apps have a square/1:1 sizing)
   * @param {Dimensions} newDimensions - the dimensions to set
   */
  protected onAppResized(newDimensions: Dimensions): void {
    if (newDimensions.width !== newDimensions.height)
      console.warn("Width and height are not the same for this app! Width will be used");

    // If the app container hasn't yet been setup, ignore until it has
    if (newDimensions.width === 0) return;

    if (this.app.isSetup()) {
      this.app.resize(newDimensions.width);
      this.app.recreate(false);
      /* Start a timer to save in the future.
         This way, this only saves once after ~0.5s of non-scaling activity by the user, instead of
         every pixel change that occurs */
      this.resizingSaveTimer = 15;
    } else {
      // Save for applying when the app is setup
      this.initDimensions = newDimensions;
    }
  }

  /**
   * Hides the app from view
   */
  public hideApp(): void {
    this.app.hide();
  }

  /**
   * @return {Dimensions} the current dimensions of the app
   */
  public getCurrentAppDimensions(): Dimensions {
    return this.app.getCurrentDimensions();
  }

  /**
   * Sends streams data to the app. If the app is not yet setup, this method also setups the app and
   * handles the app being resized.
   * Classes implementing this should call <b>onStreamsUpdated()</b> (if possible) to do the
   * heavy-lifting
   * @param {any} streams - the streams
   */
  public abstract onStreamsUpdated(streams: any): void;

  /**
   * @return {string[]} the required streams for this app
   */
  public abstract getRequiredStreams(): string[];
}
