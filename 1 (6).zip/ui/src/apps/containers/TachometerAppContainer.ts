import { AbstractBaseApp } from "../abstractBaseApp";
import { AbstractTachometerApp } from "../abstractTachometerApp";
import { AbstractAppContainer } from "./AbstractAppContainer";

/**
 * Represents a container object for a tachometer app tha can setup, update and maintain this app
 */
export class TachometerAppContainer extends AbstractAppContainer {
  /**
   * @constructor
   * @param {AbstractBaseApp} app - the app
   */
  constructor(app: AbstractBaseApp<any, any, any>) {
    super(app);
  }

  /**
   * @override
   * @inheritDoc
   */
  public onStreamsUpdated(streams: any): void {
    this.onStreamsUpdate(streams, AbstractTachometerApp.streamsUpdate);
  }

  /**
   * @override
   * @inheritDoc
   */
  public getRequiredStreams(): string[] {
    return ["electrics", "engineInfo"];
  }
}
