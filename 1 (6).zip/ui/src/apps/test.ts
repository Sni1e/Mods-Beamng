import { AbstractTachometerApp } from "./abstractTachometerApp";
import { BoostData, TachometerData } from "../vehicles/data";
import { AbstractBoostApp } from "./abstractBoostApp";

/**
 * Test classes for creating new tachometer/boost apps.
 * Allows only partial pieces of the app to be built to run/view them,
 */

export abstract class AbstractTestTachometerApp extends AbstractTachometerApp {
  /**
   * @override
   * @inheritDoc
   */
  protected createBarCollection(): void {
    let builder = this.createBarCollectionBuilder();
    this.brakeGauge = builder?.buildBrakeBar();
    this.throttleGauge = builder?.buildThrottleBar();
    this.tempGauge = builder?.buildTempBar();
    this.fuelGauge = builder?.buildFuelBar();
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    // Re-draw if necessary before the foreground canvas does so
    if (this.bgNeedsRedraw) this.drawBackgroundCanvas();

    this.canvas.show(true);
    this.canvas.clear();

    let ctx = this.canvas.get2DContext();
    this.getComponents().forEach(component => component?.draw(ctx));
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: TachometerData): void {
    this.engine?.setCurrRPM(data.currRPM);
    this.gearbox?.setGear(data.gear);

    this.pBrake?.update(data.pBrakeEnabled);
    this.speedo?.update(data.speed);
    this.RPMGauge?.update(this.engine);
    this.fuelGauge?.update(data.fuel);
    this.tempGauge?.update(data.temp);
    this.brakeGauge?.update(data.brake);
    this.throttleGauge?.update(data.throttle);
    this.gear?.update({
      gearbox: this.gearbox,
      shouldShift: this.engine.shouldShiftUp()
    });
    this.indicators?.update({
      left: data.indicators.left,
      right: data.indicators.right
    });

    this.bgNeedsRedraw = this.background?.updateLighting(this.getLightColour(data.lightState));
  }
}

export abstract class AbstractTestBoostApp extends AbstractBoostApp {
  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    // Re-draw if necessary before the foreground canvas does so
    if (this.bgNeedsRedraw) this.drawBackgroundCanvas();

    this.canvas.show(true);
    this.canvas.clear();

    let ctx = this.canvas.get2DContext();
    this.gauge?.draw(ctx);
    this.pressure?.draw(ctx);
  }


  /**
   * @override
   * @inheritDoc
   */
  public update(data: BoostData): void {
    this.turbo.setBoost(data.boost);

    this.gauge?.update(this.turbo);
    this.pressure?.update(data.boost);
  }
}