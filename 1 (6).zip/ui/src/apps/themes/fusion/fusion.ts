import { NumberRange } from "../../../maths/numberRange";
import { Vector } from "../../../maths/vector";
import { UniPointer } from "../../../gauges/dataDisplayers/pointers/uniPointer";
import { Style } from "../../../styles/style";
import { Circle } from "../../../shapes/circle";
import { Arc } from "../../../shapes/arc";
import { MultiShape } from "../../../shapes/multiShape";
import { AbstractBackground } from "../../abstractBackground";
import { Triangle } from "../../../shapes/triangle";
import { LinearGradient } from "../../../styles/gradients/linearGradient";
import { ColourScheme } from "../../../colours/colourScheme";
import { ColourRGB } from "../../../colours/colourRGB";
import { ColourRGBA } from "../../../colours/colourRGBA";
import { Canvas } from "../../../canvas";
import { Theme } from "../theme";
import { AbstractGradient } from "../../../styles/gradients/abstractGradient";

export const FUSION_THEME = new Theme("OCRAStd2", new NumberRange(0.5 * Math.PI, 1.8 * Math.PI), 'F');

export class FusionThemeHelper {
  /**
   * Creates and returns a styled pointer
   * @param {Vector} centre - the centre of the pointer
   * @param {NumberRange} valueRange - the range of value this pointer can point between
   * @param {number} length - the length of the tip of the pointer
   * @param {number} dialRadius - the radius of the dial
   * @param {number} baseRadius - the base radius
   * @param {CanvasRenderingContext2D} ctx - the canvas context that will be drawing this pointer
   * @returns {UniPointer} the pointer created
   */
  public static createPointer(
    centre: Vector,
    valueRange: NumberRange,
    length: number,
    dialRadius: number,
    baseRadius: number,
    ctx: CanvasRenderingContext2D
  ): UniPointer {
    let pointerStyle = new Style("white", 1);
    let pointerPiece = Triangle.newIsosceles(length / 4, length, pointerStyle, centre, -Math.PI / 2);
    let dial = FusionThemeHelper.getDial(dialRadius, baseRadius, centre, ctx);
    return new UniPointer(centre, valueRange, FUSION_THEME.MAIN_ANGLE_RANGE, pointerPiece, dial);
  }

  /**
   * @returns {CanvasGradient} the linear gradient
   */
  private static getDialGradient(baseRadius: number, ctx: CanvasRenderingContext2D): CanvasGradient {
    return new LinearGradient(
      new Vector(baseRadius, 0),
      new Vector(baseRadius, baseRadius * 2),
      AbstractGradient.distributeEvenly(["#555555", "#222222", "black"])
    ).createGradient(ctx);
  }

  /**
   * Creates and returns a dial object for the pointer centre piece
   * @param {number} radius - the radius of the dial itself
   * @param {number} baseRadius - the radius of the app as a whole this dial is being drawn with
   * @param {Vector} centre - the centre of the dial
   * @param {CanvasRenderingContext2D} ctx - the canvas context that will be drawing this dial
   * @returns {MultiShape} the dial created
   */
  private static getDial(radius: number, baseRadius: number, centre: Vector, ctx: CanvasRenderingContext2D): MultiShape {
    // The bottom semi-circle
    const STYLE = Style.noStrokeFill("#111111");
    let bottom = new Circle(radius, STYLE, centre);

    // The top semi-circle
    const RANGE = new NumberRange(Math.PI, 2 * Math.PI);
    const STYLE2 = Style.noStrokeFill(FusionThemeHelper.getDialGradient(baseRadius, ctx));
    let top = new Arc(radius, RANGE, STYLE2, centre);

    return new MultiShape([bottom, top], centre, centre);
  }
}

/**
 * Represents the fusion theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
export abstract class FusionBackground extends AbstractBackground {
  protected readonly BG_COLOURS: { OUTER: Style; TICKS: Style; NUMS: Style };

  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  protected constructor(
    ctx: CanvasRenderingContext2D,
    centre: Vector,
    baseRadius: number,
    colourScheme: ColourScheme
  ) {
    super(ctx, centre, baseRadius, colourScheme);
    // The background colours for the background concentric circles
    this.BG_COLOURS = this.setupBGStyles();
  }

  /**
   * Returns the colour for the outermost background circle
   * @return {string} the colour
   */
  private getOuterBGColour(): string {
    let colourRGB = ColourRGB.colourToInstance(this.colourScheme.BACKGROUND);
    let colour: ColourRGB;

    if (colourRGB instanceof ColourRGBA)
      // Force no-alpha
      colour = new ColourRGB(colourRGB.R, colourRGB.G, colourRGB.B);
    else colour = colourRGB;

    return colour.darken(20).toString();
  }

  /**
   * Returns the styles for each of the background circles
   * @return {{TICKS: Style, NUMS: Style, OUTER: Style}} the styles
   */
  private setupBGStyles(): { OUTER: Style; TICKS: Style; NUMS: Style } {
    let colourRGB = ColourRGB.colourToInstance(this.colourScheme.BACKGROUND);

    return {
      OUTER: Style.noStrokeFill(this.getOuterBGColour()),
      TICKS: Style.noStrokeFill(colourRGB.darken(10).toString()),
      NUMS: Style.noStrokeFill(colourRGB.toString())
    };
  }

  /**
   * Draws the main background concentric circles
   * @param {number} outerRadius - the radius of the outermost circle
   * @param {number} tickRadius - the radius at which ticks will be displayed at
   */
  protected drawMainBackground(outerRadius: number, tickRadius: number): void {
    let bgCircles = [
      new Circle(this.baseRadius, this.BG_COLOURS.OUTER, this.centre),
      new Circle(outerRadius, this.BG_COLOURS.TICKS, this.centre),
      new Circle(tickRadius, this.BG_COLOURS.NUMS, this.centre)
    ];
    let applyTransparency = this.colourScheme.isBackgroundTransparent();

    for (let bgCircle of bgCircles) {
      if (applyTransparency) Canvas.drawTransparency(ctx => bgCircle.draw(ctx), this.ctx);
      else bgCircle.draw(this.ctx);
    }
  }

  /**
   * Draws the glass arc in the bottom right-hand side of the background
   * @param {number} radius - the radius of the arc
   */
  protected drawGlass(radius: number): void {
    const RANGE = new NumberRange(1.85 * Math.PI, 0.45 * Math.PI);
    const COLOUR = this.lightColour === "#000" ? "rgba(255,255,255,0.25)" : this.lightColour;
    const STYLE = Style.noStrokeFill(COLOUR);

    let glassArc = new Arc(radius, RANGE, STYLE, this.centre);
    Canvas.drawTransparency(ctx => glassArc.draw(ctx), this.ctx);
  }

  /**
   * Draws the inner divider that separates the gauge arc and the inner part of the app
   * @param {number} radius - the radius of the divider
   * @param {number} width - the width of the divider
   */
  protected drawInnerDivider(radius: number, width: number): void {
    // Add a little bit of padding so the pointer base does not extend past it
    const RANGE = FUSION_THEME.MAIN_ANGLE_RANGE.clone();
    RANGE.pad(0.1);

    // Draw the inner arc that mirrors the angle of the RPM's arc
    const STYLE = new Style(this.colourScheme.BASE, width);
    new Arc(radius, RANGE, STYLE, this.centre).draw(this.ctx);

    // Draw the remaining part to finish the circle to add an element of 3D
    const STYLE2 = new Style("black", width);
    new Arc(radius, RANGE.invert(), STYLE2, this.centre).draw(this.ctx);
  }
}