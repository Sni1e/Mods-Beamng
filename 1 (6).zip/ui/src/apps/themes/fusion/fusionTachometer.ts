import { AbstractTachometerApp } from "../../abstractTachometerApp";
import { FUSION_THEME, FusionBackground, FusionThemeHelper } from "./fusion";
import { LinearGradient } from "../../../styles/gradients/linearGradient";
import { Vector } from "../../../maths/vector";
import { Font } from "../../../text/font";
import { ArrowShifterGearBuilder } from "../../../gauges/components/builders/gear/arrowShifterGearBuilder";
import { Text } from "../../../text/text";
import { ArrowIndicatorsBuilder } from "../../../gauges/components/builders/indicators/arrowIndicatorsBuilder";
import { NumberRange } from "../../../maths/numberRange";
import { TextParkingBrakeBuilder } from "../../../gauges/components/builders/textParkingBrakeBuilder";
import { AbstractUnitisedBuilder } from "../../../gauges/components/builders/unitised/abstractUnitisedBuilder";
import { ColourScheme } from "../../../colours/colourScheme";
import { AbstractRPMGaugeBuilder } from "../../../gauges/components/builders/fullGauge/abstractRPMGaugeBuilder";
import { DualColourArcTicks } from "../../../gauges/dataDisplayers/arcTicks/dualColourArcTicks";
import { ColourPriority } from "../../../colours/colourPriority";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { UniPointer } from "../../../gauges/dataDisplayers/pointers/uniPointer";
import { Quantity } from "../../../maths/units/quantity";
import { UnitConversion } from "../../../maths/units/unitConversion";
import { MinLengthFormatter } from "../../../formatting/minLengthFormatter";
import {
  PairedBarCollectionBuilder
} from "../../../gauges/components/builders/barCollection/pairedBarCollectionBuilder";
import { HasColourScheme } from "../../../mixins/builders/hasColourScheme";
import { applyMixins } from "../../../mixins/multiInherit";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";
import { TextParkingBrakeComponent } from "../../../gauges/components/textParkingBrakeComponent";
import { IndicatorsComponent } from "../../../gauges/components/indicatorsComponent";
import { GearComponent } from "../../../gauges/components/gearComponent";
import { AbstractGradient } from "../../../styles/gradients/abstractGradient";
import { Style } from "../../../styles/style";
import { CanDraw } from "../../../mixins/builders/canDraw";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Fusion Tachometer App Class //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the fusion version of the tachometer app
 */
class FusionTachometerApp extends AbstractTachometerApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(FUSION_THEME, baseRadius, document, bngApi, FusionRPMGaugeBuilder, FusionTachometerBackground);
  }

  /**
   * Creates the gear gradient
   * @param {Vector} position - the position of the gear text
   * @param {number} fontSize - the font size of the gear text
   * @return {LinearGradient} the gradient
   */
  private static createGearGradient(position: Vector, fontSize: number): LinearGradient {
    return new LinearGradient(
      position,
      Vector.sub(position, new Vector(0, fontSize)),
      AbstractGradient.distributeEvenly(["#888888", "white"])
    );
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getLightColour(lightState: number): string {
    switch (lightState) {
      case 0:
        return "rgba(255, 255, 255, 0.25)";
      case 1:
        return "rgba(0, 255, 0, 0.5)";
      case 2:
        return "rgba(0, 0, 255, 0.5)";
    }
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createGearComponent(): GearComponent {
    const FONTSIZE = 40;
    const TEXT_POS = Vector.add(this.centre, new Vector(20, 45));
    const SHIFTER_POS = Vector.add(this.centre, new Vector(13, 25));

    const FONT = new Font(this.theme.FONT_NAME, FONTSIZE, false);
    const STYLE = Style.noStrokeFill(
      FusionTachometerApp.createGearGradient(TEXT_POS, FONTSIZE).createGradient(this.canvas.get2DContext())
    );

    return this.setDefaultBuilderValues(ArrowShifterGearBuilder)
      .setText(new Text(FONT, "", TEXT_POS, STYLE))
      .setShifterPosition(SHIFTER_POS)
      .setShifterStyle(STYLE)
      .setArrowScale(1.25)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createIndicatorsComponent(): IndicatorsComponent {
    return new ArrowIndicatorsBuilder()
      .setCentre(Vector.add(this.centre, new Vector(-30, 20)))
      .setDistance(10)
      .setScale(1.7)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createBarCollectionBuilder(): PairedBarCollectionBuilder {
    return new PairedBarCollectionBuilder()
      .setCentre(this.centre)
      .setInnerRadius(130)
      .setOuterRadius(140)
      .setArcWidth(6)
      .setTempFuelArcRange(new NumberRange(Math.PI * 2.20, Math.PI * 2.45))
      .setThottleBrakeArcRange(new NumberRange(Math.PI * 1.85, Math.PI * 2.10))
      .setCapStyle("round")
      .setInvertArcDirections(true);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPBrakeComponent(): TextParkingBrakeComponent {
    return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
      .setCentre(Vector.add(this.centre, new Vector(-31, 55)))
      .setFont(new Font(this.theme.FONT_NAME, 16, true))
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createSpeedoComponent(): UnitisedComponent {
    return this.setDefaultBuilderValues(FusionSpeedometer)
      .setQuantity(this.getQuantityInstance())
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getNewUnitInstance(): Quantity {
    let unit = new UnitConversion(Quantity.speed());
    let formatter = new MinLengthFormatter(3);
    return new Quantity(unit, formatter);
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

class FusionSpeedometer extends AbstractUnitisedBuilder {
  /**
   * @constructor
   * Sets font name to {@link FUSION_THEME}'s FONT_NAME
   */
  constructor() {
    super();
    this.setFontName(FUSION_THEME.FONT_NAME);
  }

  /**
   * Returns the styling for a component piece of the text
   * @param {Vector} basePos - the position the text object will sit at
   * @param {number} fontSize - the size of the font that will be used
   * @return {Style} the style created
   */
  private getStyle(basePos: Vector, fontSize: number): Style {
    let padding = new Vector(0, fontSize / 2);

    return Style.noStrokeFill(
      new LinearGradient(
        Vector.sub(basePos, padding),
        Vector.add(basePos, padding),
        AbstractGradient.distributeEvenly(["white", this.colourScheme.UNIT])
      ).createGradient(this.ctx)
    );
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createText(fontSize: number, pos: Vector): Text {
    let font = new Font(this.fontName, fontSize, true);
    return new Text(font, "", pos, this.getStyle(pos, fontSize));
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createUnitText(): Text {
    const POS = Vector.add(this.centre, new Vector(52, -18));
    return this.createText(18, POS);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createValueText(): Text {
    const POS = Vector.add(this.centre, new Vector(-15, -25));
    return this.createText(46, POS);
  }
}
interface FusionSpeedometer extends HasColourScheme, CanDraw {}
applyMixins(FusionSpeedometer, [HasColourScheme, CanDraw]);

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents a builder class for creating the velocity version of the RPM component
 */
class FusionRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
  private static readonly BASERADIUS = 150;
  // The inner radius of the RPM arc
  private static readonly INNER_RPM_RADIUS = 134;

  /**
   * @constructor
   * Sets arc range to {@link FusionThemeHelper.MAIN_ANGLE_RANGE}
   */
  constructor() {
    super();
    this.setArcRange(FUSION_THEME.MAIN_ANGLE_RANGE);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTicks(): DualColourArcTicks {
    // The RPM spacing between two ticks
    const TICK_SPACING = 100;

    // The number of ticks
    const NUM_TICKS = Math.floor(this.engine.getRedLineRPM() / TICK_SPACING) + 1;
    // The number of ticks between one major tick and another
    const MAJOR_TICK_SPACING = 1000 / TICK_SPACING;

    let ticks = new DualColourArcTicks(
      this.centre,
      FusionRPMGaugeBuilder.INNER_RPM_RADIUS,
      NUM_TICKS,
      this.arcRange,
      new ColourPriority(this.colourScheme.TICKS.getSecondary(), "red"),
      this.engine.getRedlineRPMRatio()
    );
    ticks.setTickWidth(2);
    ticks.setTickLength(10);
    ticks.setMajorSpacing(MAJOR_TICK_SPACING);
    return ticks;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createNumbering(): ArcNumbering {
    return this.createBasicNumbering(110, 18);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPointer(): UniPointer {
    return FusionThemeHelper.createPointer(
      this.centre,
      this.createValueRange(),
      FusionRPMGaugeBuilder.INNER_RPM_RADIUS,
      88,
      FusionRPMGaugeBuilder.BASERADIUS,
      this.ctx
    );
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createArcBar(): null {
    return null;
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background of the unknown tachometer app.
 * Responsible for drawing the necessary background elements
 */
class FusionTachometerBackground extends FusionBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} radius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(ctx: CanvasRenderingContext2D, centre: Vector, radius: number, colourScheme: ColourScheme) {
    super(ctx, centre, radius, colourScheme);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();

    // The inner radius at which the ticks are place at
    const TICKRADIUS = 120;

    this.drawMainBackground(144, TICKRADIUS);
    this.drawGlass(TICKRADIUS);
    this.drawInnerDivider(90, 8);
  }
}
