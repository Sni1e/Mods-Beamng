import { AbstractBoostApp } from "../../abstractBoostApp";
import { FUSION_THEME, FusionBackground, FusionThemeHelper } from "./fusion";
import { Vector } from "../../../maths/vector";
import { ColourScheme } from "../../../colours/colourScheme";
import { AbstractPressureGaugeBuilder } from "../../../gauges/components/builders/fullGauge/abstractPressureGaugeBuilder";
import { ArcTicks } from "../../../gauges/dataDisplayers/arcTicks/arcTicks";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { UniPointer } from "../../../gauges/dataDisplayers/pointers/uniPointer";
import { StackedUnitisedBuilder } from "../../../gauges/components/builders/unitised/stackedUnitisedBuilder";
import { LinearGradient } from "../../../styles/gradients/linearGradient";
import { applyMixins } from "../../../mixins/multiInherit";
import { HasColourScheme } from "../../../mixins/builders/hasColourScheme";
import { HasRadius } from "../../../mixins/builders/hasRadius";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";
import { AbstractGradient } from "../../../styles/gradients/abstractGradient";
import { Style } from "../../../styles/style";
import { CanDraw } from "../../../mixins/builders/canDraw";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Fusion Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the fusion version of the boost app
 */
export class FusionBoostApp extends AbstractBoostApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(FUSION_THEME, baseRadius, document, bngApi, FusionPressureGaugeBuilder, FusionBoostBackground);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPressureReadout(): UnitisedComponent {
    return this.setDefaultBuilderValues(FusionStackedUnitisedBuilder)
      .setQuantity(this.getQuantityInstance())
      .build();
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

class FusionPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
  private static OUTER_TICK_BASE_RADIUS = 65;

  /**
   * @override
   * @inheritDoc
   */
  protected createTicks(): ArcTicks {
    let ticks = new ArcTicks(
      this.centre,
      FusionPressureGaugeBuilder.OUTER_TICK_BASE_RADIUS,
      41,
      FUSION_THEME.MAIN_ANGLE_RANGE
    );
    ticks.setTickLength(6);
    ticks.setTickWidth(2);
    ticks.setMajorSpacing(10);
    ticks.setTickColour(this.colourScheme.TICKS.getSecondary());
    return ticks;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createArcBar(): null {
    return null;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createNumbering(): ArcNumbering {
    // The font size for the numbering; decrease as number of digits to display increases
    const FONTSIZE = 10 - Math.floor(this.maxBoostConverted).toString().length;
    return this.createBasicNumbering(50, FONTSIZE, 5, FUSION_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPointer(): UniPointer {
    return FusionThemeHelper.createPointer(
      this.centre,
      this.createValueRange(),
      FusionPressureGaugeBuilder.OUTER_TICK_BASE_RADIUS,
      38,
      this.radius,
      this.ctx
    );
  }
}
interface FusionPressureGaugeBuilder extends HasColourScheme, HasRadius {}
applyMixins(FusionPressureGaugeBuilder, [HasColourScheme, HasRadius]);

class FusionStackedUnitisedBuilder extends StackedUnitisedBuilder {
  /**
   * @constructor
   * Sets the value font size to 16.
   * Sets the unit font size to 12.
   * Sets the padding to 10
   */
  constructor() {
    super();
    this.setValueFontSize(16);
    this.setUnitFontSize(12);
    this.setPadding(10)
  }

  /**
   * Returns the gradient style for a text element
   * @param {Vector} position - the position the text element will be placed at
   * @param {number} fontSize - the size of the font which will be used to render the text
   * @return {Style} the style object
   */
  private getGradient(position: Vector, fontSize: number): Style {
    return Style.noStrokeFill(
      new LinearGradient(
        Vector.add(position, new Vector(0, -fontSize / 2)),
        Vector.add(position, new Vector(0, fontSize / 2)),
        AbstractGradient.distributeEvenly(["white", this.colourScheme.UNIT])
      ).createGradient(this.ctx)
    );
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getUnitStyle(): Style {
    return this.getGradient(this.getPosition(false), this.unitFontSize);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected getValueStyle(): Style {
    return this.getGradient(this.getPosition(true), this.valueFontSize);
  }
}
interface FusionStackedUnitisedBuilder extends CanDraw {}
applyMixins(FusionStackedUnitisedBuilder, [CanDraw]);

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background elements that can be drawn to the background canvas for the fusion
 * version of the boost app
 */
class FusionBoostBackground extends FusionBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(ctx: CanvasRenderingContext2D, centre: Vector, baseRadius: number, colourScheme: ColourScheme) {
    super(ctx, centre, baseRadius, colourScheme);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();
    this.drawMainBackground(72, 60);
    this.drawGlass(60);
    this.drawInnerDivider(39, 5);
  }
}
