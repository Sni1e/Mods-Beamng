import { AbstractTachometerApp } from "../../abstractTachometerApp";
import { VelocityBackground, VELOCITY_THEME } from "./velocity";
import { Vector } from "../../../maths/vector";
import { RingShifterGearBuilder } from "../../../gauges/components/builders/gear/ringShifterGearBuilder";
import { Font } from "../../../text/font";
import { ArrowIndicatorsBuilder } from "../../../gauges/components/builders/indicators/arrowIndicatorsBuilder";
import { NumberRange } from "../../../maths/numberRange";
import { TextParkingBrakeBuilder } from "../../../gauges/components/builders/textParkingBrakeBuilder";
import { StackedUnitisedBuilder } from "../../../gauges/components/builders/unitised/stackedUnitisedBuilder";
import { AbstractRPMGaugeBuilder } from "../../../gauges/components/builders/fullGauge/abstractRPMGaugeBuilder";
import { ColourScheme } from "../../../colours/colourScheme";
import { LimitedArcBarDisplayer } from "../../../gauges/dataDisplayers/limitedArcBarDisplayer";
import { ArcBar } from "../../../shapes/arcBar";
import { Style } from "../../../styles/style";
import { AccentPointer } from "../../../gauges/dataDisplayers/pointers/accentPointer";
import { Arc } from "../../../shapes/arc";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { CamoArcTicks } from "../../../gauges/dataDisplayers/arcTicks/camoArcTicks";
import { RoundCornerRectangleBR } from "../../../shapes/roundCornerRectangleBR";
import { Canvas } from "../../../canvas";
import { AccentTriangleBuilder } from "../../../utils/pointers/accentTriangleBuilder";
import {
  PairedBarCollectionBuilder
} from "../../../gauges/components/builders/barCollection/pairedBarCollectionBuilder";
import { GearComponent } from "../../../gauges/components/gearComponent";
import { IndicatorsComponent } from "../../../gauges/components/indicatorsComponent";
import { TextParkingBrakeComponent } from "../../../gauges/components/textParkingBrakeComponent";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Velocity Tachometer App Class  //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the velocity version of the tachometer app
 */
class VelocityTachometerApp extends AbstractTachometerApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(VELOCITY_THEME, baseRadius, document, bngApi, VelocityRPMGaugeBuilder, VelocityTachometerBackground);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createGearComponent(): GearComponent {
    return this.setDefaultBuilderValues(RingShifterGearBuilder)
      .setFont(new Font(this.theme.FONT_NAME, 34, true))
      .setRingRadius(30)
      .setRingWidth(6)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createIndicatorsComponent(): IndicatorsComponent {
    return new ArrowIndicatorsBuilder()
      .setCentre(Vector.add(this.centre, new Vector(80, 74)))
      .setDistance(60)
      .setScale(1.5)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createBarCollectionBuilder(): PairedBarCollectionBuilder {
    return new PairedBarCollectionBuilder()
      .setCentre(this.centre)
      .setInnerRadius(65)
      .setOuterRadius(75)
      .setArcWidth(6)
      .setTempFuelArcRange(new NumberRange(Math.PI * 0.5, Math.PI * 1.15))
      .setThottleBrakeArcRange(new NumberRange(Math.PI * 1.35, Math.PI * 2))
      .setInvertArcDirections(false);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPBrakeComponent(): TextParkingBrakeComponent {
    return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
      .setCentre(Vector.add(this.centre, new Vector(60, 115)))
      .setFont(new Font(this.theme.FONT_NAME, 16, true))
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createSpeedoComponent(): UnitisedComponent {
    return this.setDefaultBuilderValues(StackedUnitisedBuilder)
      .setCentre(Vector.add(this.centre, new Vector(80, 62)))
      .setValueFontSize(40)
      .setUnitFontSize(16)
      .setQuantity(this.getQuantityInstance())
      .setPadding(12)
      .build();
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents a builder class for creating the velocity version of the RPM component
 */
export class VelocityRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
  // The inner radius of the RPM arc
  private static readonly INNER_RPM_RADIUS = 135;

  /**
   * @constructor
   * Sets arc range to {@link VELOCITY_THEME.MAIN_ANGLE_RANGE}
   */
  constructor() {
    super();
    this.setArcRange(VELOCITY_THEME.MAIN_ANGLE_RANGE);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTicks(): CamoArcTicks {
    // The RPM spacing between two ticks
    const TICKSPACING = 250;
    let numTicks = Math.floor(this.engine.getRedLineRPM() / TICKSPACING) + 1;

    let ticks = new CamoArcTicks(
      this.centre,
      VelocityRPMGaugeBuilder.INNER_RPM_RADIUS,
      numTicks,
      this.arcRange,
      this.colourScheme.TICKS
    );
    ticks.setTickWidth(2);
    ticks.setTickLength(15);
    return ticks;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createNumbering(): ArcNumbering {
    return this.createBasicNumbering(100, 20);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPointer(): AccentPointer {
    const COLOUR = this.colourScheme.POINTER;

    let colours = {
      main: COLOUR.getSecondary(),
      accent: COLOUR.getPrimary(),
      dial: COLOUR.getSecondary()
    };

    return new AccentTriangleBuilder()
      .setCentre(this.centre)
      .setWidth(38)
      .setLength(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS)
      .setValueRange(this.createValueRange())
      .setPointerRange(this.arcRange)
      .setColours(colours)
      .setMinorScale(0.5)
      .setAccentScale(0.35)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createArcBar(): LimitedArcBarDisplayer {
    // The width of the arc bar
    const ARC_BAR_WIDTH = 30;
    const COLOURS = this.colourScheme.ARC_BAR;

    let mainBarStyle = new Style(COLOURS.getPrimary(), ARC_BAR_WIDTH);
    let limitBarStyle = new Style("#FF0000", ARC_BAR_WIDTH);
    let backgroundStyle = new Style(COLOURS.getSecondary(), ARC_BAR_WIDTH, false);

    let mainBar = new ArcBar(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS, this.arcRange, mainBarStyle, backgroundStyle,this.centre);
    let limitBar = new ArcBar(VelocityRPMGaugeBuilder.INNER_RPM_RADIUS, this.createRedlineRange(), limitBarStyle, backgroundStyle, this.centre);

    return new LimitedArcBarDisplayer(this.createValueRange(), mainBar, limitBar);
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background of the velocity tachometer app.
 * Responsible for drawing the necessary background elements
 */
class VelocityTachometerBackground extends VelocityBackground {
  // The bottom right backgrounds' leftmost x coordinate for rounded rectangles
  private static readonly BRLEFTX = 173;

  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} radius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(ctx: CanvasRenderingContext2D, centre: Vector, radius: number, colourScheme: ColourScheme) {
    super(ctx, centre, radius, colourScheme);
  }

  /**
   * Draws the background to the temperature and oil bars
   */
  private drawBarCollection(): void {
    const WIDTH = 25;
    const RADIUS = 70;
    const RANGESTART = new NumberRange(Math.PI * 0.5, Math.PI * 1.15);
    const RANGEEND = new NumberRange(Math.PI * 1.35, Math.PI * 2);

    // Draw the background to the arc bars on the start side
    let style = new Style("black", WIDTH);
    new Arc(RADIUS, RANGESTART, style, this.centre).draw(this.ctx);

    // Draw the background to the arc bars on the end side
    let style2 = new Style("black", WIDTH);
    new Arc(RADIUS, RANGEEND, style2, this.centre).draw(this.ctx);
  }

  /**
   * Applies lighting, skewed to the top left corner
   */
  private applyLights(): void {
    this.ctx.filter = "drop-shadow(-8px -8px 8px " + this.lightColour + ")";
  }

  /**
   * Draws the background to the speedometer
   */
  private drawSpeedo(): void {
    let range = new NumberRange(Math.PI * 0.05, Math.PI * 0.21);

    // Don't apply everything yet as lighting may need to be done
    this.ctx.beginPath();
    new RoundCornerRectangleBR(
      this.baseRadius,
      range,
      this.centre,
      VelocityTachometerBackground.BRLEFTX,
      null
    ).drawContinue(this.ctx);
    this.ctx.lineWidth = 1;
    this.ctx.fillStyle = "black";

    // Apply lighting if necessary
    if (this.lightColour !== "#000") {
      this.applyLights();
      this.ctx.fill();
      Canvas.resetFilter(this.ctx);
    } else {
      this.ctx.fill();
    }

    Canvas.resetTransformationState(this.ctx);
  }

  /**
   * Draws the background to the parking brake
   */
  private drawPBrake(): void {
    let range = new NumberRange(Math.PI * 0.23, Math.PI * 0.32);
    let style = Style.noStrokeFill("black");

    new RoundCornerRectangleBR(this.baseRadius, range, this.centre, VelocityTachometerBackground.BRLEFTX, style).draw(
      this.ctx
    );
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();
    this.drawMainBackground(70);
    this.drawInnerGlass(81);
    this.drawBarCollection();
    this.drawInnerDivider(10, 85);
    this.drawSpeedo();
    this.drawPBrake();
  }
}
