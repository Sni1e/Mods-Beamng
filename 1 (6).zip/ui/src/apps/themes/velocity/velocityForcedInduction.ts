import { AbstractBoostApp } from "../../abstractBoostApp";
import { VELOCITY_THEME, VelocityBackground } from "./velocity";
import { StackedUnitisedBuilder } from "../../../gauges/components/builders/unitised/stackedUnitisedBuilder";
import { Vector } from "../../../maths/vector";
import { AbstractPressureGaugeBuilder } from "../../../gauges/components/builders/fullGauge/abstractPressureGaugeBuilder";
import { NumberRange } from "../../../maths/numberRange";
import { CamoArcTicks } from "../../../gauges/dataDisplayers/arcTicks/camoArcTicks";
import { Style } from "../../../styles/style";
import { ArcBarDisplayer } from "../../../gauges/dataDisplayers/arcBarDisplayer";
import { RoundCornerRectangleBR } from "../../../shapes/roundCornerRectangleBR";
import { ColourScheme } from "../../../colours/colourScheme";
import { AccentPointer } from "../../../gauges/dataDisplayers/pointers/accentPointer";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { AccentTriangleBuilder } from "../../../utils/pointers/accentTriangleBuilder";
import { HasColourScheme } from "../../../mixins/builders/hasColourScheme";
import { applyMixins } from "../../../mixins/multiInherit";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";
import { ArcBar } from "../../../shapes/arcBar";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Velocity Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the velocity version of the boost app
 */
class VelocityBoostApp extends AbstractBoostApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(VELOCITY_THEME, baseRadius, document, bngApi, VelocityPressureGaugeBuilder, VelocityBoostBackground);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPressureReadout(): UnitisedComponent {
    return this.setDefaultBuilderValues(StackedUnitisedBuilder)
      .setCentre(Vector.add(this.centre, new Vector(40, 38)))
      .setQuantity(this.getQuantityInstance())
      .setValueFontSize(16)
      .setUnitFontSize(8)
      .setPadding(8)
      .build();
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents a builder class for creating the velocity version of the pressure gauge component
 */
class VelocityPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
  private static readonly RADIUS = 65;

  /**
   * @override
   * @inheritDoc
   */
  protected createTicks(): CamoArcTicks {
    let ticks = new CamoArcTicks(
      this.centre,
      VelocityPressureGaugeBuilder.RADIUS,
      17,
      VELOCITY_THEME.MAIN_ANGLE_RANGE,
      this.colourScheme.TICKS
    );
    ticks.setTickWidth(2);
    ticks.setTickLength(10);
    return ticks;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createNumbering(): ArcNumbering {
    // The font size for the numbering; decrease as number of digits to display increases
    const FONTSIZE = 12 - Math.floor(this.maxBoostConverted).toString().length;
    return this.createBasicNumbering(45, FONTSIZE, 5, VELOCITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPointer(): AccentPointer {
    const COLOUR = this.colourScheme.POINTER;

    let colours = {
      main: COLOUR.getSecondary(),
      accent: COLOUR.getPrimary(),
      dial: COLOUR.getSecondary()
    };

    return new AccentTriangleBuilder()
      .setCentre(this.centre)
      .setWidth(16)
      .setLength(VelocityPressureGaugeBuilder.RADIUS)
      .setValueRange(this.createValueRange())
      .setPointerRange(VELOCITY_THEME.MAIN_ANGLE_RANGE)
      .setColours(colours)
      .setMinorScale(0.5)
      .setAccentScale(0.35)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createArcBar(): ArcBarDisplayer {
    let style = new Style(this.colourScheme.ARC_BAR.getPrimary(), 20);
    let bgStyle = new Style(this.colourScheme.ARC_BAR.getSecondary(), 20);

    let arcBar = new ArcBar(VelocityPressureGaugeBuilder.RADIUS, VELOCITY_THEME.MAIN_ANGLE_RANGE, style, bgStyle, this.centre);
    return new ArcBarDisplayer(this.createValueRange(), arcBar);
  }
}
interface VelocityPressureGaugeBuilder extends HasColourScheme {}
applyMixins(VelocityPressureGaugeBuilder, [HasColourScheme]);

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background elements that can be drawn to the background canvas for the velocity
 * version of the boost app
 */
class VelocityBoostBackground extends VelocityBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} radius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(ctx: CanvasRenderingContext2D, centre: Vector, radius: number, colourScheme: ColourScheme) {
    super(ctx, centre, radius, colourScheme);
  }

  /**
   * Draws the background to the parking brake
   */
  private drawUnit(): void {
    const LEFTX = this.centre.x() + 16;
    const RANGE = new NumberRange(Math.PI * 0.08, Math.PI * 0.24);
    const STYLE = Style.noStrokeFill("black");

    new RoundCornerRectangleBR(this.baseRadius, RANGE, this.centre, LEFTX, STYLE).draw(this.ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();
    this.drawMainBackground(45);
    this.drawInnerDivider(4, 32);
    this.drawInnerGlass(31);
    this.drawUnit();
  }
}
