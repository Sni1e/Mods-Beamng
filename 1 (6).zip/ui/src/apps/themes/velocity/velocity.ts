import { NumberRange } from "../../../maths/numberRange";
import { AbstractBackground } from "../../abstractBackground";
import { Vector } from "../../../maths/vector";
import { ColourScheme } from "../../../colours/colourScheme";
import { Style } from "../../../styles/style";
import { Arc } from "../../../shapes/arc";
import { Circle } from "../../../shapes/circle";
import { Canvas } from "../../../canvas";
import { Wedge } from "../../../shapes/wedge";
import { Theme } from "../theme";

export const VELOCITY_THEME = new Theme("Arial Black", new NumberRange(0.5 * Math.PI, 2 * Math.PI), "V");

/**
 * Represents the velocity theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
export class VelocityBackground extends AbstractBackground {
  static readonly BASE_RANGE = VELOCITY_THEME.MAIN_ANGLE_RANGE;

  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(
    ctx: CanvasRenderingContext2D,
    centre: Vector,
    baseRadius: number,
    colourScheme: ColourScheme
  ) {
    super(ctx, centre, baseRadius, colourScheme);
  }

  /**
   * Draws the dividing arc between the gauge arc and the inner part of the app
   * @param {number} width - the width of the arc
   * @param {number} radius - the radius of the arc
   */
  protected drawInnerDivider(width: number, radius: number): void {
    // Draw the dividing line between the inner RPM numbers
    let style = new Style("black", width);
    new Arc(radius, VELOCITY_THEME.MAIN_ANGLE_RANGE, style, this.centre).draw(this.ctx);
  }

  /**
   * Draws the main background circle, which is hollow to allow for transparency when drawing the
   * inner glass piece
   * @param {number} width - the width of the circle
   */
  protected drawMainBackground(width: number): void {
    let BG_RADIUS = this.baseRadius - width / 2;

    // Draw as a hollow circle to allow the centre to show transparency
    let style = new Style(this.colourScheme.BACKGROUND, width);
    new Circle(BG_RADIUS, style, this.centre).draw(this.ctx);
  }

  /**
   * Draws the inner glass piece. This glass piece is inside the main part of the gauge and is a
   * complete circle, comprised of a transparent piece and an opaque piece. The coverage of the
   * former is determined by {@see VELOCITY_THEME.MAIN_ANGLE_RANGE} and the latter determined by the
   * remainder of the circle left
   * @param {number} radius - the radius of the glass piece
   * */
  protected drawInnerGlass(radius: number): void {
    // Draw the glass
    let glass = new Wedge(
      radius,
      VelocityBackground.BASE_RANGE,
      Style.noStrokeFill(this.colourScheme.GLASS),
      this.centre
    );
    Canvas.drawTransparency(ctx => glass.draw(ctx), this.ctx);

    // Slight overlapping caused by transparency here; manual fix to prevent imperfection
    if (this.colourScheme.isBackgroundTransparent()) radius -= 1;
    // Fill in the other part not filled in with the background colour;
    new Wedge(
      radius,
      VelocityBackground.BASE_RANGE.invert(),
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      this.centre
    ).draw(this.ctx);
  }
}