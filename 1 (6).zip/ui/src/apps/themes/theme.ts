import { NumberRange } from "../../maths/numberRange";

/**
 * Represents a theme for all apps to use for global styling and helper methods
 */
export class Theme {
  /**
   * @constructor
   * @param {string} FONT_NAME - the name of the font associated with this theme
   * @param {NumberRange} mainAngleRange - the main range of angles to style components towards
   * @param {string} BASE_ID - the unique identifier that forms the basis of this theme's app's ids
   */
  constructor(
    public readonly FONT_NAME: string,
    protected readonly mainAngleRange: NumberRange,
    public readonly BASE_ID: string
  ) {}

  public get MAIN_ANGLE_RANGE(): NumberRange {
    return this.mainAngleRange.clone();
  }
}