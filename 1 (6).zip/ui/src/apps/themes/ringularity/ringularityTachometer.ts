import { RINGULARITY_THEME, RingularityBackground, RingularityThemeHelper } from "./ringularity";
import { GearComponent } from "../../../gauges/components/gearComponent";
import { IndicatorsComponent } from "../../../gauges/components/indicatorsComponent";
import { TextParkingBrakeComponent } from "../../../gauges/components/textParkingBrakeComponent";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";
import { AbstractRPMGaugeBuilder } from "../../../gauges/components/builders/fullGauge/abstractRPMGaugeBuilder";
import { LimitedArcBarDisplayer } from "../../../gauges/dataDisplayers/limitedArcBarDisplayer";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { AbstractGaugePointer } from "../../../gauges/dataDisplayers/pointers/abstractGaugePointer";
import { ArcTicks } from "../../../gauges/dataDisplayers/arcTicks/arcTicks";
import { ArcBar } from "../../../shapes/arcBar";
import { Vector } from "../../../maths/vector";
import { ColourScheme } from "../../../colours/colourScheme";
import { Style } from "../../../styles/style";
import { Font } from "../../../text/font";
import { RectangleShifterGearBuilder } from "../../../gauges/components/builders/gear/rectangleShifterGearBuilder";
import { Rectangle } from "../../../shapes/rectangle";
import { NumberRange } from "../../../maths/numberRange";
import {
  PairedBarCollectionBuilder
} from "../../../gauges/components/builders/barCollection/pairedBarCollectionBuilder";
import { FloatingUnitisedBuilder } from "../../../gauges/components/builders/unitised/floatingUnitisedBuilder";
import { TextParkingBrakeBuilder } from "../../../gauges/components/builders/textParkingBrakeBuilder";
import { LineIndicatorsBuilder } from "../../../gauges/components/builders/indicators/lineIndicatorsBuilder";
import { AbstractTachometerApp } from "../../abstractTachometerApp";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Ringularity Tachometer App Class //                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the Ringularity version of the tachometer app
 */
export class RingularityTachometerApp extends AbstractTachometerApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(RINGULARITY_THEME, baseRadius, document, bngApi, RingularityRPMGaugeBuilder, RingularityTachometerBackground);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createGearComponent(): GearComponent {
    const BG_STYLE = new Style("#666", 3);
    const TEXT_CENTRE = Vector.add(this.centre, new Vector(-26, 30));
    const WIDTH = 44;
    const HEIGHT = 56;

    return this.setDefaultBuilderValues(RectangleShifterGearBuilder)
      .setCentre(TEXT_CENTRE)
      .setFont(new Font(this.theme.FONT_NAME, 34, true))
      .setTextStyle(new Style(this.colourScheme.GEAR.getPrimary(), 4, true))
      .setRectangle(new Rectangle(WIDTH, HEIGHT, BG_STYLE, Vector.sub(TEXT_CENTRE, new Vector(WIDTH / 2, HEIGHT / 2))))
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createIndicatorsComponent(): IndicatorsComponent {
    return this.setDefaultBuilderValues(LineIndicatorsBuilder)
      .setUnlitStyle(new Style("black", 5))
      .setDistance(110)
      .setYCoordinates(3, 58)
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createBarCollectionBuilder(): PairedBarCollectionBuilder {
    return new PairedBarCollectionBuilder()
      .setCentre(this.centre)
      .setInnerRadius(107)
      .setOuterRadius(123)
      .setArcWidth(10)
      .setTempFuelArcRange(new NumberRange(2.315 * Math.PI, 2.475 * Math.PI))
      .setThottleBrakeArcRange(new NumberRange(2.025 * Math.PI, 2.185 * Math.PI))
      .setInvertArcDirections(true)
      .setCapStyle('butt');
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPBrakeComponent(): TextParkingBrakeComponent {
    return this.setDefaultBuilderValues(TextParkingBrakeBuilder)
      .setCentre(Vector.add(this.centre, new Vector(25, 47)))
      .setFont(new Font(RINGULARITY_THEME.FONT_NAME, 14, true))
      .build();
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createSpeedoComponent(): UnitisedComponent {
    return this.setDefaultBuilderValues(FloatingUnitisedBuilder)
      .setUnitFontSize(18)
      .setValueFontSize(44)
      .setValuePosition(Vector.add(this.centre, new Vector(0, -28)))
      .setUnitPosition(Vector.add(this.centre, new Vector(26, 15)))
      .setQuantity(this.getQuantityInstance())
      .build();
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

class RingularityRPMGaugeBuilder extends AbstractRPMGaugeBuilder {
  // The inner radius of the RPM arc
  public static readonly INNER_RPM_RADIUS = 116;

  /**
   * @constructor
   * Sets arc range to {@link RINGULARITY_THEME.MAIN_ANGLE_RANGE}
   */
  constructor() {
    super();
    this.setArcRange(RINGULARITY_THEME.MAIN_ANGLE_RANGE);
  }

  /**
   * Creates and returns a Style object for the arc bar with a gradient from the given colours
   * @param {string[]} colours - the colours to use for the gradient
   * @returns {Style} the gradient style created
   * @private
   */
  private getGradientStyle(colours: string[]): Style {
    return RingularityThemeHelper.getGradientStyle(colours, RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.centre, 43, this.ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createArcBar(): LimitedArcBarDisplayer {
    let mainStyle = this.getGradientStyle(RingularityThemeHelper.getArcbarColourPair(this.colourScheme));
    let limitStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(255, 0, 0)"));
    let backgroundStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(40, 40, 40)"));

    let mainArcBar = new ArcBar(RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.arcRange.clone(), mainStyle, backgroundStyle,this.centre);
    let limitArcBar = new ArcBar(RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, this.createRedlineRange(), limitStyle, backgroundStyle, this.centre);

    return new LimitedArcBarDisplayer(this.createValueRange(), mainArcBar, limitArcBar);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createNumbering(): ArcNumbering {
    return this.createBasicNumbering(105, 18, false);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createPointer(): AbstractGaugePointer {
    return null;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTicks(): ArcTicks {
    // The RPM spacing between two ticks
    const TICKSPACING = 250;
    let numTicks = Math.floor(this.engine.getRedLineRPM() / TICKSPACING) + 1;

    let ticks = new ArcTicks(
      this.centre,
      RingularityRPMGaugeBuilder.INNER_RPM_RADIUS + 11,
      numTicks,
      this.arcRange
    );
    ticks.setTickWidth(2);
    ticks.setTickLength(7);
    ticks.setDrawEndTicks(false);
    return ticks;
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background of the Ringularity tachometer app.
 * Responsible for drawing the necessary background elements
 */
class RingularityTachometerBackground extends RingularityBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(
    ctx: CanvasRenderingContext2D,
    centre: Vector,
    baseRadius: number,
    colourScheme: ColourScheme
  ) {
    super(ctx, centre, baseRadius, colourScheme);
  }

  /**
   * Draws the background rectangles for the speedometer value and unit
   * @private
   */
  private drawSpeedometer(): void {
    this.drawSpeedometerValue();

    // Speedometer unit
    new Rectangle(
      44,
      26,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.add(this.centre, new Vector(3, 2)),
      true
    ).draw(this.ctx);
  }

  /**
   * Draws the background rectangle for the speedometers value
   * @private
   */
  private drawSpeedometerValue(): void {
    let background = new Rectangle(
      116,
      48,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.add(this.centre, new Vector(-58, -54)),
      true
    );
    background.draw(this.ctx);

    if (this.lightColour !== "#000") {
      background
        .changeStyling(new Style(this.lightColour, 3))
        .draw(this.ctx);
    }
  }

  /**
   * Draws the background rectangle for the gear
   * @private
   */
  private drawGear(): void {
    const WIDTH = 44;
    const HEIGHT = 56;

    new Rectangle(
      WIDTH,
      HEIGHT,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.sub(Vector.add(this.centre, new Vector(-26, 30)), new Vector(WIDTH / 2, HEIGHT / 2))
    ).draw(this.ctx);
  }

  /**
   * Draws the background rectangle for the parking brake
   * @private
   */
  private drawParkingBrake(): void {
    new Rectangle(
      44,
      24,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.add(this.centre, new Vector(3, 34)),
      true
    ).draw(this.ctx);
  }

  public override draw(): void {
    super.draw();
    this.drawGlassInnerCircle(this.baseRadius);
    this.drawMainBackground(130, RingularityRPMGaugeBuilder.INNER_RPM_RADIUS, 60);
    this.drawSpeedometer();
    this.drawGear();
    this.drawParkingBrake();
    this.drawBottomRightArc(116, 44);
    this.drawGaugeArcStrokeLines(4, [88, 144]);
  }
}
