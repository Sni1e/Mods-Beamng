import { NumberRange } from "../../../maths/numberRange";
import { AbstractBackground } from "../../abstractBackground";
import { Theme } from "../theme";
import { Vector } from "../../../maths/vector";
import { ColourScheme } from "../../../colours/colourScheme";
import { ColourRGB } from "../../../colours/colourRGB";
import { ColourRGBA } from "../../../colours/colourRGBA";
import { getRemainingCircle } from "../../../utils/mathsUtils";
import { Arc } from "../../../shapes/arc";
import { Style } from "../../../styles/style";
import { Rectangle } from "../../../shapes/rectangle";
import { Circle } from "../../../shapes/circle";
import { RadialGradient } from "../../../styles/gradients/radialGradient";
import { AbstractGradient } from "../../../styles/gradients/abstractGradient";
import { Canvas } from "../../../canvas";

export const RINGULARITY_THEME = new Theme("AzeretMono-Black", new NumberRange(0.5 * Math.PI, 2 * Math.PI), "R");

export class RingularityThemeHelper {
  /**
   * Creates and returns a colour pair, from the given colour, as ColourRGB instances. The first colour is darkened to
   * 65%, and the second colour is equal to {@link colour}
   * @param {string} colour - the base colour to create a pair from
   * @returns {ColourRGB[]} the colour pair
   * @private
   */
  private static getColourPair(colour: string): ColourRGB[] {
    let colourInst = ColourRGB.colourToInstance(colour);
    return [colourInst.darkMulti(0.6), colourInst];
  }

  /**
   * Creates and returns a colour pair, from the given colour, as ColourRGB instances. The first colour is darkened to
   * 65%, and the second colour is equal to {@link colour}. Similar to {@link getColourPair}, but returns the colours
   * as strings instead
   * @param {string} colour - the base colour to create a pair from
   * @returns {string[]} the colour pair as strings
   * @private
   */
  public static getColourPairString(colour: string): string[] {
    return this.getColourPair(colour).map(c => c.toString());
  }

  /**
   * Creates and returns a colour pair, from the given colour. The first colour is darkened by 65%, and both have an
   * alpha of 0.6
   * @param {string} colour - the colour to use as a base
   * @returns {string[]} the colour pairs
   */
  public static getTransparentColourPair(colour: string): string[] {
    return this.getColourPair(colour).map(c => ColourRGBA.addAlpha(c, 0.6).toString());
  }

  /**
   * Creates and returns a colour pair, from the ARC_BAR colour of the given colour scheme.
   * See {@link getColourPairString} for details on the colours returned
   * @param {ColourScheme} colourScheme - the colour scheme to use the ARC_BAR property of
   * @returns {string[]} the colour pair created
   */
  public static getArcbarColourPair(colourScheme: ColourScheme): string[] {
    return RingularityThemeHelper.getColourPairString(colourScheme.ARC_BAR.getPrimary());
  }

  /**
   * Creates and returns a Style object for the arc bar with a gradient from the given colours
   * @param {string[]} colours - the colours to use for the gradient
   * @param {number} radius - the radius of the gradient's middle
   * @param {Vector} centre - the centre point of the gradient
   * @param {number} lineWidth - the width of the gradient (the full width will be double this)
   * @param {CanvasRenderingContext2D} ctx - the CanvasRenderingContext2D to create the gradient with
   * @returns {Style} the gradient style created
   * @private
   */
  public static getGradientStyle(colours: string[], radius: number, centre: Vector, lineWidth: number, ctx: CanvasRenderingContext2D): Style {
    return new Style(
      new RadialGradient(
        centre.clone(),
        radius,
        radius + 1,
        AbstractGradient.distributeEvenly(colours)
      ).createGradient(ctx),
      lineWidth
    );
  }
}

/**
 * Represents the Ringularity theme's background class for drawing to the background class.
 * Subclasses will be created for each app
 */
export class RingularityBackground extends AbstractBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(
    ctx: CanvasRenderingContext2D,
    centre: Vector,
    baseRadius: number,
    colourScheme: ColourScheme
  ) {
    super(ctx, centre, baseRadius, colourScheme);
  }

  /**
   * Draws the bottom right arc that is not covered by the main angle range
   * @param {number} radius - the radius of the arc
   * @param {number} lineWidth - the width of the arc
   * @protected
   */
  protected drawBottomRightArc(radius: number, lineWidth: number): void {
    let angles = getRemainingCircle(RINGULARITY_THEME.MAIN_ANGLE_RANGE);
    new Arc(
      radius,
      angles,
      new Style("black", lineWidth),
      this.centre.clone()
    ).draw(this.ctx);
  }

  /**
   * Draws the main background circle and square
   * @param {number} rectWidth - the width and length of the circle
   * @param {number} circleRadius - the radius of the circle
   * @param {number} circleLineWidth - the width of the circle
   * @protected
   */
  protected drawMainBackground(rectWidth: number, circleRadius: number, circleLineWidth: number): void {
    new Rectangle(
      rectWidth,
      rectWidth,
      Style.noStrokeFill("#111"),
      Vector.sub(this.centre, new Vector(rectWidth/2, rectWidth/2))
    ).draw(this.ctx);

    new Circle(
      circleRadius,
      new Style(this.colourScheme.BACKGROUND, circleLineWidth),
      this.centre.clone()
    ).draw(this.ctx);
  }

  /**
   * Draws the outer and inner strokes around the gauge arc
   * @param {number} width - the width of the arcs
   * @param {[number, number]} radii - the two radii values to create the arcs with
   * @protected
   */
  protected drawGaugeArcStrokeLines(width: number, radii: [number, number]): void {
    this.drawStrokePair(RINGULARITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.ARC_BAR.getPrimary(), width, radii);
  }

  /**
   * Draws the inner glass circle
   * @param {number} radius - the radius of this inner circle
   * @protected
   */
  protected drawGlassInnerCircle(radius: number): void {
    let glass = new Circle(radius, Style.noStrokeFill(this.colourScheme.GLASS), this.centre.clone());
    Canvas.drawTransparency(ctx => glass.draw(ctx), this.ctx);
  }

  /**
   * Draws a pair of arcs that 'sandwich' the arc on the gauge
   * @param {NumberRange} angles - the angles of both arcs
   * @param {string} colour - the base colour of the arcs. The outer arc will have this colour, while the inner will
   * have a modified colour based on this colour (see {@link RingularityThemeHelper#getColourPairString} for more details)
   * @param {number} width - the width of the arcs
   * @param {[number, number]} radii - the two radii values to create the arcs with
   * @private
   */
  private drawStrokePair(angles: NumberRange, colour: string, width: number, radii: [number, number]): void {
    let colours = RingularityThemeHelper.getColourPairString(colour);
    this.drawGaugeArc(radii[0], colours[0], angles.clone(), width);
    this.drawGaugeArc(radii[1], colours[1], angles.clone(), width);
  }

  /**
   * Draws an arc intended to surround the RPM part of the gauge
   * @param {number} radius - the radius of the arc
   * @param {string} colour - the colour of the arc
   * @param {NumberRange} angles - the angles of the arc
   * @param {number} width - the width of the arc
   * @private
   */
  private drawGaugeArc(radius: number, colour: string, angles: NumberRange, width: number): void {
    new Arc(
      radius,
      angles.clone(),
      new Style(colour, width),
      this.centre.clone()
    ).draw(this.ctx);
  }
}
