import { RINGULARITY_THEME, RingularityBackground, RingularityThemeHelper } from "./ringularity";
import { UnitisedComponent } from "../../../gauges/components/unitisedComponent";
import { ColourScheme } from "../../../colours/colourScheme";
import { Vector } from "../../../maths/vector";
import {
  AbstractPressureGaugeBuilder
} from "../../../gauges/components/builders/fullGauge/abstractPressureGaugeBuilder";
import { ArcBarDisplayer } from "../../../gauges/dataDisplayers/arcBarDisplayer";
import { ArcNumbering } from "../../../gauges/dataDisplayers/arcNumbering";
import { AbstractGaugePointer } from "../../../gauges/dataDisplayers/pointers/abstractGaugePointer";
import { ArcTicks } from "../../../gauges/dataDisplayers/arcTicks/arcTicks";
import { HasColourScheme } from "../../../mixins/builders/hasColourScheme";
import { applyMixins } from "../../../mixins/multiInherit";
import { ArcBar } from "../../../shapes/arcBar";
import { Style } from "../../../styles/style";
import { StackedUnitisedBuilder } from "../../../gauges/components/builders/unitised/stackedUnitisedBuilder";
import { Rectangle } from "../../../shapes/rectangle";
import { AbstractBoostApp } from "../../abstractBoostApp";

////////////////////////////////////////////////////////////////////////////////////////////////////
// Ringularity Boost App Class //                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the nu version of the boost app
 */
export class RingularityBoostApp extends AbstractBoostApp {
  /**
   * @constructor
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   */
  constructor(baseRadius: number, document: Document, bngApi: any) {
    super(RINGULARITY_THEME, baseRadius, document, bngApi, RingularityPressureGaugeBuilder, RingularityBoostBackground);
  }

  protected override createPressureReadout(): UnitisedComponent {
    return this.setDefaultBuilderValues(StackedUnitisedBuilder)
      .setQuantity(this.getQuantityInstance())
      .setValueFontSize(18)
      .setUnitFontSize(10)
      .setPadding(12)
      .build();
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Builder Classes //                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

class RingularityPressureGaugeBuilder extends AbstractPressureGaugeBuilder {
  static readonly RADIUS = 57;

  /**
   * Creates and returns a Style object for the arc bar with a gradient from the given colours
   * @param {string[]} colours - the colours to use for the gradient
   * @returns {Style} the gradient style created
   * @private
   */
  private getGradientStyle(colours: string[]): Style {
    return RingularityThemeHelper.getGradientStyle(colours, RingularityPressureGaugeBuilder.RADIUS, this.centre, 24, this.ctx);
  }

  protected override createArcBar(): ArcBarDisplayer {
    let mainStyle = this.getGradientStyle(RingularityThemeHelper.getArcbarColourPair(this.colourScheme));
    let backgroundStyle = this.getGradientStyle(RingularityThemeHelper.getTransparentColourPair("rgb(40, 40, 40)"));

    let mainArcBar = new ArcBar(RingularityPressureGaugeBuilder.RADIUS, RINGULARITY_THEME.MAIN_ANGLE_RANGE.clone(), mainStyle, backgroundStyle,this.centre);
    return new ArcBarDisplayer(this.createValueRange(), mainArcBar);
  }

  protected override createNumbering(): ArcNumbering {
    // The font size for the numbering; decrease as number of digits to display increases
    const FONTSIZE = 10 - Math.floor(this.maxBoostConverted).toString().length;
    return this.createBasicNumbering(48, FONTSIZE, 5, RINGULARITY_THEME.MAIN_ANGLE_RANGE, this.colourScheme.NUMBERING);
  }

  protected override createPointer(): AbstractGaugePointer {
    return null;
  }

  protected override createTicks(): ArcTicks {
    let ticks = new ArcTicks(
      this.centre,
      62,
      17,
      RINGULARITY_THEME.MAIN_ANGLE_RANGE,
    );
    ticks.setTickWidth(2);
    ticks.setTickLength(5);
    return ticks;
  }
}
interface RingularityPressureGaugeBuilder extends HasColourScheme {}
applyMixins(RingularityPressureGaugeBuilder, [HasColourScheme]);

////////////////////////////////////////////////////////////////////////////////////////////////////
// Background Class //                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Represents the background elements that can be drawn to the background canvas for the Ringularity
 * version of the boost app
 */
class RingularityBoostBackground extends RingularityBackground {
  /**
   * @constructor
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {Vector} centre - the centre of the background
   * @param {number} baseRadius - the base radius from the centre
   * @param {ColourScheme} colourScheme - the colour scheme to apply
   */
  constructor(ctx: CanvasRenderingContext2D, centre: Vector, baseRadius: number, colourScheme: ColourScheme) {
    super(ctx, centre, baseRadius, colourScheme);
  }

  /**
   * Draws the background rectangles for both the unit and value
   * @private
   */
  private drawUnitAndValueBackgrounds(): void {
    new Rectangle(
      48,
      24,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.add(this.centre, new Vector(-24, -25)),
      true
    ).draw(this.ctx);

    new Rectangle(
      48,
      18,
      Style.noStrokeFill(this.colourScheme.BACKGROUND),
      Vector.add(this.centre, new Vector(-24, 3)),
      true
    ).draw(this.ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(): void {
    super.draw();
    this.drawGlassInnerCircle(this.baseRadius);
    this.drawMainBackground(60, RingularityPressureGaugeBuilder.RADIUS, 33);
    this.drawGaugeArcStrokeLines(2, [42, 72]);
    this.drawUnitAndValueBackgrounds();
    this.drawBottomRightArc(RingularityPressureGaugeBuilder.RADIUS, 26);
  }
}
