import { Vector } from "../maths/vector";
import { ColourScheme } from "../colours/colourScheme";
import { Canvas } from "../canvas";
import { AbstractBackground } from "./abstractBackground";
import { Dimensions } from "../types/dimensions";
import { Quantity } from "../maths/units/quantity";
import { Theme } from "./themes/theme";
import { Newable } from "../types/classes";
import { AbstractFullGaugeBuilder } from "../gauges/components/builders/fullGauge/abstractFullGaugeBuilder";
import { HasColourScheme } from "../mixins/builders/hasColourScheme";
import { HasRadius } from "../mixins/builders/hasRadius";
import { AbstractGaugeComponent } from "../gauges/components/abstractGaugeComponent";
import { AbstractComponentBuilder } from "../gauges/components/builders/abstractComponentBuilder";
import { HasFontName } from "../mixins/builders/hasFontName";
import { CanDraw } from "../mixins/builders/canDraw";
import { getNextElement } from "../utils/arrayUtils";

/**
 * Represent an app that can display information from a vehicle
 * @template T, S, R
 */
export abstract class AbstractBaseApp<T, S, R extends AbstractGaugeComponent<any>> {
  protected readonly centre: Vector;
  protected readonly COLOUR_SCHEMES: ColourScheme[] = ColourScheme.createSchemes();
  // Default to first
  protected colourScheme: ColourScheme = this.COLOUR_SCHEMES[0];
  // A flag that determines whether the background needs to be re-drawn for the next update cycle
  protected bgNeedsRedraw = false;

  // The canvases for drawing, background is drawn to the latter
  protected readonly canvas: Canvas;
  protected readonly bgCanvas: Canvas;
  // The background object, responsible for drawing various background elements to the background canvas
  protected background: AbstractBackground;

  // The unique identifier for this app
  protected id: string;

  /**
   * @constructor
   * @param {Theme} theme - the theme of this app
   * @param {number} baseRadius - the radius of the outermost part of the app
   * @param {Document} document - the document element the app uses
   * @param {any} bngApi - the bngApi service
   * @param {Newable<AbstractFullGaugeBuilder<R>>} GaugeBuilder - the gauge builder class to use when creating gauge
   * components
   * @param {Newable<AbstractBackground>} Background - the background class to use for creating the background
   */
  protected constructor(
    protected readonly theme: Theme,
    protected readonly baseRadius: number,
    protected readonly document: Document,
    protected readonly bngApi: any,
    protected readonly GaugeBuilder: Newable<AbstractFullGaugeBuilder<R>>,
    protected readonly Background: Newable<AbstractBackground>,
  ) {
    this.centre = new Vector(baseRadius, baseRadius);
    this.id = this.getId();

    // The foreground and background canvases
    this.canvas = new Canvas(document, this.id + "_canvas", this.baseRadius * 2);
    this.bgCanvas = new Canvas(document, this.id + "_bgCanvas", this.baseRadius * 2);

    this.addClickEvents();

    this.background = this.createBackground();
  }

  /**
   * Creates the gauge component using the instance's gauge builder and returns it
   * @returns {R} the created gauge component
   * @protected
   */
  protected createGauge(): R {
    return this.setDefaultGaugeBuilderValues(this.GaugeBuilder).build();
  }

  /**
   * Creates the background component
   */
  protected createBackground(): AbstractBackground {
    return new this.Background(
      this.bgCanvas.get2DContext(),
      this.centre,
      this.baseRadius,
      this.colourScheme
    );
  }

  /**
   * Adds click an event handler for mouse actions on the foreground canvas
   */
  protected addClickEvents(): void {
    this.canvas.setupCanvasClick(
      (_event: Event) => this.cycleUnitWithUpdate(),
      (_event: Event) => this.cycleColourSchemeWithUpdate()
    );
  }

  /**
   * Sets default values to all setters in an AbstractComponentBuilder instance.
   * @param {AbstractComponentBuilder<any>} Builder - the class of builder to create and set values to
   * @returns {AbstractComponentBuilder<any>} the same builder object
   * @protected
   */
  protected setDefaultBuilderValues<T extends AbstractComponentBuilder<any>>(Builder: Newable<T>): T {
    let builder = new Builder();
    // TODO - Find a better way of performing 'instanceof' for below partial classes
    if (Object.getPrototypeOf(builder)['setColourScheme']) (builder as unknown as HasColourScheme).setColourScheme(this.colourScheme);
    if (Object.getPrototypeOf(builder)['setRadius']) (builder as unknown as HasRadius).setRadius(this.baseRadius);
    if (Object.getPrototypeOf(builder)['setFontName']) (builder as unknown as HasFontName).setFontName(this.theme.FONT_NAME);
    if (Object.getPrototypeOf(builder)['setCtx']) (builder as unknown as CanDraw).setCtx(this.canvas.get2DContext());
    return builder.setCentre(this.centre);
  }

  /**
   * Sets default values to all setters in an AbstractFullGaugeBuilder instance.
   * @param {AbstractFullGaugeBuilder<any>} builder - the builder to set values to
   * @returns {AbstractFullGaugeBuilder<any>} the same builder object
   * @protected
   */
  protected setDefaultGaugeBuilderValues(builder: Newable<AbstractFullGaugeBuilder<any>>): AbstractFullGaugeBuilder<any> {
    return this.setDefaultBuilderValues(builder);
  }

  /**
   * Resizes the canvases for drawing on a smaller or bigger canvas.
   * Note that all apps are currently square (and assumed for the future?) so this will also set the height to this
   * value as well
   * @param {number} newWidth - the new width to assign
   */
  public resize(newWidth: number): void {
    this.canvas.resize(newWidth);
    this.bgCanvas.resize(newWidth);
  }

  /**
   * @return {Dimensions} the current dimensions of the canvases
   */
  public getCurrentDimensions(): Dimensions {
    return this.canvas.getCurrentDimensions();
  }

  /**
   * Cycles the unit and recreates the app to show the change when drawing
   */
  public cycleUnitWithUpdate(): void {
    this.cycleUnit();
    this.recreate(true);
  }

  /**
   * Cycles the colour scheme and recreates the app to show the change when drawing
   */
  public cycleColourSchemeWithUpdate(): void {
    this.colourScheme = getNextElement(this.COLOUR_SCHEMES, this.colourScheme);
    // Re-creating is far easier than having tonnes of setters everywhere
    this.recreate(true);
  }

  /**
   * Recreates the components and re-draws the background canvas.
   * If the app is not return set up, this method does nothing
   */
  public recreate(resave: boolean): void {
    if (!this.isSetup()) return;

    // Re-create components to reflect unit changes
    this.createComponents();
    // Re-create background
    this.background = this.createBackground();
    this.drawBackgroundCanvas();

    // Save this colour scheme and unit as default
    if (resave) this.save();
  }

  /**
   * Saves the current colour scheme and unit to a file in the user's directory. Note that this
   * only saves the indexes with respect to the colourSchemes array and not the actual instance
   */
  public save(): void {
    let data = {
      unit: this.getIndexOfCurrUnit(),
      colourScheme: this.COLOUR_SCHEMES.indexOf(this.colourScheme)
    };

    this.bngApi.engineLua("extensions.ui_tachometers.save('" + this.id + "', " + this.bngApi.serializeToLua(data) + ")");
  }

  /**
   * Loads the settings file from the user's directory. If the file does not exist, this method
   * does nothing; else, it loads the unit and colour scheme to this app
   */
  public load(): void {
    this.bngApi.engineLua(
      "extensions.ui_tachometers.load('" + this.id + "')",
      (response: { unit: number; colourScheme: number }) => {
        if (!response) return;

        this.setIndexOfCurrUnit(response.unit || 0);
        // Backwards compatibility -> the number of colour-schemes has changed so check it is not out
        // of bounds
        this.colourScheme =
          this.COLOUR_SCHEMES[response.colourScheme < this.COLOUR_SCHEMES.length ? response.colourScheme : 0];

        this.recreate(false);
      }
    );
  }

  /**
   * Draws to the main canvas
   */
  public draw(): void {
    // Re-draw if necessary before the foreground canvas does so
    if (this.bgNeedsRedraw) this.drawBackgroundCanvas();

    this.canvas.show(true);
    this.canvas.clear();
  }

  /**
   * Draws the app to the background canvas
   */
  public drawBackgroundCanvas(): void {
    this.bgCanvas.show(true);
    this.bgCanvas.clear();
    this.background.draw();
  }

  /**
   * Hides the app by hiding both canvases
   */
  public hide(): void {
    this.canvas.show(false);
    this.bgCanvas.show(false);
    // When this app is next drawn, the background will need an update
    this.bgNeedsRedraw = true;
  }

  /**
   * Reloads the UI, hiding it after 50ms. If instantReload is true, this is done
   * instantly
   * @param {AbstractBaseApp} app - the app to reload
   * @param {boolean} instantReload - whether to instantly reload instead of waiting
   */
  public static reload(app: AbstractBaseApp<any, any, any>, instantReload: boolean): void {
    if (!app) return;

    let time = instantReload ? 0 : 50;
    setTimeout(() => {
      // It is unknown whether this vehicle will need this app, so hide it provisionally and it is
      // does, the app will re-show itself automatically when updating/drawing occurs
      app.hide();
    }, time);
  }

  /**
   * Updates the visual display with the necessary data
   * @param {T} data - the data to update with
   */
  public abstract update(data: T): void;

  /**
   * Sends the required data to initialise any additional objects required for drawing/processing
   * @param {S} data - the data to initialise with
   */
  public abstract sendInitialVehicleData(data: S): void;

  /**
   * @return {boolean} whether the app inside this container is setup yet
   */
  public abstract isSetup(): boolean;

  /**
   * Changes the unit of the speedo component
   */
  protected abstract cycleUnit(): void;

  /**
   * Creates the components
   */
  protected abstract createComponents(): void;

  /**
   * Gets the current index of the unit being displayed
   * @return {number} the index of the current unit
   */
  protected abstract getIndexOfCurrUnit(): number;

  /**
   * Sets the index of the unit being displayed
   * @param {number} index - the index of the unit to display
   */
  protected abstract setIndexOfCurrUnit(index: number): void;

  /**
   * Returns a quantity instance. This method returns the current in-use one, should it exist, otherwise
   * it returns a quantity instance
   * @return {Quantity} the quantity
   */
  protected abstract getQuantityInstance(): Quantity;

  /**
   * Returns a unique identifier for this app
   * @returns {string} the unique identifier
   */
  public abstract getId(): string;
}
