/**
 * Applies one or more mixins onto a base class, mimicking multiple inheritance
 * @param {any} derivedCtor - the base class
 * @param {any[]} constructors - the list of mixins
 */
export function applyMixins(derivedCtor: any, constructors: any[]): void {
  constructors.forEach((baseCtor) => {
    Object.getOwnPropertyNames(baseCtor.prototype).forEach((name) => {
      Object.defineProperty(
        derivedCtor.prototype,
        name,
        Object.getOwnPropertyDescriptor(baseCtor.prototype, name) || Object.create(null)
      );
    });
  });
}