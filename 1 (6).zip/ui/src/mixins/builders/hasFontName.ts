export class HasFontName {
  protected fontName: string;

  public setFontName(fontName: string): this {
    this.fontName = fontName;
    return this;
  }
}