export class CanDraw {
  protected ctx: CanvasRenderingContext2D;

  public setCtx(ctx: CanvasRenderingContext2D): this {
    this.ctx = ctx;
    return this;
  }
}