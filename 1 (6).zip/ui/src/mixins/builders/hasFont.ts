import { Font } from "../../text/font";

export class HasFont {
  protected font: Font;

  public setFont(font: Font): this {
    this.font = font;
    return this;
  }
}