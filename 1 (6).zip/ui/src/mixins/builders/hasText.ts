import { Text } from "../../text/text";

export class HasText {
  protected text: Text;

  public setText(text: Text): this {
    this.text = text;
    return this;
  }
}