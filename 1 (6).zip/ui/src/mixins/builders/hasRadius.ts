export class HasRadius {
  protected radius: number;

  public setRadius(radius: number): this {
    this.radius = radius;
    return this;
  }
}