import { ColourScheme } from "../../colours/colourScheme";

export class HasColourScheme {
  protected colourScheme: ColourScheme;

  public setColourScheme(colourScheme: ColourScheme): this {
    this.colourScheme = colourScheme;
    return this;
  }
}