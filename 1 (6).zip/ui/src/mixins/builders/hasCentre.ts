import { Vector } from "../../maths/vector";

export class HasCentre {
  protected centre: Vector;

  public setCentre(value: Vector): this {
    this.centre = value;
    return this;
  }
}