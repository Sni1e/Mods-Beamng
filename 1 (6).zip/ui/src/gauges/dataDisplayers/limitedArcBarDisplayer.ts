import { AbstractBoundedDataDisplayer } from "./abstractBoundedDataDisplayer";
import { ArcBar } from "../../shapes/arcBar";
import { NumberRange } from "../../maths/numberRange";

/**
 * Represents an arc bar displayer, where a part of the end of the bar has a cap on it.
 * Useful for bars that have a 'warning' area where the bar shouldn't exceed
 */
export class LimitedArcBarDisplayer extends AbstractBoundedDataDisplayer<number> {
  /**
   * @constructor
   * @param {NumberRange} valueRange - the value range of the displayer that marks the lowest and highest
   * values that will be displayed
   * @param {ArcBar} mainArcBar - the arc bar that will show the current value
   * @param {ArcBar} limitArcBar - the arc bar that will show the 'limit' part of the bar
   */
  constructor(valueRange: NumberRange, private readonly mainArcBar: ArcBar, private readonly limitArcBar: ArcBar) {
    super(valueRange);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.mainArcBar.draw(ctx);
    this.limitArcBar.draw(ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: number): void {
    this.setValueOf(data, this.mainArcBar);
  }
}
