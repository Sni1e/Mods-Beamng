import { AbstractBoundedDataDisplayer } from "../abstractBoundedDataDisplayer";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";

/**
 * Represents a pointer that points at the angle that the value represents
 */
export abstract class AbstractGaugePointer extends AbstractBoundedDataDisplayer<number> {
  /**
   * @constructor
   * @param {Vector} centre - the centre of the pointer
   * @param {NumberRange} valueRange - the value range possible to displayer
   * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
   */
  protected constructor(protected centre: Vector, valueRange: NumberRange, protected arcAngles: NumberRange) {
    super(valueRange);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: number): void {
    let perc = this.getPerc(data);
    let angle = this.arcAngles.getLinearRatio(perc);
    this.setActiveAngle(angle);
  }

  /**
   * Returns the angle 180deg added to the current angle. Note that the value returned will
   * always be +180deg from the current, regardless of whether this makes the angle bigger than
   * 360deg
   * @param {number} angle - the angle to get the inverse of
   * @returns {number} the angle 180deg plus the current angle, in radians
   */
  protected getInvAngle(angle: number): number {
    return angle + Math.PI;
  }

  /**
   * Sets the centre of rotation for the pointers
   * @param {Vector} centre - the centre of rotation to set
   * @public
   */
  public abstract setRotationalCentre(centre: Vector): void;

  /**
   * Sets the angle this pointer is pointing to
   * @param {number} angle - the angle to point to
   * @public
   */
  public abstract setActiveAngle(angle: number): void;
}
