import { AbstractGaugePointer } from "./abstractGaugePointer";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { Rotatable } from "../../../rotatable";
import { Drawable } from "../../../drawable";

/**
 * Represents a pointer with only one moving piece and a middle dial
 */
export class UniPointer extends AbstractGaugePointer {
  /**
   * @constructor
   * @param {Vector} centre - the centre of the pointer
   * @param {NumberRange} valueRange - the value range possible to displayer
   * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
   * @param {Rotatable} piece - the piece that rotates
   * @param {Drawable} dial - the dial piece
   */
  constructor(
    centre: Vector,
    valueRange: NumberRange,
    arcAngles: NumberRange,
    protected readonly piece: Rotatable,
    protected readonly dial: Drawable
  ) {
    super(centre, valueRange, arcAngles);
    this.setRotationalCentre(this.centre);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setActiveAngle(angle: number): void {
    this.piece.setAngle(angle);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setRotationalCentre(centre: Vector): void {
    this.piece.setRotationalCentre(centre);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.piece.draw(ctx);
    this.dial.draw(ctx);
  }
}
