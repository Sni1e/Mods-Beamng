import { AbstractGaugePointer } from "./abstractGaugePointer";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { SimplePointer } from "./simplePointer";
import { Drawable } from "../../../drawable";

/**
 * Represents a pointer object, wherein an accent is displayed over the pointer
 */
export class AccentPointer extends AbstractGaugePointer {
  /**
   * @constructor
   * @param {Vector} centre - the centre of the pointer
   * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
   * @param {SimplePointer} bgPointer - the background pointer
   * @param {SimplePointer} accentPointer - the accent pointer
   * @param {Drawable} pointerDial - the centre dial part of the pointers
   */
  constructor(
    centre: Vector,
    arcAngles: NumberRange,
    protected bgPointer: SimplePointer,
    protected accentPointer: SimplePointer,
    protected pointerDial: Drawable
  ) {
    super(centre, bgPointer.getValueRange(), arcAngles);
    this.setRotationalCentre(this.centre);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setActiveAngle(angle: number): void {
    this.accentPointer.setActiveAngle(angle);
    this.bgPointer.setActiveAngle(angle);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setRotationalCentre(centre: Vector): void {
    this.accentPointer.setRotationalCentre(centre);
    this.bgPointer.setRotationalCentre(centre);
  }

  /**
   * @override
   * Draws the pointer pieces to a canvas.
   * Note that pointerDial overrides the pointer dials specified in the pointer objects
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.bgPointer.drawPointers(ctx);
    this.accentPointer.drawPointers(ctx);
    this.pointerDial.draw(ctx);
  }
}
