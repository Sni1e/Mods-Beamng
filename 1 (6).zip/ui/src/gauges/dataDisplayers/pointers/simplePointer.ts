import { AbstractGaugePointer } from "./abstractGaugePointer";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { Rotatable } from "../../../rotatable";
import { Drawable } from "../../../drawable";

/**
 * Represents a gauge pointer as a collection of the centre dial, minor pointer and major pointer
 */
export class SimplePointer extends AbstractGaugePointer {
  /**
   * @constructor
   * @param {Vector} centre - the centre of the pointer
   * @param {NumberRange} valueRange - the value range possible to displayer
   * @param {NumberRange} arcAngles - the start and end angles this pointer can range between
   * @param {Rotatable} majorPointer - the major part of the pointer
   * @param {Rotatable} minorPointer - the minor part of the pointer (points to the inverse angle)
   * @param {Drawable} pointerDial - the pointer dial at the centre
   */
  constructor(
    centre: Vector,
    valueRange: NumberRange,
    arcAngles: NumberRange,
    protected majorPointer: Rotatable,
    protected minorPointer: Rotatable,
    protected pointerDial: Drawable
  ) {
    super(centre, valueRange, arcAngles);
    this.setCentre(this.centre);
    this.setRotationalCentre(this.centre);
    this.setActiveAngle(0);
  }

  /**
   * Draws the pointers
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
   * @public
   */
  public drawPointers(ctx: CanvasRenderingContext2D): void {
    this.majorPointer.draw(ctx);
    this.minorPointer.draw(ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setActiveAngle(angle: number): void {
    // An angle of 0 means the pointer is at the bottom -> -Math.PI/2
    // angle -= Math.PI/2;

    this.majorPointer.setAngle(angle);
    this.minorPointer.setAngle(this.getInvAngle(angle));
  }

  /**
   * @override
   * @inheritDoc
   */
  public setRotationalCentre(centre: Vector): void {
    this.majorPointer.setRotationalCentre(centre);
    this.minorPointer.setRotationalCentre(centre);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.drawPointers(ctx);
    this.pointerDial.draw(ctx);
  }

  /**
   * Sets the centres of the major and minor pointers
   * @param {Vector} centre - the centre to set
   */
  public setCentre(centre: Vector): void {
    this.majorPointer.setCentre(centre);
    this.minorPointer.setCentre(centre);
  }
}
