import { AbstractDataDisplayer } from "./abstractDataDisplayer";
import { ArcTicks } from "./arcTicks/arcTicks";
import { ArcNumbering } from "./arcNumbering";
import { AbstractGaugePointer } from "./pointers/abstractGaugePointer";
import { ArcBarDisplayer } from "./arcBarDisplayer";
import { LimitedArcBarDisplayer } from "./limitedArcBarDisplayer";
import { Drawable } from "../../drawable";
import { CamoArcTicks } from "./arcTicks/camoArcTicks";

/**
 * Represents an object that can update and display a single piece of information to a full gauge's
 * worth of displayers
 */
export class FullGauge extends AbstractDataDisplayer<{ arcBar: number; ticks: number; pointer: number }> {
  /**
   * @constructor
   * @param {ArcTicks} ticks - the ticks that show regular intervals along the gauge
   * @param {ArcNumbering} numbering - the numbers that show the value at set intervals
   * @param {AbstractGaugePointer} pointer - the pointer that pointers to the current value. Can be
   * <b>null</b>
   * @param {ArcBarDisplayer | LimitedArcBarDisplayer} bar - the bar that shows the current value.
   * Can be <b>null</b>
   */
  constructor(
    private readonly ticks: ArcTicks,
    private readonly numbering: ArcNumbering,
    private readonly pointer?: AbstractGaugePointer,
    private readonly bar?: ArcBarDisplayer | LimitedArcBarDisplayer
  ) {
    super();
  }

  /**
   * Returns the elements as a list. The order of the list is in their drawn order, from first drawn
   * to last drawn. Note that some values may be <b>null</b>
   * @returns {Drawable[]}
   */
  private elementsToList(): Drawable[] {
    return [this.bar, this.numbering, this.ticks, this.pointer];
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: { arcBar: number; ticks: number; pointer: number }): void {
    if (this.bar) this.bar.update(data.arcBar);

    if (this.ticks instanceof CamoArcTicks) this.ticks.update(data.ticks);

    if (this.pointer) this.pointer.update(data.pointer);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    let elements = this.elementsToList();
    elements.forEach(element => element?.draw(ctx));
  }
}
