import { Drawable } from "../../drawable";

/**
 * Represents a data displayer than can draw to a canvas
 * @template T
 * T is the type/object that will be used to perform updates
 */
export abstract class AbstractDataDisplayer<T> extends Drawable {
  /**
   * @constructor
   */
  protected constructor() {
    super();
  }

  /**
   * Updates with data sent via an object
   * @param {T} data - the data object
   */
  public abstract update(data: T): void;
}
