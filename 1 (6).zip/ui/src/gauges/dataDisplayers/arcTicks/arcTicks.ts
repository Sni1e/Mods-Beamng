import { Moveable } from "../../../moveable";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { getRelCircularPoint } from "../../../utils/mathsUtils";
import { Line } from "../../../shapes/line";
import { Style } from "../../../styles/style";

/**
 * Represents a list of lines ("ticks") that follow an arc curve.
 * Useful for representing an RPM gauge or a gauge with set interval values
 */
export class ArcTicks extends Moveable {
  protected drawEndTicks = true;
  protected majorSpacing = 4;
  protected colour = "white";
  protected tickLength = 10;
  protected tickWidth = 4;
  protected areCentred = true;

  protected readonly angleSpacing: number;
  protected ticks: Vector[][];

  /**
   * @constructor
   * By default: <ul>
   *  <li>End ticks are drawn</li>
   *  <li>Major (big) ticks are spaced every 4th tick</li>
   *  <li>Ticks are coloured white</li>
   *  <li>Tick length is 10</li>
   *  <li>Tick width is 4</li>
   *  <li>Tick are centred</li>
   * </ul>
   * Use the relevant set method to adjust as necessary
   * @param {Vector} centre - the centre of the display
   * @param {number} radius - the distance between the display centre and each tick's centre. Note
   * that for non-centred ticks, this radii is the _smallest_ radii of the ticks
   * @param {number} numTicks - the number of ticks to have
   * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
   */
  constructor(
    centre: Vector,
    protected readonly radius: number,
    protected numTicks: number,
    protected readonly arcRange: NumberRange
  ) {
    super(centre);
    // -1 as element 0 starts at angleRange.lower and element N ends at angleRange.upper
    // so include upper bound as element N (not N+1)
    this.angleSpacing = this.arcRange.getDifference() / (this.numTicks - 1);
    this.ticks = this.generateTicks();
  }

  /**
   * Sets whether or not to draw end ticks
   * @param {boolean} drawEndTicks - whether to draw end ticks
   */
  public setDrawEndTicks(drawEndTicks: boolean): void {
    if (this.drawEndTicks === drawEndTicks) return;

    this.drawEndTicks = drawEndTicks;
    this.ticks = this.generateTicks();

    // Remove the two end ticks from the count
    if (!this.drawEndTicks) this.numTicks -= 2;
  }

  /**
   * Sets whether to centre the ticks or not
   * @param {boolean} areCentred - whether to centre the ticks
   */
  public setCentring(areCentred: boolean): void {
    if (this.areCentred === areCentred) return;

    this.areCentred = areCentred;
    this.ticks = this.generateTicks();
  }

  /**
   * Sets the tick length
   * @param {number} length - the length to set
   */
  public setTickLength(length: number): void {
    if (this.tickLength === length) return;

    this.tickLength = length;
    this.ticks = this.generateTicks();
  }

  /**
   * Sets the spacing between major ticks
   * @param {number} spacing - the spacing to set
   */
  public setMajorSpacing(spacing: number): void {
    if (this.majorSpacing === spacing) return;

    this.majorSpacing = spacing;
    this.ticks = this.generateTicks();
  }

  /**
   * Sets the tick width
   * @param {number} width - the width to set
   */
  public setTickWidth(width: number): void {
    if (this.tickWidth === width) return;

    this.tickWidth = width;
  }

  /**
   * Sets the tick's colour
   * @param {string} colour - the colour to set
   */
  public setTickColour(colour: string): void {
    this.colour = colour;
  }

  /**
   * Generates a list of ticks as pairs of radii
   * @returns {[[Vector, Vector]]} the ticks, as pairs of inner and outer radii
   */
  private generateTicks(): Vector[][] {
    let ticks = [];
    let currAngle = this.arcRange.getLower();

    for (let i = 0; i < this.numTicks; i++) {
      let isMajor = i % this.majorSpacing !== 0;
      let isEndTick = i === 0 || i === this.numTicks - 1;

      // Only draw end ticks if wanted
      if (!isEndTick || this.drawEndTicks) ticks.push(this.addTick(currAngle, isMajor));

      currAngle += this.angleSpacing;
    }

    return ticks;
  }

  /**
   * Returns the tick radii for a non centred tick
   * @param {boolean} isMinor - whether this tick is a minor tick
   * @returns {number[]} the tick's start and end radii
   */
  private getTickRadiiNonCentred(isMinor: boolean): number[] {
    let r1 = this.getTickRadius(false);
    let r2 = this.getTickRadius(true);

    // Half size for minor ticks
    if (isMinor) r2 += (r1 - r2) / 2;

    return [r1, r2];
  }

  /**
   * Returns the tick radii for a centred tick
   * @param {boolean} isMinor - whether this tick is a minor tick
   * @returns {[number, number]} the tick's start and end radii
   */
  private getTickRadiiCentred(isMinor: boolean): number[] {
    let r1 = this.getTickRadius(false);
    let r2 = this.getTickRadius(true);

    if (isMinor) {
      // Make it smaller but also centre the change
      let size = this.tickLength / 2;
      r1 -= size;
      r2 += size;
    }

    return [r1, r2];
  }

  /**
   * Returns the tick radii
   * @param {boolean} isMinor - whether this tick is a minor tick
   * @returns {[number, number]} the tick's start and end radii
   */
  private getTickRadii(isMinor: boolean): number[] {
    return this.areCentred ? this.getTickRadiiNonCentred(isMinor) : this.getTickRadiiCentred(isMinor);
  }

  /**
   * Returns an RPM tick, as a pair of radii, of the given inputs. The radii returned are the
   * outer and inner radii of the tick.
   * @param {number} angle - the angle this tick sits at around the RPM
   * @param {boolean} isMinor - whether this tick is representing a minor point on the gauge (ie.
   * a thousand on an RPM gauge)
   * @returns {[Vector, Vector]} the radii of the tick
   */
  private addTick(angle: number, isMinor: boolean): Vector[] {
    let radii = this.getTickRadii(isMinor);

    return [getRelCircularPoint(this.centre, radii[0], angle), getRelCircularPoint(this.centre, radii[1], angle)];
  }

  /**
   * Returns the radius on the RPM gauge a tick will start/end at
   * @param {boolean} isInner - whether to return the inner or outer radius
   * @returns {number}
   */
  private getTickRadius(isInner: boolean): number {
    if (isInner) return this.radius - this.tickLength;
    else return this.radius + this.tickLength;
  }

  /**
   * Draws a tick to a canvas object
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {[Vector, Vector]} tick - the tick's start and end positions
   * @param {string} colour - the colour to draw the tick in
   */
  protected drawTick(ctx: CanvasRenderingContext2D, tick: Vector[], colour: string): void {
    new Line(tick[0], tick[1], new Style(colour, this.tickWidth)).draw(ctx);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.ticks.forEach(tick => this.drawTick(ctx, tick, this.colour));
  }
}
