import { DualColourArcTicks } from "./dualColourArcTicks";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { ColourPriority } from "../../../colours/colourPriority";

/**
 * Represents an arc tick component that changes individual tick colour based on whether it meets a,
 * threshold value and whose threshold value can be changed
 */
export class CamoArcTicks extends DualColourArcTicks {
  /**
   * @constructor
   * @see ArcTicks for default parameters and how to change them
   * @param {Vector} centre - the centre of the display
   * @param {number} radius - the distance between the display centre and each tick's centre
   * @param {number} numTicks - the number of ticks to have
   * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
   * @param {ColourPriority} colours - the colours for the tick
   */
  constructor(centre: Vector, radius: number, numTicks: number, arcRange: NumberRange, colours: ColourPriority) {
    super(centre, radius, numTicks, arcRange, colours);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: number): void {
    this.threshold = data;
  }
}
