import { ArcTicks } from "./arcTicks";
import { Vector } from "../../../maths/vector";
import { NumberRange } from "../../../maths/numberRange";
import { ColourPriority } from "../../../colours/colourPriority";

/**
 * Represents arc ticks where there are two groups of colouring, specified by a threshold value
 */
export class DualColourArcTicks extends ArcTicks {
  /**
   * @constructor
   * @see ArcTicks for default parameters and how to change them
   * @param {Vector} centre - the centre of the display
   * @param {number} radius - the distance between the display centre and each tick's centre
   * @param {number} numTicks - the number of ticks to have
   * @param {NumberRange} arcRange - the angle range of the arc the ticks follow
   * @param {ColourPriority} colours - the colours for the tick
   * @param {number} threshold - the threshold value. Defaults to 0
   */
  constructor(
    centre: Vector,
    radius: number,
    numTicks: number,
    arcRange: NumberRange,
    private colours: ColourPriority,
    protected threshold = 0
  ) {
    super(centre, radius, numTicks, arcRange);
  }

  /**
   * Returns the accent colour of a tick based on whether it has surpassed a threshold.
   * More specifically, a tick that surpasses the threshold will return the secondary colour, and
   * vice versa for the primary colour
   * @param {boolean} isThresholdPassed - whether the tick being drawn is over the current threshold
   * @returns {string} the accent colour
   */
  private getAccentColour(isThresholdPassed: boolean): string {
    return isThresholdPassed ? this.colours.getSecondary() : this.colours.getPrimary();
  }

  /**
   * Returns whether a particular tick is past the threshold or not
   * @param {number} tickIndex - the tick's index
   * @returns {boolean} whether this tick is past the threshold or not
   */
  private isTickPassedThreshold(tickIndex: number): boolean {
    if (this.drawEndTicks)
      // -1 as indexes start at 0
      return tickIndex / (this.numTicks - 1) >= this.threshold;
    // No end tick at the start so shift everything up by 1 index
    else return (tickIndex + 1) / (this.numTicks + 1) >= this.threshold;
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    for (let i = 0; i < this.numTicks; i++) {
      let colour = this.getAccentColour(this.isTickPassedThreshold(i));
      this.drawTick(ctx, this.ticks[i], colour);
    }
  }
}
