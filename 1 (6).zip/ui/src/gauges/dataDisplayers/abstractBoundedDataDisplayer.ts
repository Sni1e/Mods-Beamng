import { AbstractDataDisplayer } from "./abstractDataDisplayer";
import { NumberRange } from "../../maths/numberRange";
import { ArcBar } from "../../shapes/arcBar";

/**
 * Represents an object that can display data that is bounded between two values, ie. is discrete in
 * nature.
 * T is the type/object that will be used to perform updates
 */
export abstract class AbstractBoundedDataDisplayer<T> extends AbstractDataDisplayer<T> {
  /**
   * @constructor
   * @param {NumberRange} VALUE_RANGE - the value range possible to display
   */
  protected constructor(protected readonly VALUE_RANGE: NumberRange) {
    super();
  }

  public getValueRange(): NumberRange {
    return this.VALUE_RANGE.clone();
  }

  /**
   * Sets the value of an ArcBar instance
   * @param {number} value - the value to set
   * @param {ArcBar} arcBar - the arc bar to set the value to
   */
  protected setValueOf(value: number, arcBar: ArcBar): void {
    let perc = this.getPerc(value);
    arcBar.setPercentageAlong(perc);
  }

  /**
   * Returns the percentage complete this displayer will be, given a value
   * @param {number} value - the value to consider
   * @returns {number} the percentage [0,1] complete this displayer will be
   */
  protected getPerc(value: number): number {
    return this.VALUE_RANGE.getNormLinearRatio(value);
  }
}
