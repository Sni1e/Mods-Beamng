import { AbstractBoundedDataDisplayer } from "./abstractBoundedDataDisplayer";
import { Vector } from "../../maths/vector";
import { NumberRange } from "../../maths/numberRange";
import { ArcBar } from "../../shapes/arcBar";
import { Style } from "../../styles/style";

/**
 * Represents a bar display in an arc format
 */
export class ArcBarDisplayer extends AbstractBoundedDataDisplayer<number> {
  /**
   * @constructor
   * @param {NumberRange} valueRange - the value range possible to display
   * @param {ArcBar} arcBar - the arc bar that will show the value
   */
  constructor(valueRange: NumberRange, protected readonly arcBar: ArcBar) {
    super(valueRange);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: number): void {
    this.setValueOf(data, this.arcBar);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.arcBar.draw(ctx);
  }
}
