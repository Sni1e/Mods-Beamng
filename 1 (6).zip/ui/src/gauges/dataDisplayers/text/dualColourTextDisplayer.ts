import { TextDisplayer } from "./textDisplayer";
import { Text } from "../../../text/text";
import { ColourPriority } from "../../../colours/colourPriority";

/**
 * Represents text that can be displayed in two different colours, given a particular condition is
 * true or false
 */
export class DualColourTextDisplayer extends TextDisplayer {
  /**
   * @constructor
   * @param {Text} text - the text to displayer
   * @param {ColourPriority} colours - the colours
   */
  constructor(text: Text, private colours: ColourPriority) {
    super(text);
  }

  /**
   * Changes the colour of the text
   * @param {boolean} useFirstColour - whether to use the primary colour
   */
  public changeTextColour(useFirstColour: boolean): void {
    this.text.setColour(this.colours.getFromBool(useFirstColour));
  }
}
