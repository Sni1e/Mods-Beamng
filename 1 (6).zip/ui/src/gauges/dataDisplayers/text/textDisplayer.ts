import { AbstractDataDisplayer } from "../abstractDataDisplayer";
import { Text } from "../../../text/text";

/**
 * Represents an object that can display text
 */
export class TextDisplayer extends AbstractDataDisplayer<string> {
  /**
   * @constructor
   * @param {Text} text - the text to display
   */
  constructor(protected text: Text) {
    super();
  }

  /**
   * @override
   * @inheritDoc
   * @param {string} data - the new text
   */
  public update(data: string): void {
    this.text.setText(data);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.text.draw(ctx);
  }
}
