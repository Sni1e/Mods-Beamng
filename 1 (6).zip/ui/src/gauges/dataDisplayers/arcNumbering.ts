import { Moveable } from "../../moveable";
import { Vector } from "../../maths/vector";
import { NumberRange } from "../../maths/numberRange";
import { Font } from "../../text/font";
import { Style } from "../../styles/style";
import { Text } from "../../text/text";

/**
 * Represents a list of numbers, arranged in an arc
 */
export class ArcNumbering extends Moveable {
  private colour: string[];
  private text: Text[];

  /**
   * @constructor
   * The colour of the numbering text defaults to white.
   * @param {Vector} centre - the centre of the display
   * @param {number} radius - the distance between the centre and each number
   * @param {[number]} numbers - the list of numbers to display
   * @param {NumberRange} arcRange - the angle range that the numbers will occupy
   * @param {Font} font - the font to display the numbering text in
   * @param {CanvasRenderingContext2D} ctx - the canvas to draw to
   * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
   */
  constructor(
    centre: Vector,
    private readonly radius: number,
    private readonly numbers: number[],
    private readonly arcRange: NumberRange,
    private readonly font: Font,
    private readonly ctx: CanvasRenderingContext2D,
    private readonly drawStartAndEndNumbers = true
  ) {
    super(centre);
    /** @type string[] */
    this.colour = Array(numbers.length).fill("white");
    this.text = this.generateText();
  }

  /**
   * Sets the colour of the numbering text
   * @param {string | string[]} colour - the colour(s) to set. If an array is given, then every
   * number will be given the corresponding colour in that array. The length of the array must
   * therefore be equal to the number of numbers
   */
  public setColour(colour: string | string[]): void {
    if (typeof colour === "string") {
      this.colour = Array(this.numbers.length).fill(colour);
    } else if (Array.isArray(colour)) {
      this.colour = colour;
    }

    this.text = this.generateText();
  }

  /**
   * Returns the position of one of the numbers on the gauge, rotated to the position it will appear
   * at
   * @param {number} numberIndex - the index of the number
   * @return {Vector} the position of this number
   */
  private getRotatePosition(numberIndex: number): Vector {
    const INITPOS = new Vector(this.radius, 0);
    const ANGLERANGE = this.arcRange.getDifference();

    // -1 to show a number at both ends
    let percentAlong = numberIndex / (this.numbers.length - 1);
    // Add the start angle to ensure the first number starts at the lowest angle
    let angle = percentAlong * ANGLERANGE + this.arcRange.getLower();
    return INITPOS.rotateAboutOrigin(angle);
  }

  /**
   * Returns the position a particular number will be placed at
   * @param {number} numberIndex - the index of the number
   * @returns {Vector} the position this number will be placed at
   */
  private getNumberPosition(numberIndex: number): Vector {
    let totalPos = new Vector();
    // Get the position rotated around the centre
    totalPos.add(this.getRotatePosition(numberIndex));
    // Add in the font fixing for centring
    // totalPos.add(this.font.getCentreFix(this.CTX, numberIndex.toString()));
    // And translate it to the centre of the displayer
    totalPos.add(this.centre);
    return totalPos;
  }

  /**
   * Generates and returns the list of numbers in text form
   * @returns {Text[]} the numbers in text form
   */
  private generateText(): Text[] {
    let text = [];

    for (let i = 0; i < this.numbers.length; i++) {
      if (!this.drawStartAndEndNumbers && (i === 0 || i === this.numbers.length - 1)) continue;

      let position = this.getNumberPosition(i);
      let style = Style.noStrokeFill(this.colour[i]);

      let numText = new Text(this.font, this.numbers[i].toString(), position, style);
      text.push(numText);
    }

    return text;
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.text.forEach(text => text.draw(ctx));
  }
}
