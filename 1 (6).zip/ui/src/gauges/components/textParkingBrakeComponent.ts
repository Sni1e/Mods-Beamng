import { AbstractTextDisplayerComponent } from "./abstractTextDisplayerComponent";
import { DualColourTextDisplayer } from "../dataDisplayers/text/dualColourTextDisplayer";

/**
 * Represents a textual representation of the parking brake
 */
export class TextParkingBrakeComponent extends AbstractTextDisplayerComponent<DualColourTextDisplayer, boolean> {
  /**
   * @constructor
   * @param {DualColourTextDisplayer} textDisplayer - the displayer
   */
  constructor(textDisplayer: DualColourTextDisplayer) {
    super(textDisplayer);
  }

  /**
   * @override
   * @inheritDoc
   * @param {boolean} data - whether the parking brake is on
   */
  public update(data: boolean): void {
    this.textDisplayer.changeTextColour(data);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.textDisplayer.draw(ctx);
  }
}
