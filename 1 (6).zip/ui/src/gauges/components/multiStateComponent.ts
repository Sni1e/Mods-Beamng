import { AbstractDataDisplayer } from "../dataDisplayers/abstractDataDisplayer";
import { Style } from "../../styles/style";
import { AbstractShape } from "../../shapes/abstractShape";


export class MultiStateComponent extends AbstractDataDisplayer<number> {
  protected currentState: Style;

  constructor(protected states: Style[], protected object: AbstractShape) {
    super();
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.object.draw(ctx);
  }

  /**
   * @override
   * @inheritDoc
   * @param {number} data - a number that represents the state to change to. Should be a number between `0->n`, where
   * `n` is the the number of different states this component has minus 1.
   */
  public update(data: number): void {
    let newState = this.states[data];

    if (this.currentState === newState) return;

    this.object = this.object.changeStyling(newState);
    this.currentState = newState;
  }
}