import { AbstractDataDisplayer } from "../dataDisplayers/abstractDataDisplayer";
import { TextDisplayer } from "../dataDisplayers/text/textDisplayer";
import { Quantity } from "../../maths/units/quantity";

/**
 * Represents a component that displays a value and the units it is in
 */
export class UnitisedComponent extends AbstractDataDisplayer<number> {
  /**
   * @constructor
   * @param {TextDisplayer} valueDisplayer - the displayer for the value
   * @param {TextDisplayer} unitDisplayer - the displayer for the unit
   * @param {Quantity} quantity - the quantity type for displaying and converting values
   */
  constructor(
    protected valueDisplayer: TextDisplayer,
    protected unitDisplayer: TextDisplayer,
    protected quantity: Quantity
  ) {
    super();
  }

  /**
   * @return {Quantity} the unit instance
   */
  public getQuantity(): Quantity {
    return this.quantity;
  }

  /**
   * @returns {number} the index of the current unit
   */
  public getIndexOfCurrent(): number {
    return this.quantity.getUnitIndex();
  }

  /**
   * Sets the selected unit to the unit at the given index
   * @param {number} index - the index to set
   */
  public setIndexOfCurrent(index: number): void {
    this.quantity.setUnitIndex(index);
  }

  /**
   * Cycles the unit
   */
  public cycleUnit(): void {
    this.quantity.cycleUnit();
    this.unitDisplayer.update(this.quantity.getUnitName());
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: number): void {
    let conversion = this.quantity.convert(data);

    this.valueDisplayer.update(conversion.value);
    this.unitDisplayer.update(conversion.units);
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.valueDisplayer.draw(ctx);
    this.unitDisplayer.draw(ctx);
  }
}
