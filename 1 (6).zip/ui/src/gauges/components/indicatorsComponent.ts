import { AbstractDataDisplayer } from "../dataDisplayers/abstractDataDisplayer";
import { AbstractShape } from "../../shapes/abstractShape";
import { Style } from "../../styles/style";
import { ColourPriority } from "../../colours/colourPriority";
import { IndicatorData } from "../../vehicles/data";
import { MultiStateComponent } from "./multiStateComponent";

/**
 * Represents a component that can highlight two shapes representing vehicle indicators
 */
export class IndicatorsComponent extends AbstractDataDisplayer<IndicatorData> {
  protected static readonly COLOURS: ColourPriority = new ColourPriority("grey", "#00FF00");

  protected leftIndicator: MultiStateComponent;
  protected rightIndicator: MultiStateComponent;

  /**
   * @constructor
   * Note that any styling applied to either indicator will be overridden
   * @param {AbstractShape} leftIndicator - the left indicator
   * @param {AbstractShape} rightIndicator - the right indicator
   * @param {Style} baseStyle - the base style, supplying whether the indicators will be filled and
   * any stroke applicable. The colour is overridden here.
   */
  constructor(
    leftIndicator: AbstractShape,
    rightIndicator: AbstractShape,
    baseStyle: Style
  ) {
    super();
    this.initIndicators(leftIndicator, rightIndicator, baseStyle);
  }

  /**
   * Creates two styles where the stroke width and whether they are filled are determined by the passed style, and whose
   * colours are the primary and secondary colour of {@link IndicatorsComponent.COLOURS} respectively
   * @param {Style} baseStyle - the base style
   * @returns {Style[]} the two styles created
   * @private
   */
  private static createStyles(baseStyle: Style): Style[] {
    return [
      baseStyle.changeColour(IndicatorsComponent.COLOURS.getPrimary()),
      baseStyle.changeColour(IndicatorsComponent.COLOURS.getSecondary())
    ];
  }

  /**
   * Creates the indicators with the given shapes and base style
   * @param {AbstractShape} leftShape - the left indicator shape
   * @param {AbstractShape} rightShape - the right indicator shape
   * @param {Style} baseStyle - the base style to apply (stroke width and whether it is filled are used)
   * @private
   */
  private initIndicators(leftShape: AbstractShape, rightShape: AbstractShape, baseStyle: Style): void {
    this.leftIndicator = new MultiStateComponent(IndicatorsComponent.createStyles(baseStyle), leftShape);
    this.rightIndicator = new MultiStateComponent(IndicatorsComponent.createStyles(baseStyle), rightShape);

    // Ensure correct starting style
    this.leftIndicator.update(0);
    this.rightIndicator.update(0);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: IndicatorData): void {
    this.leftIndicator.update(Math.floor(data.left));
    this.rightIndicator.update(Math.floor(data.right));
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.leftIndicator.draw(ctx);
    this.rightIndicator.draw(ctx);
  }
}
