import { AbstractUnitisedBuilder } from "./abstractUnitisedBuilder";
import { Text } from "../../../../text/text";
import { Vector } from "../../../../maths/vector";

export class FloatingUnitisedBuilder extends AbstractUnitisedBuilder {
  protected unitPosition: Vector;
  protected valuePosition: Vector;

  public setUnitPosition(unitPosition: Vector): this {
    this.unitPosition = unitPosition;
    return this;
  }

  public setValuePosition(valuePosition: Vector): this {
    this.valuePosition = valuePosition;
    return this;
  }

  protected override createUnitText(): Text {
    return this.createText(this.unitFontSize, this.unitPosition, this.getUnitStyle());
  }

  protected override createValueText(): Text {
    return this.createText(this.valueFontSize, this.valuePosition, this.getValueStyle());
  }
}