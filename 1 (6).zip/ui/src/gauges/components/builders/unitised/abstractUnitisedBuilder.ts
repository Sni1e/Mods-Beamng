import { AbstractComponentBuilder } from "../abstractComponentBuilder";
import { Vector } from "../../../../maths/vector";
import { UnitisedComponent } from "../../unitisedComponent";
import { TextDisplayer } from "../../../dataDisplayers/text/textDisplayer";
import { Text } from "../../../../text/text";
import { Font } from "../../../../text/font";
import { BaseStyle } from "../../../../styles/baseStyle";
import { Quantity } from "../../../../maths/units/quantity";
import { applyMixins } from "../../../../mixins/multiInherit";
import { HasFontName } from "../../../../mixins/builders/hasFontName";
import { Style } from "../../../../styles/style";
import { HasColourScheme } from "../../../../mixins/builders/hasColourScheme";

/**
 * Represents a builder that can create an unitised component
 */
export abstract class AbstractUnitisedBuilder extends AbstractComponentBuilder<UnitisedComponent> {
  protected quantity: Quantity;
  protected valueFontSize: number;
  protected unitFontSize: number;

  public setQuantity(value: Quantity): this {
    this.quantity = value;
    return this;
  }

  public setValueFontSize(value: number): this {
    this.valueFontSize = value;
    return this;
  }

  public setUnitFontSize(value: number): this {
    this.unitFontSize = value;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractUnitisedBuilder): AbstractUnitisedBuilder {
    this.setQuantity(builder.quantity);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): UnitisedComponent {
    return new UnitisedComponent(
      new TextDisplayer(this.createValueText()),
      new TextDisplayer(this.createUnitText()),
      this.quantity
    );
  }

  /**
   * @return {BaseStyle} the style for the unit text
   */
  protected getUnitStyle(): BaseStyle {
    return Style.noStrokeFill(this.colourScheme.UNIT);
  }

  /**
   * @return {BaseStyle} the style for the value text
   */
  protected getValueStyle(): BaseStyle {
    return Style.noStrokeFill(this.colourScheme.VALUE);
  }

  /**
   * Creates a text object
   * @param {number} fontSize - the size of the font to use
   * @param {Vector} position - the position to place the text
   * @param {BaseStyle} style - the styling to apply
   * @return {Text} the text created
   */
  protected createText(fontSize: number, position: Vector, style: BaseStyle): Text {
    let font = new Font(this.fontName, fontSize, true);
    return new Text(font, "", position, style);
  }

  /**
   * Creates the value text
   * @returns {Text} the text created
   */
  protected abstract createValueText(): Text;

  /**
   * Creates the unit text
   * @returns {Text} the text created
   */
  protected abstract createUnitText(): Text;
}

export interface AbstractUnitisedBuilder extends HasFontName, HasColourScheme {}
applyMixins(AbstractUnitisedBuilder, [HasFontName, HasColourScheme]);