import { Vector } from "../../../../maths/vector";
import { ColourScheme } from "../../../../colours/colourScheme";
import { Text } from "../../../../text/text";
import { applyMixins } from "../../../../mixins/multiInherit";
import { HasFontName } from "../../../../mixins/builders/hasFontName";
import { AbstractUnitisedBuilder } from "./abstractUnitisedBuilder";

/**
 * Represents a builder that can build an unitised component that has its 'value' text stacked on top of its 'unit' text
 */
export class StackedUnitisedBuilder extends AbstractUnitisedBuilder {
  protected colourScheme: ColourScheme;
  // The distance between the value and unit texts
  protected padding: number;

  public setPadding(value: number): this {
    this.padding = value;
    return this;
  }

  /**
   * Returns the position of one of the texts, given whether they are the top or bottom element
   * @param {boolean} isTop - whether the position returned will be for the top element
   * @return {Vector} the position
   */
  protected getPosition(isTop: boolean): Vector {
    let yCoord = isTop ? -this.padding : this.padding;
    return Vector.add(this.centre, new Vector(0, yCoord));
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createValueText(): Text {
    return this.createText(this.valueFontSize, this.getPosition(true), this.getValueStyle());
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createUnitText(): Text {
    return this.createText(this.unitFontSize, this.getPosition(false), this.getUnitStyle());
  }

  /**
   * @override
   * @inheritDoc
   */

  public useAsBase(builder: StackedUnitisedBuilder): StackedUnitisedBuilder {
    super.useAsBase(builder);
    this.setPadding(builder.padding);
    this.setColourScheme(builder.colourScheme);
    this.setUnitFontSize(builder.unitFontSize);
    this.setValueFontSize(builder.valueFontSize);
    this.setFontName(builder.fontName);
    return this;
  }
}

export interface StackedUnitisedBuilder extends HasFontName {}
applyMixins(StackedUnitisedBuilder, [HasFontName]);