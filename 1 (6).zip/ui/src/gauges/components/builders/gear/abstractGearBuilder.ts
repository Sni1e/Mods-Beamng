import { AbstractComponentBuilder } from "../abstractComponentBuilder";
import { GearComponent } from "../../gearComponent";
import { TextDisplayer } from "../../../dataDisplayers/text/textDisplayer";
import { AbstractShape } from "../../../../shapes/abstractShape";
import { HasColourScheme } from "../../../../mixins/builders/hasColourScheme";
import { applyMixins } from "../../../../mixins/multiInherit";
import { Drawable } from "../../../../drawable";

export abstract class AbstractGearBuilder extends AbstractComponentBuilder<GearComponent> {
  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractGearBuilder): AbstractGearBuilder {
    super.useAsBase(builder);
    this.setColourScheme(builder.colourScheme);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): GearComponent {
    return new GearComponent(this.createTextDisplayer(), this.createShiftPrompt());
  }

  /**
   * Creates the shift prompter
   * @returns {Drawable} the shift prompt created
   */
  protected abstract createShiftPrompt(): Drawable;

  /**
   * Creates the text displayer for displaying the gear
   * @returns {TextDisplayer} the text displayer created
   */
  protected abstract createTextDisplayer(): TextDisplayer;
}

export interface AbstractGearBuilder extends HasColourScheme {}
applyMixins(AbstractGearBuilder, [HasColourScheme]);