import { AbstractGearBuilder } from "./abstractGearBuilder";
import { Vector } from "../../../../maths/vector";
import { Style } from "../../../../styles/style";
import { Circle } from "../../../../shapes/circle";
import { TextDisplayer } from "../../../dataDisplayers/text/textDisplayer";
import { Text } from "../../../../text/text";
import { HasFont } from "../../../../mixins/builders/hasFont";
import { applyMixins } from "../../../../mixins/multiInherit";

/**
 * Represents a gear component builder that can build a gear component that has a text display for the gear and a ring
 * that outlines this text for a shift prompter
 */
export class RingShifterGearBuilder extends AbstractGearBuilder {
  protected ringRadius: number;
  protected ringWidth: number;

  public setRingRadius(ringRadius: number): this {
    this.ringRadius = ringRadius;
    return this;
  }

  public setRingWidth(ringWidth: number): this {
    this.ringWidth = ringWidth;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createShiftPrompt(): Circle {
    let style = new Style(this.colourScheme.GEAR.getSecondary(), this.ringWidth);
    return new Circle(this.ringRadius, style, this.centre);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTextDisplayer(): TextDisplayer {
    // Manually apply a fix to centre the text properly; automatic way not handled by Beam's version of chrome yet
    const POS = Vector.add(this.centre, new Vector(0, 2));
    const STYLE = Style.noStrokeFill(this.colourScheme.GEAR.getPrimary());

    let text = new Text(this.font, "", POS, STYLE);
    return new TextDisplayer(text);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: RingShifterGearBuilder): RingShifterGearBuilder {
    super.useAsBase(builder);
    this.setFont(builder.font);
    this.setRingWidth(builder.ringWidth);
    this.setRingRadius(builder.ringRadius);
    return this;
  }
}

export interface RingShifterGearBuilder extends HasFont {}
applyMixins(RingShifterGearBuilder, [HasFont]);