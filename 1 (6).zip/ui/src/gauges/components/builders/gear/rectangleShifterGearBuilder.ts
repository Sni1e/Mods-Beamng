import { AbstractGearBuilder } from "./abstractGearBuilder";
import { Rectangle } from "../../../../shapes/rectangle";
import { TextDisplayer } from "../../../dataDisplayers/text/textDisplayer";
import { Vector } from "../../../../maths/vector";
import { Style } from "../../../../styles/style";
import { Text } from "../../../../text/text";
import { HasFont } from "../../../../mixins/builders/hasFont";
import { applyMixins } from "../../../../mixins/multiInherit";

export class RectangleShifterGearBuilder extends AbstractGearBuilder {
  protected rectangle: Rectangle;
  protected textStyle: Style;

  public setRectangle(rectangle: Rectangle): this {
    this.rectangle = rectangle;
    return this;
  }

  public setTextStyle(textStyle: Style): this {
    this.textStyle = textStyle;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createShiftPrompt(): Rectangle {
    return this.rectangle;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTextDisplayer(): TextDisplayer {
    // Manually apply a fix to centre the text properly; automatic way not handled by Beam's version of chrome yet
    const POS = Vector.add(this.centre, new Vector(0, 2));

    if (!this.textStyle) this.textStyle = Style.noStrokeFill(this.colourScheme.GEAR.getPrimary());

    let text = new Text(this.font, "", POS, this.textStyle);
    return new TextDisplayer(text);
  }
}

export interface RectangleShifterGearBuilder extends HasFont {}
applyMixins(RectangleShifterGearBuilder, [HasFont]);