import { AbstractGearBuilder } from "./abstractGearBuilder";
import { Vector } from "../../../../maths/vector";
import { Arrow } from "../../../../shapes/arrow";
import { TextDisplayer } from "../../../dataDisplayers/text/textDisplayer";
import { BaseStyle } from "../../../../styles/baseStyle";
import { HasColourScheme } from "../../../../mixins/builders/hasColourScheme";
import { HasText } from "../../../../mixins/builders/hasText";
import { applyMixins } from "../../../../mixins/multiInherit";

/**
 * Represents a component that can builder a gear component that displays the current gear and a shift prompter in the
 * shape of an arrow on the top left side (relative to the gear text)
 */
export class ArrowShifterGearBuilder extends AbstractGearBuilder {
  protected shifterPosition: Vector;
  protected shifterStyle: BaseStyle;
  protected arrowScale: number;

  public setShifterPosition(shifterPosition: Vector): this {
    this.shifterPosition = shifterPosition;
    return this;
  }

  public setShifterStyle(shifterStyle: BaseStyle): this {
    this.shifterStyle = shifterStyle;
    return this;
  }

  public setArrowScale(arrowScale: number): this {
    this.arrowScale = arrowScale;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createShiftPrompt(): Arrow {
    let arrow = new Arrow(this.arrowScale, this.shifterStyle, this.shifterPosition, this.shifterPosition);
    // Angle up
    arrow.setAngle(1.5 * Math.PI);
    return arrow;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createTextDisplayer(): TextDisplayer {
    return new TextDisplayer(this.text);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: ArrowShifterGearBuilder): ArrowShifterGearBuilder {
    super.useAsBase(builder);
    this.setArrowScale(builder.arrowScale);
    this.setText(builder.text);
    this.setShifterStyle(builder.shifterStyle);
    this.setShifterPosition(builder.shifterPosition);
    return this;
  }
}

export interface ArrowShifterGearBuilder extends HasColourScheme, HasText {}
applyMixins(ArrowShifterGearBuilder, [HasColourScheme, HasText]);