import { Arrow } from "../../../../shapes/arrow";
import { AbstractMirroredIndicatorsBuilder } from "./abstractMirroredIndicatorsBuilder";

/**
 * Represents a builder class for creating an indicators component where both indicators are arrows
 */
export class ArrowIndicatorsBuilder extends AbstractMirroredIndicatorsBuilder {
  // The scale factor of each arrow's size
  protected scale: number;

  public setScale(value: number): this {
    this.scale = value;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  protected createIndicatorShape(isLeft: boolean): Arrow {
    // If left, rotate around 180deg
    let angle = isLeft ? Math.PI : 0;
    let position = this.getPositioning(isLeft);

    let arrow = new Arrow(this.scale, this.unlitStyle, position);
    arrow.setRotationalCentre(position);
    arrow.setAngle(angle);
    return arrow;
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: ArrowIndicatorsBuilder): ArrowIndicatorsBuilder {
    super.useAsBase(builder);
    this.setScale(builder.scale);
    return this;
  }
}
