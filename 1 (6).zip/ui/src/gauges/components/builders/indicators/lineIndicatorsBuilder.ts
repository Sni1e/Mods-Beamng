import { AbstractMirroredIndicatorsBuilder } from "./abstractMirroredIndicatorsBuilder";
import { Line } from "../../../../shapes/line";
import { Vector } from "../../../../maths/vector";

export class LineIndicatorsBuilder extends AbstractMirroredIndicatorsBuilder {
  protected startY: number;
  protected endY: number;

  public setYCoordinates(start: number, end: number): this {
    this.startY = start;
    this.endY = end;
    return this;
  }

  protected override createIndicatorShape(isLeft: boolean): Line {
    let basePos = this.getPositioning(isLeft);

    return new Line(
      Vector.add(basePos, new Vector(0, this.startY)),
      Vector.add(basePos, new Vector(0, this.endY)),
      this.unlitStyle
    );
  }
}