import { IndicatorsComponent } from "../../indicatorsComponent";
import { AbstractShape } from "../../../../shapes/abstractShape";
import { Vector } from "../../../../maths/vector";
import { AbstractIndicatorsBuilder } from "./abstractIndicatorsBuilder";

/**
 * Represents a builder class for creating an indicators component where both indicators are mirror versions of one
 * another
 */
export abstract class AbstractMirroredIndicatorsBuilder extends AbstractIndicatorsBuilder {
  // The total distance between the centre of one indicator and the centre of the other
  protected distance: number;

  public setDistance(value: number): this {
    this.distance = value;
    return this;
  }

  /**
   * Returns the position for either the left or right indicator (controlled using the {@link isLeft} parameter)
   * @param {boolean} isLeft - whether to return te position for the left indicator
   * @returns {Vector} the position for that indicator
   * @protected
   */
  protected getPositioning(isLeft: boolean): Vector {
    const SPACING = this.distance / 2;
    let padding = isLeft ? -SPACING : SPACING;
    return Vector.add(this.centre, new Vector(padding, 0));
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractMirroredIndicatorsBuilder): AbstractMirroredIndicatorsBuilder {
    super.useAsBase(builder);
    this.setCentre(builder.centre);
    this.setDistance(builder.distance);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): IndicatorsComponent {
    return new IndicatorsComponent(
      this.createIndicatorShape(true),
      this.createIndicatorShape(false),
      this.unlitStyle
    );
  }

  /**
   * Creates and returns one of the indicators as a shape.
   * @param {boolean} isLeft - whether to return the left indicator or right
   * @returns {AbstractShape} the indicator created
   * @protected
   */
  protected abstract createIndicatorShape(isLeft: boolean): AbstractShape;
}
