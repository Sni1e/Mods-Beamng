import { AbstractComponentBuilder } from "../abstractComponentBuilder";
import { IndicatorsComponent } from "../../indicatorsComponent";
import { Style } from "../../../../styles/style";

export abstract class AbstractIndicatorsBuilder extends AbstractComponentBuilder<IndicatorsComponent> {
  protected unlitStyle: Style = new Style("", 0, true);

  public setUnlitStyle(unlitStyle: Style): this {
    this.unlitStyle = unlitStyle;
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractIndicatorsBuilder): AbstractIndicatorsBuilder {
    super.useAsBase(builder);
    this.setUnlitStyle(builder.unlitStyle);
    return this;
  }
}