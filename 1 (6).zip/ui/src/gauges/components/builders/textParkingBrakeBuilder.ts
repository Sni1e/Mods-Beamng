import { AbstractComponentBuilder } from "./abstractComponentBuilder";
import { TextParkingBrakeComponent } from "../textParkingBrakeComponent";
import { DualColourTextDisplayer } from "../../dataDisplayers/text/dualColourTextDisplayer";
import { Font } from "../../../text/font";
import { Text } from "../../../text/text";
import { Style } from "../../../styles/style";
import { HasColourScheme } from "../../../mixins/builders/hasColourScheme";
import { HasFont } from "../../../mixins/builders/hasFont";
import { applyMixins } from "../../../mixins/multiInherit";

/**
 * Represents a builder class for creating a text parking brake component
 */
export class TextParkingBrakeBuilder extends AbstractComponentBuilder<TextParkingBrakeComponent> {
  /**
   * Creates the dual colour text displayer
   * @returns {DualColourTextDisplayer} the dual text displayer
   */
  private createPBrakeText(): DualColourTextDisplayer {
    let font = new Font(this.font.FONT_NAME, this.font.FONT_SIZE, true);
    let text = new Text(font, "PARK", this.centre, Style.noStrokeFill(""));
    return new DualColourTextDisplayer(text, this.colourScheme.PARKING_BRAKE);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: TextParkingBrakeBuilder): TextParkingBrakeBuilder {
    this.setCentre(builder.centre);
    this.setFont(builder.font);
    this.setColourScheme(builder.colourScheme);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): TextParkingBrakeComponent {
    return new TextParkingBrakeComponent(this.createPBrakeText());
  }
}

export interface TextParkingBrakeBuilder extends HasColourScheme, HasFont {}
applyMixins(TextParkingBrakeBuilder, [HasColourScheme, HasFont]);