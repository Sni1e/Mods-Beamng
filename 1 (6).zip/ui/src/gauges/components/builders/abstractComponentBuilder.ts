import { AbstractDataDisplayer } from "../../dataDisplayers/abstractDataDisplayer";
import { Builder } from "../../../builder";
import { HasCentre } from "../../../mixins/builders/hasCentre";

/**
 * Represents a base builder class that can build component objects
 * @template T
 */
export abstract class AbstractComponentBuilder<T extends AbstractDataDisplayer<any>> extends HasCentre implements Builder<T> {
  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractComponentBuilder<T>): AbstractComponentBuilder<T> {
    builder.setCentre(this.centre);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public abstract build(): T;
}