import { AbstractFullGaugeBuilder } from "./abstractFullGaugeBuilder";
import { ArcNumbering } from "../../../dataDisplayers/arcNumbering";
import { NumberRange } from "../../../../maths/numberRange";
import { createBasicNumbering } from "../../../../utils/fullGaugeUtils";
import { BoostGaugeComponent } from "../../boostGaugeComponent";
import { HasFontName } from "../../../../mixins/builders/hasFontName";
import { applyMixins } from "../../../../mixins/multiInherit";
import { generateEquidistantValues } from "../../../../utils/arrayUtils";

/**
 * Represents a pressure gauge builder class that can build a FullGauge object
 */
export abstract class AbstractPressureGaugeBuilder extends AbstractFullGaugeBuilder<BoostGaugeComponent> {
  protected maxBoostConverted: number;

  protected maxBoost: number;

  public setMaxBoost(maxBoost: number): this {
    this.maxBoost = maxBoost;
    return this;
  }

  public setMaxBoostConverted(maxBoostConverted: number): this {
    this.maxBoostConverted = maxBoostConverted;
    return this;
  }

  protected createValueRange(): NumberRange {
    return new NumberRange(-this.maxBoost, this.maxBoost);
  }

  /**
   * Creates and returns a numbering system with numbers arranged in an arc
   * @param {number} radius - the radius of the arc
   * @param {number} fontSize - the font size for the numbers
   * @param {number} numNumbers - the number of numbers to show
   * @param {NumberRange} angleRange - the min and max angles for the start and end numbers
   * @param {string} colour - the colour of the text
   * @return {ArcNumbering} the numbering system created
   */
  protected createBasicNumbering(
    radius: number,
    fontSize: number,
    numNumbers: number,
    angleRange: NumberRange,
    colour: string
  ): ArcNumbering {
    let numbers = generateEquidistantValues(
      -this.maxBoostConverted,
      this.maxBoostConverted,
      numNumbers,
      this.getDecimalPlacesToShow()
    );

    let arcNumbering = createBasicNumbering(
      radius,
      fontSize,
      this.fontName,
      numbers,
      this.centre,
      angleRange,
      this.ctx
    );
    arcNumbering.setColour(colour);
    return arcNumbering;
  }

  /**
   * @return {number} the number of decimal places that will be used for the numbering system
   */
  protected getDecimalPlacesToShow(): number {
    return this.maxBoostConverted > 10 ? 0 : 1;
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractPressureGaugeBuilder): AbstractPressureGaugeBuilder {
    super.useAsBase(builder);
    this.setMaxBoostConverted(builder.maxBoostConverted);
    this.setFontName(builder.fontName);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): BoostGaugeComponent {
    return new BoostGaugeComponent(this.createFullGauge());
  }
}

export interface AbstractPressureGaugeBuilder extends HasFontName {}
applyMixins(AbstractPressureGaugeBuilder, [HasFontName]);