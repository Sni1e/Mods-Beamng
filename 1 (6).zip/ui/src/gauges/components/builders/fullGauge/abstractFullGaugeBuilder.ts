import { AbstractComponentBuilder } from "../abstractComponentBuilder";
import { FullGauge } from "../../../dataDisplayers/fullGauge";
import { ArcTicks } from "../../../dataDisplayers/arcTicks/arcTicks";
import { ArcNumbering } from "../../../dataDisplayers/arcNumbering";
import { AbstractGaugePointer } from "../../../dataDisplayers/pointers/abstractGaugePointer";
import { ArcBarDisplayer } from "../../../dataDisplayers/arcBarDisplayer";
import { LimitedArcBarDisplayer } from "../../../dataDisplayers/limitedArcBarDisplayer";
import { AbstractDataDisplayer } from "../../../dataDisplayers/abstractDataDisplayer";
import { applyMixins } from "../../../../mixins/multiInherit";
import { HasFontName } from "../../../../mixins/builders/hasFontName";
import { CanDraw } from "../../../../mixins/builders/canDraw";

/**
 * Represents a class that can builder a component with a full gauge piece
 */
export abstract class AbstractFullGaugeBuilder<T extends AbstractDataDisplayer<any>> extends AbstractComponentBuilder<T> {
  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractFullGaugeBuilder<T>): AbstractFullGaugeBuilder<T> {
    super.useAsBase(builder);
    this.setCtx(builder.ctx);
    return this;
  }

  /**
   * @returns {FullGauge} the full gauge created
   */
  protected createFullGauge(): FullGauge {
    return new FullGauge(this.createTicks(), this.createNumbering(), this.createPointer(), this.createArcBar());
  }

  /**
   * Creates and returns the ticks
   * @returns {ArcTicks} the ticks created
   */
  protected abstract createTicks(): ArcTicks;

  /**
   * Creates and return the numbering system for the gauge
   * @returns {ArcNumbering} the numbering system created
   */
  protected abstract createNumbering(): ArcNumbering;

  /**
   * Creates and returns the pointer for the gauge
   * @returns {AbstractGaugePointer} the pointer created
   */
  protected abstract createPointer(): AbstractGaugePointer;

  /**
   * Creates and returns the arc bar for the gauge
   * @returns {ArcBarDisplayer | LimitedArcBarDisplayer} the arc bar created
   */
  protected abstract createArcBar(): ArcBarDisplayer | LimitedArcBarDisplayer;
}

export interface AbstractFullGaugeBuilder<T extends AbstractDataDisplayer<any>> extends HasFontName, CanDraw {}
applyMixins(AbstractFullGaugeBuilder, [HasFontName, CanDraw]);