import { AbstractFullGaugeBuilder } from "./abstractFullGaugeBuilder";
import { Engine } from "../../../../vehicles/engine";
import { NumberRange } from "../../../../maths/numberRange";
import { ArcNumbering } from "../../../dataDisplayers/arcNumbering";
import { createBasicNumbering } from "../../../../utils/fullGaugeUtils";
import { RPMComponent } from "../../RPMComponent";
import { HasFontName } from "../../../../mixins/builders/hasFontName";
import { applyMixins } from "../../../../mixins/multiInherit";
import { HasColourScheme } from "../../../../mixins/builders/hasColourScheme";
import { arithmeticSeries, partition } from "../../../../utils/arrayUtils";

/**
 * Represents an RPM gauge builder class that can build a FullGauge object
 */
export abstract class AbstractRPMGaugeBuilder extends AbstractFullGaugeBuilder<RPMComponent> {
  // The maximum number of numbers to show for the numbering system
  static MAXNUMS = 15;

  protected engine: Engine;
  // The total range the gauge will be displayed about
  protected arcRange: NumberRange;

  public setEngine(engine: Engine): this {
    this.engine = engine;
    return this;
  }

  public setArcRange(arcRange: NumberRange): this {
    this.arcRange = arcRange;
    return this;
  }

  /**
   * Creates and returns a numbering system with numbers arranged in an arc
   * @param {number} radius - the radius of the arc
   * @param {number} fontSize - the font size for the numbers
   * @param {boolean} drawStartAndEndNumbers - whether to draw the start and end numbers in the list. Defaults to true
   * @return {ArcNumbering} the numbering system created
   */
  protected createBasicNumbering(radius: number, fontSize: number, drawStartAndEndNumbers = true): ArcNumbering {
    let numbering = createBasicNumbering(
      radius,
      fontSize,
      this.fontName,
      this.getNumbersToDisplay(),
      this.centre,
      this.arcRange,
      this.ctx,
      drawStartAndEndNumbers
    );
    numbering.setColour(this.getNumberColours());
    return numbering;
  }

  /**
   * Returns the numbers to display for the engine RPM
   * @return {number[]} the numbers to display
   */
  protected getNumbersToDisplay(): number[] {
    let numbers = this.getRPMNumbers();
    let numNums = numbers.length;

    if (numNums > AbstractRPMGaugeBuilder.MAXNUMS) numbers = this.squishRPMs(numbers);

    return numbers;
  }

  /**
   * Returns the colours for each RPM thousand, with 'white' denoting smaller than max RPM, and
   * 'red' denoting >= max RPM
   * @returns {string[]} the RPM thousand colours
   */
  protected getNumberColours(): string[] {
    return this.getRPMNumbers().map(n => (n * 1000 < this.engine.getMaxRPM() ? "white" : "red"));
  }

  /**
   * Returns the RPM whole thousand numbers for the engine
   * @returns {number[]} the RPM whole thousands
   */
  protected getRPMNumbers(): number[] {
    return arithmeticSeries(0, 1, this.engine.getRedlineThousand() + 1);
  }

  /**
   * @returns {number} the angle at which redline begins for the gauge
   */
  protected getRedlineAngle(): number {
    return this.arcRange.getLinearRatio(this.engine.getRedlineRPMRatio());
  }

  protected createRedlineRange(): NumberRange {
    return new NumberRange(this.getRedlineAngle(), this.arcRange.getUpper());
  }

  protected createValueRange(): NumberRange {
    return new NumberRange(0, this.engine.getRedLineRPM());
  }

  /**
   * Reduces the number of numbers to a more suitable amount. The maximal amount is dictated by <b>
   * AbstractRPMGaugeBuilder.MAXNUMS </b>
   * @param {[number]} numbers - the numbers to reduce
   * @return {[number]} the reduced numbers
   */
  protected squishRPMs(numbers: number[]): number[] {
    const MAXNUMS = AbstractRPMGaugeBuilder.MAXNUMS;
    let gapBetweenTerms = Math.floor(numbers.length / MAXNUMS) + 1;
    return partition(numbers, gapBetweenTerms);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractRPMGaugeBuilder): AbstractRPMGaugeBuilder {
    super.useAsBase(builder);
    this.setFontName(builder.fontName);
    this.setEngine(builder.engine);
    this.setArcRange(builder.arcRange);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public build(): RPMComponent {
    return new RPMComponent(this.createFullGauge());
  }
}

export interface AbstractRPMGaugeBuilder extends HasFontName, HasColourScheme {}
applyMixins(AbstractRPMGaugeBuilder, [HasFontName, HasColourScheme]);