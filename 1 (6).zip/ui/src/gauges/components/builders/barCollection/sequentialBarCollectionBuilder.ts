import { AbstractBarCollectionBuilder, ArcBarData, BRAKE, FUEL, TEMP, THROTTLE } from "./abstractBarCollectionBuilder";
import { ArcBarDisplayer } from "../../../dataDisplayers/arcBarDisplayer";
import { NumberRange } from "../../../../maths/numberRange";
import { ArcBar } from "../../../../shapes/arcBar";

/**
 * Represents a builder than can builder the four arc bars in a row
 */
export class SequentialBarCollectionBuilder extends AbstractBarCollectionBuilder {
  protected startingRadius: number;
  protected spacing: number;
  protected arcRange: NumberRange;
  protected invertArcDirection = false;

  public setStartingRadius(startingRadius: number): this {
    this.startingRadius = startingRadius;
    return this;
  }

  public setSpacing(spacing: number): this {
    this.spacing = spacing;
    return this;
  }

  public setArcRange(arcRange: NumberRange): this {
    this.arcRange = arcRange;
    return this;
  }

  public setInvertArcDirection(invertArcDirection: boolean): this {
    this.invertArcDirection = invertArcDirection;
    return this;
  }

  /**
   * Returns the radius at which a particular arc bar will sit at, given its sequence number
   * @param {number} seqNumber - the sequence number (1 -> 4)
   * @returns {number}
   * @private
   */
  private calculateRadius(seqNumber: number): number {
    return this.startingRadius + (seqNumber * this.spacing);
  }

  /**
   * Creates a new ArcBarDisplayer, given the order at which is sits in sequence and the data about the arc bar
   * @param {number} seqNumber - the sequence number (1 -> 4)
   * @param {ArcBarData} arcBarData - the arc bar data
   * @returns {ArcBarDisplayer} the created ArcBarDisplayer
   * @protected
   */
  protected createSequentialGaugeDisplayer(seqNumber: number, arcBarData: ArcBarData): ArcBarDisplayer {
    return this.createGaugeDisplayer(this.calculateRadius(seqNumber), arcBarData, this.arcRange);
  }

  /**
   * @override
   * @inheritDoc
   * Inverts the arc direction with the value of invertArcDirection
   */
  protected createArcBar(radius: number, arcBarData: ArcBarData, arcRange: NumberRange): ArcBar {
    let arcBar = super.createArcBar(radius, arcBarData, arcRange);
    arcBar.invertArcs(this.invertArcDirection);
    return arcBar;
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildTempBar(): ArcBarDisplayer {
    return this.createSequentialGaugeDisplayer(3, TEMP);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildFuelBar(): ArcBarDisplayer {
    return this.createSequentialGaugeDisplayer(4, FUEL);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildBrakeBar(): ArcBarDisplayer {
    return this.createSequentialGaugeDisplayer(2, BRAKE);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildThrottleBar(): ArcBarDisplayer {
    return this.createSequentialGaugeDisplayer(1, THROTTLE);
  }
}