import { ArcBarDisplayer } from "../../../dataDisplayers/arcBarDisplayer";
import { Style } from "../../../../styles/style";
import { NumberRange } from "../../../../maths/numberRange";
import { HasCentre } from "../../../../mixins/builders/hasCentre";
import { BuilderFromBase } from "../../../../builder";
import { ArcBar } from "../../../../shapes/arcBar";

export interface ArcBarData {
  maxValue: number;
  colour: string;
}

// 130 is the maximal value for temp as seen in BeamNG's Tacho2 app
export const TEMP    : ArcBarData = { colour: "#A00", maxValue: 130 };
export const FUEL    : ArcBarData = { colour: "#00F", maxValue:   1 };
export const BRAKE   : ArcBarData = { colour: "#F00", maxValue:   1 };
export const THROTTLE: ArcBarData = { colour: "#0F0", maxValue:   1 };

/**
 * Represents a class that can generate the various bar displayers such as temperature and fuel bars
 */
export abstract class AbstractBarCollectionBuilder extends HasCentre implements BuilderFromBase {
  protected arcWidth: number;
  protected capStyle: "round" | "butt" = "butt";

  public setArcWidth(width: number): this {
    this.arcWidth = width;
    return this;
  }

  public setCapStyle(capStyle: "round" | "butt"): this {
    this.capStyle = capStyle;
    return this;
  }

  /**
   * Creates the arc bar for the gauge displayer
   * @param {number} radius - the radius of the arc bar
   * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
   * @param {NumberRange} arcRange - the range of angles of the arc bar
   * @returns {ArcBar} the arc bar
   */
  protected createArcBar(radius: number, arcBarData: ArcBarData, arcRange: NumberRange): ArcBar {
    let style = new Style(arcBarData.colour, this.arcWidth);
    let bgStyle = new Style("rgba(255, 255, 255, 0.25)", this.arcWidth);

    let arcBar = new ArcBar(radius, arcRange, style, bgStyle, this.centre);
    arcBar.setCapStyle(this.capStyle);
    return arcBar;
  }

  /**
   * Creates the gauge arc displayer, with the given ArcBar
   * @param {ArcBar} arcBar - the arc bar to use
   * @param {number} maxValue - the maximum value of the arc bar
   * @returns {ArcBarDisplayer} the created ArcBarDisplayer
   */
  protected createGaugeDisplayerFromArcBar(arcBar: ArcBar, maxValue: number): ArcBarDisplayer {
    let valRange = new NumberRange(0, maxValue);
    return new ArcBarDisplayer(valRange, arcBar);
  }

  /**
   * Creates a new ArcBarDisplayer. Similar to {@link createGaugeDisplayerFromArcBar}, but creates the ArcBar as well
   * @param {number} radius - the radius of the ArcBar
   * @param {ArcBarData} arcBarData - the arc bar data to use
   * @param {NumberRange} arcRange - the angle range of the ArcBar
   * @returns {ArcBarDisplayer} the created ArcBarDisplayer
   * @protected
   */
  protected createGaugeDisplayer(radius: number, arcBarData: ArcBarData, arcRange: NumberRange): ArcBarDisplayer {
    let arcBar = this.createArcBar(radius, arcBarData, arcRange);
    return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: AbstractBarCollectionBuilder): AbstractBarCollectionBuilder {
    builder.setCentre(this.centre);
    return this;
  }

  /**
   * Builds and returns the throttle bar
   * @return {ArcBarDisplayer} the throttle bar
   */
  public abstract buildThrottleBar(): ArcBarDisplayer;

  /**
   * Builds and returns the brake bar
   * @return {ArcBarDisplayer} the brake bar
   */
  public abstract buildBrakeBar(): ArcBarDisplayer;

  /**
   * Builds and returns the temperature bar
   * @return {ArcBarDisplayer} the temperature bar
   */
  public abstract buildTempBar(): ArcBarDisplayer;

  /**
   * Builds and returns the fuel bar
   * @return {ArcBarDisplayer} the fuel bar
   */
  public abstract buildFuelBar(): ArcBarDisplayer;
}
