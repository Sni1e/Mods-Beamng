import { AbstractBarCollectionBuilder, ArcBarData, BRAKE, FUEL, TEMP, THROTTLE } from "./abstractBarCollectionBuilder";
import { NumberRange } from "../../../../maths/numberRange";
import { ArcBarDisplayer } from "../../../dataDisplayers/arcBarDisplayer";

/**
 * Represents a builder that can build the temperature, fuel, throttle and brake values as arc bars,
 * where pairs of which arc placed along the same radius.
 * The throttle and brake bars default to being inverted while the temperature and fuel bars default
 * to being normal. This can be inverted with the {@link invertArcDirections} flag in the constructor
 */
export class PairedBarCollectionBuilder extends AbstractBarCollectionBuilder {
  protected innerRadius: number;
  protected outerRadius: number;
  protected invertArcDirections = false;
  // The arc range for the temperature and fuel arc bars
  protected arcRangeTF: NumberRange;
  // The arc range for the throttle and brake arc bars
  protected arcRangeTB: NumberRange;

  public setInnerRadius(innerRadius: number): this {
    this.innerRadius = innerRadius;
    return this;
  }

  public setOuterRadius(outerRadius: number): this {
    this.outerRadius = outerRadius;
    return this;
  }

  public setTempFuelArcRange(arcRangeTF: NumberRange): this {
    this.arcRangeTF = arcRangeTF;
    return this;
  }

  public setThottleBrakeArcRange(arcRangeTB: NumberRange): this {
    this.arcRangeTB = arcRangeTB;
    return this;
  }

  public setInvertArcDirections(invert: boolean): this {
    this.invertArcDirections = invert;
    return this;
  }

  /**
   * Creates an end gauge displayer, positioned at the end of the inner part of the gauge
   * @param {number} radius - the radius of the arc bar
   * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
   * @returns {ArcBarDisplayer} the created arc bar displayer
   */
  private createEndGaugeDisplayer(radius: number, arcBarData: ArcBarData): ArcBarDisplayer {
    let arcBar = this.createArcBar(radius, arcBarData, this.arcRangeTB);
    // This arc bar is inverted by default, so un-invert if inversion is set to true
    arcBar.invertArcs(!this.invertArcDirections);
    return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
  }

  /**
   * Creates an end gauge displayer, positioned at the start of the inner part of the gauge
   * @param {number} radius - the radius of the arc bar
   * @param {ArcBarData} arcBarData - the colour and maximum value for this arc bar
   * @returns {ArcBarDisplayer} the created arc bar displayer
   */
  private createStartGaugeDisplayer(radius: number, arcBarData: ArcBarData): ArcBarDisplayer {
    let arcBar = this.createArcBar(radius, arcBarData, this.arcRangeTF);
    arcBar.invertArcs(this.invertArcDirections);
    return this.createGaugeDisplayerFromArcBar(arcBar, arcBarData.maxValue);
  }

  /**
   * @override
   * @inheritDoc
   */
  public useAsBase(builder: PairedBarCollectionBuilder): PairedBarCollectionBuilder {
    super.useAsBase(builder);
    this.setInvertArcDirections(builder.invertArcDirections);
    this.setArcWidth(builder.arcWidth);
    this.setInnerRadius(builder.innerRadius);
    this.setOuterRadius(builder.outerRadius);
    this.setCapStyle(builder.capStyle);
    this.setTempFuelArcRange(builder.arcRangeTF);
    this.setThottleBrakeArcRange(builder.arcRangeTB);
    return this;
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildTempBar(): ArcBarDisplayer {
    return this.createStartGaugeDisplayer(this.innerRadius, TEMP);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildFuelBar(): ArcBarDisplayer {
    return this.createStartGaugeDisplayer(this.outerRadius, FUEL);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildBrakeBar(): ArcBarDisplayer {
    return this.createEndGaugeDisplayer(this.innerRadius, BRAKE);
  }

  /**
   * @override
   * @inheritDoc
   */
  public buildThrottleBar(): ArcBarDisplayer {
    return this.createEndGaugeDisplayer(this.outerRadius, THROTTLE);
  }
}
