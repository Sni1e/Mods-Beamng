import { AbstractGaugeComponent } from "./abstractGaugeComponent";
import { Engine } from "../../vehicles/engine";
import { FullGauge } from "../dataDisplayers/fullGauge";

/**
 * Represents a component that can draw and update the vehicles RPM as a full gauge
 */
export class RPMComponent extends AbstractGaugeComponent<Engine> {
  /**
   * @constructor
   * @param {FullGauge} gauge - the gauge to display the RPM on
   */
  constructor(gauge: FullGauge) {
    super(gauge);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected updateGauge(object: Engine): void {
    let value = object.getCurrentRPM();

    let updateData = {
      ticks: object.getCurrentRPMRatio(),
      pointer: value,
      arcBar: value
    };

    this.gauge.update(updateData);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: Engine): void {
    this.updateGauge(data);
  }
}
