import { TextDisplayer } from "../dataDisplayers/text/textDisplayer";
import { AbstractDataDisplayer } from "../dataDisplayers/abstractDataDisplayer";

/**
 * Represents a component that displays via a text displayer
 * @template T, S
 * T is the text displayer to use
 * S is the type that will be used to perform updates
 */
export abstract class AbstractTextDisplayerComponent<T extends TextDisplayer, S> extends AbstractDataDisplayer<S> {
  /**
   * @constructor
   * @param {T} textDisplayer - the displayer that will display the text
   */
  protected constructor(protected readonly textDisplayer: T) {
    super();
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.textDisplayer.draw(ctx);
  }
}
