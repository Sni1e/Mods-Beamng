import { AbstractGaugeComponent } from "./abstractGaugeComponent";
import { FullGauge } from "../dataDisplayers/fullGauge";
import { Turbo } from "../../vehicles/turbo";

/**
 * Represents a component that can display the current boost value of a turbo object in the form of
 * a full gauge
 */
export class BoostGaugeComponent extends AbstractGaugeComponent<Turbo> {
  /**
   * @constructor
   * @param {FullGauge} fullGauge - the gauge to display on
   */
  constructor(fullGauge: FullGauge) {
    super(fullGauge);
  }

  /**
   * @override
   * @param {Turbo} object - the engine of the vehicle to display info about
   */
  protected updateGauge(object: Turbo): void {
    const VALUE = object.getBoost();

    let updateData = {
      ticks: object.getNormBoost(),
      pointer: VALUE,
      arcBar: VALUE
    };

    this.gauge.update(updateData);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: Turbo): void {
    this.updateGauge(data);
  }
}
