import { AbstractDataDisplayer } from "../dataDisplayers/abstractDataDisplayer";
import { FullGauge } from "../dataDisplayers/fullGauge";

/**
 * Represents a base component that makes up part of the whole gauge
 * @template T
 * T is the object that will update this update with new values
 */
export abstract class AbstractGaugeComponent<T> extends AbstractDataDisplayer<T> {
  /**
   * @constructor
   * @param {FullGauge} gauge - the gauge to display on
   */
  protected constructor(protected gauge: FullGauge) {
    super();
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    this.gauge.draw(ctx);
  }

  /**
   * Updates the gauge to reflect any new changes in the engine
   * @param {T} object - the object to get update values from
   */
  protected abstract updateGauge(object: T): void;
}
