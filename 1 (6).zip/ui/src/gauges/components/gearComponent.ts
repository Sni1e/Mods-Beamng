import { AbstractTextDisplayerComponent } from "./abstractTextDisplayerComponent";
import { TextDisplayer } from "../dataDisplayers/text/textDisplayer";
import { Gearbox } from "../../vehicles/gearbox";
import { Drawable } from "../../drawable";

type GearboxData = { gearbox: Gearbox; shouldShift: boolean };

/**
 * Represents a component that displays the current gear
 */
export class GearComponent extends AbstractTextDisplayerComponent<TextDisplayer, GearboxData> {
  protected shouldShift = false;

  /**
   * @constructor
   * @param {TextDisplayer} textDisplayer - the text displayer that will display the gear
   * @param {Drawable} shiftPrompt - the shift prompter
   */
  constructor(textDisplayer: TextDisplayer, protected readonly shiftPrompt: Drawable) {
    super(textDisplayer);
  }

  /**
   * @override
   * @inheritDoc
   */
  public update(data: GearboxData): void {
    this.textDisplayer.update(data.gearbox.getGearName());
    this.shouldShift = data.shouldShift;
  }

  /**
   * @override
   * @inheritDoc
   */
  public draw(ctx: CanvasRenderingContext2D): void {
    if (this.shouldShift) this.shiftPrompt.draw(ctx);

    super.draw(ctx);
  }
}
