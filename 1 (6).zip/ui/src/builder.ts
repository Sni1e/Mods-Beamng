interface BuilderBase<T> {
  /**
   * Sets properties from the given builder to this builder
   * @returns {Builder} this builder instance
   */
  useAsBase(builder: T): T;
}

/**
 * A class implementing this interface can build an object of the given type with the values set as part of the classic
 * builder pattern.
 * @template T
 * T is the type of object that can be built
 */
export interface Builder<T> extends BuilderBase<Builder<T>> {
  /**
   * Builds and returns the object with the values set
   * @returns {T} the object built from the values set
   */
  build(): T;
}

export type BuilderFromBase = BuilderBase<BuilderFromBase>
