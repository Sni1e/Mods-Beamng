import { Drawable } from "./drawable";
import { Vector } from "./maths/vector";

/**
 * Represents an object that can be moved
 */
export abstract class Moveable extends Drawable {
  /**
   * @constructor
   * @param {Vector} [centre] - the centre point of the object. Defaults to (0,0)
   */
  protected constructor(protected centre: Vector = new Vector()) {
    super();
  }

  /**
   * @param {Vector} centre - the new centre to set the object to
   */
  public setCentre(centre: Vector): void {
    this.centre = centre;
  }
}
