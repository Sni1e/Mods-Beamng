export interface PrepCtx {
  /**
   * Applies styling to a drawn-on canvas context and renders it
   * @param {CanvasRenderingContext2D} ctx - the rendering context of the canvas to draw on
   */
  apply(ctx: CanvasRenderingContext2D): void;
}

/**
 * Represents a base style
 */
export interface BaseStyle extends PrepCtx {
  /**
   * Sets the values to the canvas object, but does not apply them
   * @param {CanvasRenderingContext2D} ctx - the canvas object to set the values to
   */
  setVars(ctx: CanvasRenderingContext2D): void;
}
