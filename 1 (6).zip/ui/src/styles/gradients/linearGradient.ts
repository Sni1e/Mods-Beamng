import { Vector } from "../../maths/vector";
import { AbstractGradient, ColourStop } from "./abstractGradient";

export class LinearGradient extends AbstractGradient {
  /**
   * @constructor
   * @param {Vector} startPos - the start position of the gradient
   * @param {Vector} endPos - the end position of the gradient
   * @param {string[]} colourStops - the colours in the gradient
   */
  constructor(
    private readonly startPos: Vector,
    private readonly endPos: Vector,
    colourStops: ColourStop[],
  ) {
    super(colourStops);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected initGradient(ctx: CanvasRenderingContext2D): CanvasGradient {
    return ctx.createLinearGradient(this.startPos.x(), this.startPos.y(), this.endPos.x(), this.endPos.y());
  }
}
