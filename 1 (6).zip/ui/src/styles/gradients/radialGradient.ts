import { Vector } from "../../maths/vector";
import { AbstractGradient, ColourStop } from "./abstractGradient";

export class RadialGradient extends AbstractGradient {
  /**
   * @constructor
   * @param {Vector} centre - the start position of the gradient
   * @param {number} startRadius - the start radius of the circle
   * @param {number} endRadius - the end radius of the circle
   * @param {string[]} colourStops - the colours in the gradient
   */
  constructor(
    private readonly centre: Vector,
    private readonly startRadius: number,
    private readonly endRadius: number,
    colourStops: ColourStop[]
  ) {
    super(colourStops);
  }

  /**
   * @override
   * @inheritDoc
   */
  protected initGradient(ctx: CanvasRenderingContext2D): CanvasGradient {
    return ctx.createRadialGradient(
      this.centre.x(),
      this.centre.y(),
      this.startRadius,
      this.centre.x(),
      this.centre.y(),
      this.endRadius
    );
  }
}