export interface ColourStop {
  colour: string;
  offset: number;
}

export abstract class AbstractGradient {
  /**
   * @constructor
   * @param {string[]} colourStops - the colours in the gradient
   */
  protected constructor(protected readonly colourStops: ColourStop[]) {}

  /**
   * Creates a set of ColourStop objects from the given colours where each colour is equally spaced, in the given order
   * @param {string[]} colours - the colours to make into ColourStops
   * @returns {ColourStop[]} the evenly distributed colours
   */
  public static distributeEvenly(colours: string[]): ColourStop[] {
    return colours.map((colour, i, array) => {
      return { colour: colour, offset: i / array.length };
    });
  }

  /**
   * Initialises the CanvasGradient and returns the completed gradient with all colours added to iut
   * @param {CanvasRenderingContext2D} ctx - the object to use to create the gradient
   * @returns {CanvasGradient} the gradient created
   */
  public createGradient(ctx: CanvasRenderingContext2D): CanvasGradient {
    let grad = this.initGradient(ctx);
    this.colourStops.forEach(colourStop => grad.addColorStop(colourStop.offset, colourStop.colour));
    return grad;
  }

  /**
   * Creates and returns a new CanvasGradient object from the given CanvasRenderingContext2D
   * @param {CanvasRenderingContext2D} ctx - the object to use to create the gradient
   * @returns {CanvasGradient} the gradient created
   * @protected
   */
  protected abstract initGradient(ctx: CanvasRenderingContext2D): CanvasGradient;
}