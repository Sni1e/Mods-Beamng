import { BaseStyle } from "./baseStyle";

/**
 * Represents a style which can be applied to shapes and objects being drawn on a canvas
 */
export class Style implements BaseStyle {
  /**
   * @constructor
   * @param {string | CanvasGradient} STROKE_COLOUR - the colour of the stroke
   * @param {number} LINE_WIDTH - the width of the line/outline
   * @param {boolean} [FILLED] - whether the shape will be filled (fill colour will be the same as stroke
   * colour). Defaults to false
   */
  constructor(
    public readonly STROKE_COLOUR: string | CanvasGradient,
    public readonly LINE_WIDTH: number,
    public readonly FILLED = false
  ) {}

  /**
   * Returns a Style object of the specified colour that has a 1px stroke and is filled
   * @param {string} strokeColour - the colour of the stroke. Can be either RGB/RGBA or colour
   * name
   * @returns {Style} the style object created
   */
  public static unitStrokeFill(strokeColour: string | CanvasGradient): Style {
    return new Style(strokeColour, 1, true);
  }

  /**
   * Returns a Style object that is filled with the specified colour and that does not have a
   * stroke applied to it
   * @param {string} fillColour - the fill colour. Can be either RGB/RGBA or colour name
   * @returns {Style} the style object created
   */
  public static noStrokeFill(fillColour: string | CanvasGradient): Style {
    return new Style(fillColour, 0, true);
  }

  /**
   * @return {Style} a Style object with black colour, 0 stroke width and unfilled
   */
  public static default(): Style {
    return new Style("black", 0, false);
  }

  public changeColour(newColour: string): Style {
    return new Style(newColour, this.LINE_WIDTH, this.FILLED);
  }

  public changeLineWidth(newLineWidth: number): Style {
    return new Style(this.STROKE_COLOUR, newLineWidth, this.FILLED);
  }

  public changeIsFilled(isFilled: boolean): Style {
    return new Style(this.STROKE_COLOUR, this.LINE_WIDTH, isFilled);
  }

  /**
   * @override
   * @inheritDoc
   */
  public setVars(ctx: CanvasRenderingContext2D): void {
    if (this.FILLED) {
      ctx.fillStyle = this.STROKE_COLOUR;
    } else {
      ctx.strokeStyle = this.STROKE_COLOUR;
      ctx.lineWidth = this.LINE_WIDTH;
    }
  }

  /**
   * @Override
   * @inheritDoc
   */
  public apply(ctx: CanvasRenderingContext2D): void {
    this.setVars(ctx);

    if (this.FILLED) ctx.fill();
    else ctx.stroke();
  }
}
