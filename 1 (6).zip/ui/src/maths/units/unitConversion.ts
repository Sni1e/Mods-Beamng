import { wrapAdd } from "../../utils/mathsUtils";
import { ConvertableUnit } from "./convertableUnit";
import { Converter } from "./converter";

export class UnitConversion implements Converter<number, number> {
  /**
   * @constructor
   * @param {ConvertableUnit[]} quantity - the quantity that will be returned
   * @param {number} selected - the currently selected unit inside the quantity instance. Defaults to 0
   */
  constructor(private readonly quantity: ConvertableUnit[], private selected = 0) {}

  /**
   * @override
   * Converts a value (in ms^-1) to the selected unit
   * @param {number} value - the value (in ms^-1) to convert
   * @returns {number} the converted number
   */
  public convert(value: number): number {
    let unit = this.quantity[this.selected];
    return value * unit.conversionFactor;
  }

  /**
   * Selects the next unit, wrapping around to the first unit if it is at the last unit currently
   */
  public cycleUnit(): void {
    this.selected = wrapAdd(this.selected, 1, this.quantity.length);
  }

  /**
   * Sets the selected unit
   * @param {number} selected - the index of the selected unit
   * @throws RangeError
   */
  public setSelected(selected: number): void {
    if (selected < 0 || selected >= this.quantity.length)
      throw RangeError("Index must be > 0 and < the number of units");
    this.selected = selected;
  }

  /**
   * @returns {number} the index of the currently selected unit
   */
  public getIndex(): number {
    return this.selected;
  }

  /**
   * @returns {string} the name of the currently selected unit
   */
  public getUnitName(): string {
    return this.quantity[this.selected].name;
  }

  /**
   * @returns {ConvertableUnit} the unit currently in use
   */
  public getUnit(): ConvertableUnit {
    return this.quantity[this.selected];
  }

  /**
   * Converts a value (in ms^-1) to the selected unit
   * @param {ConvertableUnit} unit - the selected unit to convert into
   * @param {number} value - the value (in ms^-1) to convert
   * @returns {number} the converted number in {@link unit} units
   */
  public static convert(unit: ConvertableUnit, value: number): number {
    return value * unit.conversionFactor;
  }
}
