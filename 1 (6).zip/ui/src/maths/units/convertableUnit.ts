export interface ConvertableUnit {
  name: string;
  conversionFactor: number;
}
