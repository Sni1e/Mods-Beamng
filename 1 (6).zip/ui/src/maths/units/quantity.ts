import { ConvertableUnit } from "./convertableUnit";
import { Formatter } from "../../formatting/formatter";
import { UnitConversion } from "./unitConversion";
import { Converter } from "./converter";

type ConvertedUnit = { value: string; units: string };

export class Quantity implements Converter<number, ConvertedUnit> {
  /**
   * @constructor
   * @param {UnitConversion} unitConversion - the conversion unit for converting values to their respective unit
   * @param {Formatter<any, string>} formatter - the formatter to apply formatting to the converted unit
   */
  constructor(private readonly unitConversion: UnitConversion, private formatter: Formatter<any, string>) {}

  /**
   * @override
   * Converts a value (in ms^-1) to the selected unit
   * @param {number} value - the value (in ms^-1) to convert
   * @returns {ConvertedUnit} the converted number, in string format and the units it is in
   */
  public convert(value: number): ConvertedUnit {
    let result = this.unitConversion.convert(value);

    return {
      value: this.formatter.format(result),
      units: this.unitConversion.getUnitName()
    };
  }

  /**
   * @returns {ConvertableUnit} the current unit being used
   */
  public getUnit(): ConvertableUnit {
    return this.unitConversion.getUnit();
  }

  /**
   * @returns {number} the index of the current unit being used
   */
  public getUnitIndex(): number {
    return this.unitConversion.getIndex();
  }

  /**
   * @returns {string} the name of the current unit being used
   */
  public getUnitName(): string {
    return this.unitConversion.getUnitName();
  }

  /**
   * Selects the next unit, wrapping around to the first unit if it is at the last unit currently
   */
  public cycleUnit(): void {
    this.unitConversion.cycleUnit();
  }

  /**
   * Sets the selected unit
   * @param {number} index - the index of the new unit
   * @throws RangeError
   */
  public setUnitIndex(index: number): void {
    this.unitConversion.setSelected(index);
  }

  /**
   * Sets/changes the formatter object to the given one
   * @param {Formatter<any, any>} formatter - the new formatter to use
   */
  public changeFormatter(formatter: Formatter<any, string>): void {
    this.formatter = formatter;
  }

  /**
   * @returns {ConvertableUnit[]} a list of speed units and their conversion factors, relative to ms^-1
   */
  public static speed(): ConvertableUnit[] {
    return [
      { name: "mph", conversionFactor: 2.237 },
      { name: "kph", conversionFactor: 3.600 },
      { name:  "kt", conversionFactor: 1.943 },
      { name: "m/s", conversionFactor: 1.000 }
    ];
  }

  /**
   * @returns {ConvertableUnit[]} a list of boost units and their conversion factors, relative to kPa
   */
  public static boost(): ConvertableUnit[] {
    return [
      { name: "inHg", conversionFactor: 0.295 },
      { name:  "bar", conversionFactor: 0.010 },
      { name:  "psi", conversionFactor: 0.145 },
      { name:  "kPa", conversionFactor: 1.000 }
    ];
  }
}
