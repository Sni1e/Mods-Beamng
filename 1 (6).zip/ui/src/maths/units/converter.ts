/**
 * @template T, S
 * T is the type to convert
 * S is the type after conversion
 */
export interface Converter<T, S> {
  /**
   * Converts a value
   * @param {T} value - the value to convert
   * @returns {S} the converted number
   */
  convert(value: T): S;
}
