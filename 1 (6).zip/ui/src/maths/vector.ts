/**
 * A class representing a 2D vector
 */
export class Vector {
  private array: number[];

  /**
   * @constructor
   * @param {number} x
   * @param {number} y
   */
  constructor(x = 0, y = 0) {
    this.array = [x || 0, y || 0];
  }

  /**
   * Copies a vector and returns its copy
   * @param {Vector} v - the vector to copy
   * @returns {Vector} the copied vector instance
   */
  public static copy(v: Vector): Vector {
    return new Vector(v.array[0], v.array[1]);
  }

  /**
   * Rotates this vector around the origin by a given angle amount.
   * This does not affect this vector and a new vector is returned
   * @param {number} angle - the angle (in radians)
   * @returns {Vector} the resultant vector
   */
  public rotateAboutOrigin(angle: number): Vector {
    let cos = Math.cos(angle);
    let sin = Math.sin(angle);

    return new Vector(this.x() * cos - this.y() * sin, this.x() * sin + this.y() * cos);
  }

  /**
   * Reverse the signs of all elements in the vector
   */
  public negate(): void {
    this.array.forEach(e => -e);
  }

  /**
   *
   * @param {Vector} vector
   * @param {Vector|number} amount
   * @param {(a: number, b: number) => number} func
   * @returns {Vector}
   */
  private static mapOperations(
    vector: Vector,
    amount: Vector | number,
    func: (a: number, b: number) => number
  ): Vector {
    let result = new Vector(vector.array[0], vector.array[1]);

    if (amount instanceof Vector) {
      result.array = result.array.map((v, i) => func(v, amount.array[i]));
    } else {
      result.array = result.array.map(e => func(e, amount));
    }

    return result;
  }

  /**
   * Adds a vector from another or a scalar value
   * @param {Vector} vector - the vector to be added to
   * @param {Vector|number} amount - the vector/scalar to add
   * @returns {Vector} - the resulting vector
   */
  public static add(vector: Vector, amount: Vector | number): Vector {
    return Vector.mapOperations(vector, amount, (e, a) => e + a);
  }

  /**
   * Subtracts a vector from another or a scalar value
   * @param {Vector} vector - the vector to be subtracted from
   * @param {Vector|number} amount - the vector/scalar to subtract
   * @returns {Vector} - the resulting vector
   */
  public static sub(vector: Vector, amount: Vector | number): Vector {
    return Vector.mapOperations(vector, amount, (e, a) => e - a);
  }

  /**
   * Multiples a vector with another or a scalar value
   * @param {Vector} vector - the vector to be subtracted from
   * @param {Vector|number} amount - the vector/scalar to subtract
   * @returns {Vector} - the resulting vector
   */
  public static mult(vector: Vector, amount: Vector | number): Vector {
    return Vector.mapOperations(vector, amount, (e, a) => e * a);
  }

  /**
   * Divides a vector by another or a scalar value
   * @param {Vector} vector - the vector to be divided by
   * @param {Vector|number} amount - the vector/scalar to divide with
   * @returns {Vector} - the resulting vector
   */
  public static div(vector: Vector, amount: Vector | number): Vector {
    return Vector.mapOperations(vector, amount, (e, a) => e / a);
  }

  /**
   * Returns whether this vector and another are the same
   * @param {Vector} v - the other vector
   * @returns {boolean} whether this vector and another are the same
   */
  public isEqual(v: Vector): boolean {
    return this.x() === v.x() && this.y() === v.y();
  }

  /**
   * Clones this vector and returns its copy
   * @returns {Vector} the cloned vector
   */
  public clone(): Vector {
    return Vector.copy(this);
  }

  /**
   * Adds to this vector another vector from another or a scalar value
   * @param {Vector|number} amount - the vector/scalar to add
   */
  public add(amount: Vector | number): void {
    this.array = Vector.add(this, amount).array;
  }

  /**
   * Subtracts this vector by another or a scalar value
   * @param {Vector|number} amount - the vector/scalar to subtract
   */
  public sub(amount: Vector | number): void {
    this.array = Vector.sub(this, amount).array;
  }

  /**
   * Multiples this vector with another or a scalar value
   * @param {Vector|number} amount - the vector/scalar to subtract
   */
  public mult(amount: Vector | number): void {
    this.array = Vector.mult(this, amount).array;
  }

  /**
   * Divides this vector by another or a scalar value
   * @param {Vector|number} amount - the vector/scalar to divide with
   */
  public div(amount: Vector | number): void {
    this.array = Vector.div(this, amount).array;
  }

  /**
   * Normalises this vector
   */
  public normalise(): void {
    let mag = this.mag();

    if (mag > 0) this.div(mag);
  }

  /**
   * Calculates and returns this vector's magnitude
   * @returns {number} the magnitude of this vector
   */
  public mag(): number {
    return Math.sqrt(this.array.reduce((a, b) => Math.pow(a, 2) + Math.pow(b, 2)));
  }

  /**
   * Sets this vector's components to that of another's
   * @param {Vector} vector - the components to copy
   */
  public set(vector: Vector): void {
    this.array = this.array.map((_, i) => vector.array[i]);
  }

  public addX(incX: number): void {
    this.array[0] += incX;
  }

  public addY(incY: number): void {
    this.array[1] += incY;
  }

  public x(): number {
    return this.array[0];
  }

  public y(): number {
    return this.array[1];
  }
}
