/**
 * Represents a range of values between two values
 */
export class NumberRange {
  /**
   * @constructor
   * The lower bound does not have to be smaller than the upper bound, and in which case, the
   * range is considered reversed
   * @param {number} lower - the lower bound of the range
   * @param {number} upper - the upper bound of the range
   */
  constructor(private lower: number, private upper: number) {}

  /**
   * Inverts the bounds such that the upper and lower bound swap
   * @returns {NumberRange}
   */
  public invert(): NumberRange {
    return new NumberRange(this.upper, this.lower);
  }

  public setLower(lower: number): void {
    this.lower = lower;
  }
  public setUpper(upper: number): void {
    this.upper = upper;
  }

  public getLower(): number {
    return this.lower;
  }
  public getUpper(): number {
    return this.upper;
  }

  /**
   * Pads the bounds outwards by a set amount. This lowers the lower bound by the set amount and
   * increases the upper bound by the set amount
   * @param {number} amount - the amount to pad
   */
  public pad(amount: number): void {
    this.lower -= amount;
    this.upper += amount;
  }

  /**
   * Clamps a value between this number range, such that a value lesser than the lower bound
   * will be set to the lower bound and vice versa for the upper bound. A value which lies
   * within the bounds is not affected
   * @param {number} value - the value to clamp
   * @returns {number} the clamped value
   */
  public clampTo(value: number): number {
    return Math.min(Math.max(value, this.lower), this.upper);
  }

  /**
   * Returns the value of the specified distance along this number range.
   * Example: {lower=5, upper=10}.getLinearRatio(0.5) -> 7.5
   * @param distance - the distance along the range
   * @returns {number} the value at {distance} along this range
   */
  public getLinearRatio(distance: number): number {
    return this.lower + distance * (this.upper - this.lower);
  }

  /**
   * Returns the normalised distance along a value appears along this number range.
   * This is a the inverse function of <b>getLinearRatio()</b>.
   * Note that a value greater than or less than the bounds of this range will be clamped as
   * necessary, so that a value lower than the lower-bound returns 0, and a value higher than the
   * higher-bound returns 1.
   * Example: {lower=5, upper=10}.getLinearRatio(7.5) -> 0.5
   * @param value
   * @returns {number}
   */
  public getNormLinearRatio(value: number): number {
    value = this.clampTo(value);
    return (value + Math.abs(this.lower)) / this.getDifference();
  }

  /**
   * @returns {number} the differences between the two bounds
   */
  public getDifference(): number {
    return this.upper - this.lower;
  }

  /**
   * Clones and returns a new range with the same bounds as this one
   * @returns {NumberRange} the cloned range
   */
  public clone(): NumberRange {
    return new NumberRange(this.lower, this.upper);
  }
}
