import { ColourRGB } from "./colourRGB";
import { ColourPriority } from "./colourPriority";

export class ColourScheme {
  /**
   * @constructor
   * @param {string} BASE - the default colour to use when for miscellaneous situations
   * @param {ColourPriority} ARC_BAR - the colouring for the arc bar. The primary is used for the
   * active part of the bar, and the secondary the passive
   * @param {ColourPriority} TICKS - the colouring of the ticks. The primary is used when the
   * current value surpasses a tick and vice versa for the secondary
   * @param {string} VALUE - the colour of the value text
   * @param {string} UNIT - the colour of the unit text
   * @param {string} NUMBERING - the colouring of the numbering system
   * @param {ColourPriority} POINTER - the colour of the pointer. The primary is used for the main
   * part of the pointer and the secondary as an accent
   * @param {string} GLASS - the colour of the glass (expected to be transparent)
   * @param {ColourPriority} GEAR - the colour of the gear. The primary is used for the default text
   * and the secondary for when the shifting should occur
   * @param {ColourPriority} PARKING_BRAKE - the colour of the parking brake. The primary is used for
   * when the parking brake is active and vice versa for the secondary
   * @param {string} BACKGROUND - the default colour to use for background coloring to apps
   */
  constructor(
    public readonly BASE: string,
    public readonly ARC_BAR: ColourPriority,
    public readonly TICKS: ColourPriority,
    public readonly VALUE: string,
    public readonly UNIT: string,
    public readonly NUMBERING: string,
    public readonly POINTER: ColourPriority,
    public readonly GLASS: string,
    public readonly GEAR: ColourPriority,
    public readonly PARKING_BRAKE: ColourPriority,
    public readonly BACKGROUND: string
  ) {}

  /**
   * @return {boolean} whether or not the background is transparent
   */
  public isBackgroundTransparent(): boolean {
    return this.BACKGROUND.startsWith("rgba");
  }

  /**
   * Creates a colour scheme
   * @param {string} baseColour - the base/main colour
   * @param {string} background - the background colour
   * @param {ColourPriority} arcBar - the secondary colour of the arc bar
   * @return {ColourScheme} the colour scheme created
   */
  private static createScheme(baseColour: string, background: string, arcBar: ColourPriority): ColourScheme {
    let glass = "rgba(0,0,0,0.5)";
    let black = ColourRGB.black().toString();

    return new ColourScheme(
      baseColour,
      arcBar,
      new ColourPriority(black, baseColour),
      baseColour,
      baseColour,
      ColourRGB.white().toString(),
      new ColourPriority(baseColour, black),
      glass,
      new ColourPriority(baseColour, baseColour),
      new ColourPriority(baseColour, ColourRGB.grey().toString()),
      background
    );
  }

  /**
   * Creates a glass/transparent colour scheme
   * @param {ColourRGB} baseColour - the base/main colour
   * @return {ColourScheme} the colour scheme created
   */
  private static createGlassLikeScheme(baseColour: ColourRGB): ColourScheme {
    let arcBar = new ColourPriority(baseColour.toString(), "rgba(0,0,0,0.5)");
    return ColourScheme.createScheme(baseColour.toString(), "rgba(40,40,40,0.25)", arcBar);
  }

  /**
   * Creates a opaque colour scheme
   * @param {ColourRGB} baseColour - the base/main colour
   * @return {ColourScheme} the colour scheme created
   */
  private static createStandardScheme(baseColour: ColourRGB): ColourScheme {
    let arcBar = new ColourPriority(baseColour.toString(), ColourRGB.black().toString());
    return ColourScheme.createScheme(baseColour.toString(), "rgb(30,30,30)", arcBar);
  }

  /**
   * Creates and returns a list of default colour schemes
   * @return {ColourScheme[]} the list of colour schemes
   */
  public static createSchemes(): ColourScheme[] {
    let colours = [
      ColourRGB.orange(),
      ColourRGB.red(),
      ColourRGB.green(),
      ColourRGB.blue(),
      ColourRGB.yellow(),
      ColourRGB.lightblue(),
      ColourRGB.purple(),
      ColourRGB.white()
    ];

    let themes = [];
    for (let colour of colours) {
      themes.push(ColourScheme.createStandardScheme(colour));
      themes.push(ColourScheme.createGlassLikeScheme(colour));
    }

    return themes;
  }
}
