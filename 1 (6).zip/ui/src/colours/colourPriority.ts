/**
 * Represents a dual-colour scheme with a primary/default colour and a secondary/backup colour
 */
export class ColourPriority {
  /**
   * Constructor
   * @param {string} primary - the primary colour
   * @param {string} secondary - the secondary colour
   */
  constructor(private readonly primary: string, private readonly secondary: string) {}

  public invert(): ColourPriority {
    return new ColourPriority(this.secondary, this.primary);
  }

  public clone(): ColourPriority {
    return new ColourPriority(this.primary, this.secondary);
  }

  public asArray(): [string, string] {
    return [this.primary, this.secondary];
  }

  public getPrimary(): string {
    return this.primary;
  }

  public getSecondary(): string {
    return this.secondary;
  }

  /**
   * Returns {@link primary} if passed value is true, else returns {@link secondary}
   * @param {boolean} bool - the boolean value
   * @returns {string} the returned colour
   */
  public getFromBool(bool: boolean): string {
    return bool ? this.primary : this.secondary;
  }
}
