export interface ChangeableColour {
  /**
   * Returns a new object with the same properties but the colour set to the given one
   * @param {string} newColour - the new colour
   * @returns {this} the created object
   */
  changeColour(newColour: string): this
}