import { ColourRGBA } from "./colourRGBA";
import { hexadecimalToDenary } from "../utils/mathsUtils";
import { stringToArray } from "../utils/arrayUtils";

/**
 * Represents an RGB colour
 */
export class ColourRGB {
  constructor(protected r: number, protected g: number, protected b: number) {}

  /**
   * Lightens the colour by the specified amount, where 0 has no effect and 255 has maximal effect
   * @param {number} amount - the amount to lighten
   * @return {ColourRGB} the new colour
   */
  public lighten(amount: number): ColourRGB {
    return new ColourRGB(this.r + amount, this.g + amount, this.b + amount);
  }

  /**
   * Darkens the colour by the specified amount, where 0 has no effect and 255 has maximal effect
   * @param {number} amount - the amount to darken
   * @return {ColourRGB} the new colour
   */
  public darken(amount: number): ColourRGB {
    return new ColourRGB(this.r - amount, this.g - amount, this.b - amount);
  }

  /**
   * Darkens the colour by multiplying each channel by the given amount
   * @param {number} amount - the amount to darken (between [0,1])
   * @return {ColourRGB} the new colour
   */
  public darkMulti(amount: number): ColourRGB {
    return new ColourRGB(this.r * amount, this.g * amount, this.b * amount);
  }

  public get R(): number {
    return this.r;
  }
  public get G(): number {
    return this.g;
  }
  public get B(): number {
    return this.b;
  }

  public toString(): string {
    return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
  }

  /**
   * Converts a hexadecimal string into a ColourRGB or ColourRGBA instance
   * @param {string} colour - the hexadecimal string
   * @returns {ColourRGB | ColourRGBA} the colour instance
   */
  public static hexToInstance(colour: string): ColourRGB | ColourRGBA {
    // Remove starting "#"
    colour = colour.substring(1);
    let channels = stringToArray(colour, 2).map(hexadecimalToDenary);

    // Convert alpha channel from (0-255) to (0-1)
    if (channels.length === 4) channels[3] /= 255;

    return ColourRGB.arrayToInstance(channels);
  }

  /**
   * Converts a rgb() or rgba() string into a ColourRGB or ColourRGBA instance
   * @param {string} colour - the rgb() or rgba() string
   * @returns {ColourRGB | ColourRGBA} the colour instance
   */
  public static jsColourToInstance(colour: string): ColourRGB | ColourRGBA {
    let channels = colour.split(",").map(str => {
      let num = str.match(/[+-]?\d+(\.\d+)?/g)[0];
      return Number.parseFloat(num);
    });
    return ColourRGB.arrayToInstance(channels);
  }

  /**
   * Converts a an array of three or four integers between (0,255) into a ColourRGB or ColourRGBA instance
   * @param {number[]} array - the array of values for each channel. Four values should be provided to specify alpha
   * @returns {ColourRGB | ColourRGBA} the colour instance
   */
  public static arrayToInstance(array: number[]): ColourRGB | ColourRGBA {
    if (array.length === 3) return new ColourRGB(array[0], array[1], array[2]);
    else if (array.length === 4) return new ColourRGBA(array[0], array[1], array[2], array[3]);
  }

  /**
   * Takes in an rgb/rgba or hex string and returns a ColourRGB or ColourRGBA object
   * @param {string} colour the rgb(), rgba() or hex string to convert
   * @returns {ColourRGB | ColourRGBA} the colour instance
   */
  public static colourToInstance(colour: string): ColourRGB | ColourRGBA {
    if (colour.startsWith("rgb") || colour.startsWith("rgba")) return ColourRGB.jsColourToInstance(colour);
    else if (colour.startsWith("#")) return ColourRGB.hexToInstance(colour);

    throw new Error(colour + " is not a known colour format. Use hex, rgb() or rgba()");
  }

  // Colour instances
  public static red(): ColourRGB {
    return new ColourRGB(255, 0, 0);
  }
  public static blue(): ColourRGB {
    return new ColourRGB(0, 100, 255);
  }
  public static grey(): ColourRGB {
    return new ColourRGB(128, 128, 128);
  }
  public static green(): ColourRGB {
    return new ColourRGB(0, 255, 0);
  }
  public static white(): ColourRGB {
    return new ColourRGB(255, 255, 255);
  }
  public static black(): ColourRGB {
    return new ColourRGB(0, 0, 0);
  }
  public static orange(): ColourRGB {
    return new ColourRGB(255, 127, 0);
  }
  public static yellow(): ColourRGB {
    return new ColourRGB(255, 255, 0);
  }
  public static purple(): ColourRGB {
    return new ColourRGB(150, 0, 255);
  }
  public static lightblue(): ColourRGB {
    return new ColourRGB(0, 255, 255);
  }
}
