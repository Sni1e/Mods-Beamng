import { ColourRGB } from "./colourRGB";

/**
 * Represents an RGB colour with an additional alpha channel
 */
export class ColourRGBA extends ColourRGB {
  constructor(r: number, g: number, b: number, protected a: number) {
    super(r, g, b);
  }

  public get A(): number {
    return this.a;
  }

  /**
   * @override
   * @inheritDoc
   */
  public toString(): string {
    return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.a + ")";
  }

  /**
   * @override
   * @inheritDoc
   */
  public lighten(amount: number): ColourRGBA {
    return new ColourRGBA(this.r, this.g, this.b, this.a + amount / 255);
  }

  /**
   * @override
   * @inheritDoc
   */
  public darken(amount: number): ColourRGBA {
    return new ColourRGBA(this.r, this.g, this.b, this.a - amount / 255);
  }

  /**
   * Adds an alpha channel to the a given RGB colour
   * @param {ColourRGB} colour - the colour to add the alpha channel to
   * @param {number} alpha  -the alpha channel value
   * @return {ColourRGBA} the new colour
   */
  public static addAlpha(colour: ColourRGB, alpha: number): ColourRGBA {
    return new ColourRGBA(colour.R, colour.G, colour.B, alpha);
  }
}
