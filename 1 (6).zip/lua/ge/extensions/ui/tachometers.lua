local FILE_NAME = "tachometers_settings";

local function loadWhole()
    local file = readFile(FILE_NAME)

    if not file then
        return nil
    end

    return jsonDecode(file)
end

local function load(id)
    local file = loadWhole()

    if not file then
        return nil
    else
        return file[id]
    end
end

local function save(id, data)
    -- Load existing or create if new
    local file = loadWhole() or {}
    file[id] = data

    serializeJsonToFile(FILE_NAME, file, true)
end

return {
    save = save,
    load = load
}