local id = "M9SF2QDCU"
core_online.apiCall("s1/v4/getMod/"..id, function(response)
    if response and response.responseData and response.responseData.data and response.responseData.data.subscribed ~= "true" then
        guihooks.trigger('toastrMsg', {
            type = "warning",
            title = "Minimap",
            msg = "Incorrect install: deleted mod and subscribed via repository.",
            config = {
                -- require user to acknowledge
                timeOut = 0,
                progressBar = false,
                closeButton = true,

                -- default stuffs
                positionClass = 'toast-top-right',
                preventDuplicates = true,
                preventOpenDuplicates = true,
            }
        })
        core_repository.modSubscribe(id)
        core_modmanager.deleteMod(core_modmanager.getModNameFromID(id))
    end
end)