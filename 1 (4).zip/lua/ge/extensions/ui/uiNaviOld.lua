-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt

local M = {}

local curSpeedLimit = 9999

local function getSpeedLimit()
  local n1, n2 = map.findClosestRoad(be:getPlayerVehicle(0):getPosition())
  local mapNodes = map.getMap().nodes
  if not mapNodes[n1] or not mapNodes[n2] then return end
  local link = mapNodes[n1].links[n2] or mapNodes[n2].links[n1]
  return link.speedLimit
end

local function onGuiUpdate(dt)
  if not be:getPlayerVehicleID(0) then return end
  local cameraForward = core_camera.getForward() or vec3(0,0,0)
  local camPosVec = (core_camera.getPosition()) or vec3(0,0,0)

  local data = {
    playerID = be:getPlayerVehicleID(0),
    objects = deepcopy(map.objects),
    isFreeCam = commands.isFreeCamera() or gameplay_walk.isWalking(), -- use same behaviour for walk mode
    camRotationZ = math.atan2(cameraForward.x, -cameraForward.y) * 180 / math.pi,
    camPosition = camPosVec:toTable(),
    speedLimit = getSpeedLimit() or curSpeedLimit or 9999
  }

  curSpeedLimit = data.speedLimit

  -- convert vec3 to JS table
  for k, v in pairs(data.objects) do
    if scenetree.findObjectById(v.id).hiddenInNavi == "1" or tostring(gameplay_walk.getPlayerUnicycle() or "") == tostring(scenetree.findObjectById(v.id)) then
      data.objects[k] = nil
    end
    v.pos = v.pos:toTable()
    v.vel = v.vel:toTable()
    local dir = v.dirVec:normalized()
    v.rot = math.deg(math.atan2(dir:dot(vec3(1,0,0)), dir:dot(vec3(0,-1,0))))
    v.dirVec = v.dirVec:toTable()
  end

  -- hacky fix to avoid data stop from vehicle
  if bullettime.getPause() then
    be:getPlayerVehicle(0):queueLuaCommand([[ if uiNaviOld then uiNaviOld.updateGFX() end ]])
  end

  data.dt = dt -- send dt to ui for double click
  guihooks.trigger('NavigationMapUpdateOld', data)
end

local function getNodes()
  local tmpmap = map.getMap()
  -- local tmpmap = deepcopy(m) -- since we are always just create a new object out of primitive data types in the function below we don't need this copy here
  local newNodes = {}
  if not tmpmap or not tmpmap.nodes then return end
  for k, v in pairs(tmpmap.nodes) do
    if not v.hiddenInNavi then
      newNodes[k] = {
        pos = {v.pos.x, v.pos.y}, -- v.pos.z}, 3d is not used in ui atm anyway
        radius = v.radius
      }
      newNodes[k].links = {}
      for j, w in pairs(v.links) do
        if not w.hiddenInNavi then
          newNodes[k].links[j] = {drivability = w.drivability, oneWay = w.oneWay}
        end
      end
    end
  end
  return newNodes
end

local function getPointsOfInterest()
  -- points of interest
  local poi_set = scenetree.PointOfInterestSet
  local pois = {}
  if poi_set then
  local poios = poi_set:getObjects() or {}
  for _, pid in pairs(poios) do
    local o = scenetree.findObject(pid)
    if o then
      table.insert(pois, {name = o.name, pos = vec3(o:getPosition()):toTable(), desc = o.desc, title = o.title, type = o.type})
    end
  end
  return pois
 end
end

local function minimapFromTerrainBlock()
  log("I","","No minimap data found in levels info.json. Creating minimap data from terrainblock data...")
  local minimap = {}
  local terr = getObjectByClass("TerrainBlock")
  if terr then
    local blockSize = terr:getWorldBlockSize()
    local minimapImage = terr.minimapImage -- minimapImage is a BString
    if minimapImage:startswith("/") then
      minimapImage = minimapImage:sub(2)
    end
    minimap = {
      {
        size = vec3(blockSize, blockSize, terr.maxHeight):toTable(),
        offset = vec3(terr:getPosition().x, terr:getPosition().y + blockSize, 0):toTable(),
        file = minimapImage
      }
    }
  end
  return minimap
end

local function addOldFormatFromMinimap(d)
  if not d then return end
  local mainTile = d.terrainTiles[1]
  if mainTile then
    d.terrainSize = mainTile.size
    d.minimapImage = mainTile.file
    d.squareSize = 1
    d.terrainOffset = { mainTile.offset[1], mainTile.offset[2] - mainTile.size[1] }
  end
end

local function requestUIDashboardMap()
  print("Requesting UI Dashboard Map...")
  local d = {}
  d.nodes = getNodes()

  local levelData = core_levels.getLevelByName(getCurrentLevelIdentifier())
  if levelData then
    if not levelData.minimap then
      levelData.minimap = minimapFromTerrainBlock()
    end
    d.terrainTiles = levelData.minimap
    -- account for old mods still using the old system
    addOldFormatFromMinimap(d)
  end

  local tmp = getPointsOfInterest()
  if tmp then d.poi = tmp end
  guihooks.trigger('NavigationMapOld', d)
end

local function onVehicleSwitched(oid, nid)
  -- we need the tracking information for the ui navigation, so enable it
  if oid ~= -1 then
    local veh = scenetree.findObject(oid)
    if veh then
      veh:queueLuaCommand("mapmgr.enableTracking()")
    end
  end
  if nid ~= -1 then
    local veh = scenetree.findObject(nid)
    if veh then
      veh:queueLuaCommand("mapmgr.enableTracking()")
    end
  end
end

local function onExtensionLoaded()
  guihooks.trigger('RouteUpdate', {})
end

-- public interface
M.onGuiUpdate = onGuiUpdate
M.onVehicleSwitched = onVehicleSwitched
M.onExtensionLoaded = onExtensionLoaded

M.requestUIDashboardMap = requestUIDashboardMap

return M


