angular.module("beamng.apps").directive("proJ", [function () {
  return {
  templateUrl: '/ui/modules/apps/proJ/app.html',
  replace: true,
  link: function (scope, element, attrs) {
	scope.power = 0;
	scope.weight = 0;
	scope.powerHP = 0;
	scope.ratio = 0;
	let weightOld = 0;
	let weightNew = 0;
	let powerNew = 0;
	let powerOld = 0;
	const LuaPower = `(function()return powertrain.getDevicesByCategory("engine")[1].maxPower end)()`;
	const LuaWeight = `(function()return obj:calcBeamStats().total_weight end)()`;

	bngApi.activeObjectLua(LuaPower, function(power){
	scope.power = Math.ceil(power)
	scope.powerHP = Math.ceil(power * 0.986)
	powerNew = scope.power
	})
	
	bngApi.activeObjectLua(LuaWeight, function(weight){
	scope.weight = Math.ceil(weight)
	weightNew = scope.weight
	scope.ratio = powerNew / weightNew
	scope.ratio = scope.ratio.toFixed(3);
	})
	
	
	
	
	scope.$on('VehicleFocusChanged', function(){
		
		
		setTimeout(()=>bngApi.activeObjectLua(LuaPower, function(power){
	    scope.power = Math.ceil(power)
		scope.powerHP = Math.ceil(power * 0.986)
		powerNew = scope.power
		scope.powerDif = (powerOld - powerNew) * (-1)
		
		}), 50)
		
		setTimeout(()=>bngApi.activeObjectLua(LuaWeight, function(weight){
	    scope.weight = Math.ceil(weight)
		weightNew = scope.weight
		scope.weightDif = weightNew - weightOld
		scope.ratio = powerNew / weightNew;
		scope.ratio = scope.ratio.toFixed(3);
		}), 50)
		

	});
	
}}}]);

